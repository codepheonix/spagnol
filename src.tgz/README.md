# Sara Physio — 3D website + appointment platform

Premium bilingual (IT/EN) physiotherapy website with a procedural 3D hero (built on the open-source
[Dioramas](https://github.com/blendi-remade/dioramas) engine), a no-account / no-payment booking system with
server-side availability and database-level double-booking protection, a mobile-friendly admin dashboard,
patient email (+ optional SMS) notifications and WhatsApp alerts to the practitioner.

**No online payments of any kind** — patients pay at the practice.

## Stack
Next.js 16 (App Router) · React 19 · TypeScript · Tailwind v4 · next-intl · Drizzle ORM · PostgreSQL
(embedded PGlite for dev/tests) · three.js + postprocessing (Dioramas engine) · Resend · Meta WhatsApp Cloud API ·
Twilio (optional) · Vitest.

## Quick start
```bash
npm install
cp .env.example .env.local        # set SESSION_SECRET, ADMIN_EMAIL, ADMIN_PASSWORD
npm run dev                       # http://localhost:3000 → redirects to /it
npm test                          # booking engine + acceptance scenario (12 tests)
```
Without `DATABASE_URL` the app runs on an embedded Postgres (PGlite) stored in `./.data` — nothing to install.
The first run seeds demo content (6 services, Mon–Fri hours, placeholder clinic info) and the admin user.

- Public site: `/it`, `/en` · Booking: `/it/book` · Admin: `/it/admin` (login with `ADMIN_EMAIL` / `ADMIN_PASSWORD`)
- All notifications run in **demo mode** (logged, not sent) until provider keys exist in the environment.

## Production
1. **Database**: create a Postgres (Neon, Supabase, Vercel Postgres, Railway…) and set `DATABASE_URL`.
   Migrations run automatically at first connection (`drizzle/`), including the `btree_gist` extension and the
   exclusion constraint that makes overlapping appointments impossible at the database level.
2. **Secrets**: `SESSION_SECRET` (long random string), `ADMIN_EMAIL`, `ADMIN_PASSWORD` (change it after first login
   in Settings → Account; enable 2FA there too), `NEXT_PUBLIC_APP_URL` (public URL, used in emails).
3. **Email** (Resend): `RESEND_API_KEY`, `EMAIL_FROM` with a verified domain.
4. **WhatsApp** (Meta Cloud API): `WHATSAPP_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID`, an approved message template
   `WHATSAPP_TEMPLATE_NAME` with three body parameters ({{1}} date+time, {{2}} patient, {{3}} treatment),
   `WHATSAPP_VERIFY_TOKEN` + `WHATSAPP_APP_SECRET` for the webhook at `/api/webhooks/whatsapp`.
   The practitioner's number goes in Admin → Settings → Notifications. Business-initiated messages require an
   approved template; a `wa.me` link is not automated delivery.
5. **SMS** (optional, Twilio): `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM`, then enable "SMS to patients".
6. **Reminders / retries**: `vercel.json` schedules `/api/cron/notifications` daily (Hobby plan limit). On Pro set it
   to `*/10 * * * *` for timely 24h/2h reminders. Set `CRON_SECRET`. Confirmations are sent right after booking.
7. Deploy on Vercel (or any Node host): `npm run build && npm start`.

## How availability works
`src/lib/availability.ts` is a pure function: weekly hours ∪ extra openings − closures/breaks/blocks, then candidate
starts on a grid (default = service duration) that fit inside a window and don't intersect any active appointment
incl. buffer. Minimum notice, booking horizon and Europe/Rome DST are applied. `src/lib/booking.ts` re-checks inside
a transaction and the `appointments_no_overlap` EXCLUDE constraint guarantees that two simultaneous requests can never
both succeed — the loser gets `slot_taken` and the UI asks to pick another time.

Statuses: `pending` (optional approval) · `confirmed` · `rescheduled` · `completed` · `cancelled` · `no_show`.
Pending and manual bookings block time too. Cancelling releases exactly its interval; rescheduling locks the new slot
and releases the old in one transaction.

## Layout
```
src/app/[locale]/            public pages (landing, book, booking/confirm, booking/manage, legal) + admin
src/app/api/                 availability, book, manage, ics, cron, webhooks, admin helpers
src/lib/                     availability engine, booking transactions, settings, auth, notifications
src/db/                      Drizzle schema, connection (Postgres or PGlite), seed
src/three/                   Dioramas engine core + procedural spine hero
messages/                    it.json / en.json
tests/                       Vitest acceptance tests        drizzle/   SQL migrations
```

## Limitations / next steps
- Rate limiting is in-memory per instance; add a WAF/edge limiter for public endpoints in production.
- Legal texts are templates — have them reviewed. No clinical records are stored by design.
- Waiting list and recurring series are not implemented (data model leaves room for them).
- Browser push notifications are not wired; the dashboard polls every 30 s and plays a sound while open.
