import { beforeAll, describe, expect, it } from "vitest";
import { DateTime } from "luxon";
import { eq } from "drizzle-orm";

(process.env as Record<string,string>).NODE_ENV = "test";
process.env.NOTIFICATIONS_MODE = "mock";

const { getDb, schema, resetDbForTests } = await import("@/db");
const { seedIfEmpty } = await import("@/db/seed");
const booking = await import("@/lib/booking");
const { computeSlots, daySummary, openWindows } = await import("@/lib/availability");
const { BookingPolicy, setSetting } = await import("@/lib/settings");
const { processNotificationJobs } = await import("@/lib/notify/worker");

const ZONE = "Europe/Rome";
// Next Tuesday at least 3 days out (so min notice never interferes)
const nextTuesday = (() => { let d = DateTime.now().setZone(ZONE).plus({ days: 3 }); while (d.weekday !== 2) d = d.plus({ days: 1 }); return d.toISODate()!; })();
const patient = (i: number) => ({ name: `Paziente ${i}`, email: `p${i}@example.com`, phone: `+3933300000${i}`, locale: "it" as const });

let serviceId = "";

beforeAll(async () => {
  resetDbForTests();
  await seedIfEmpty({ tuesdayAcceptance: true });
  const db = await getDb();
  const s = await db.query.services.findFirst({ where: eq(schema.services.slug, "valutazione") });
  serviceId = s!.id;
});

describe("availability engine (pure)", () => {
  const policy = BookingPolicy.parse({ minNoticeHours: 0 });
  const hours = [{ weekday: 2, startTime: "12:00", endTime: "16:00", active: true }];
  it("yields 12,13,14,15 for 60-min sessions on a 12–16 Tuesday", () => {
    const slots = computeSlots({ dateISO: nextTuesday, service: { durationMin: 60, bufferMin: 0 }, hours, exceptions: [], busy: [], policy });
    expect(slots.map((s) => s.label)).toEqual(["12:00", "13:00", "14:00", "15:00"]);
  });
  it("recomputes for 90-min sessions and buffers", () => {
    const slots = computeSlots({ dateISO: nextTuesday, service: { durationMin: 90, bufferMin: 0 }, hours, exceptions: [], busy: [], policy });
    expect(slots.map((s) => s.label)).toEqual(["12:00", "13:30"]);
    const withBuffer = computeSlots({ dateISO: nextTuesday, service: { durationMin: 60, bufferMin: 15 }, hours, exceptions: [], busy: [], policy: { ...policy, slotStepMin: 75 } });
    expect(withBuffer.map((s) => s.label)).toEqual(["12:00", "13:15", "14:30"]);
  });
  it("applies breaks, closures and extra openings", () => {
    const ex = [{ date: nextTuesday, startTime: "13:00", endTime: "14:00", kind: "break" as const }];
    expect(openWindows(nextTuesday, hours, ex, ZONE).map((w) => w.toFormat("HH:mm"))).toEqual(["12:00 – 13:00", "14:00 – 16:00"]);
    expect(openWindows(nextTuesday, hours, [{ date: nextTuesday, startTime: null, endTime: null, kind: "closed" }], ZONE)).toEqual([]);
    const extra = openWindows(nextTuesday, hours, [{ date: nextTuesday, startTime: "17:00", endTime: "18:00", kind: "open" }], ZONE);
    expect(extra.length).toBe(2);
  });
  it("respects minimum notice and horizon", () => {
    const now = DateTime.fromISO(`${nextTuesday}T11:30`, { zone: ZONE }).toJSDate();
    const slots = computeSlots({ dateISO: nextTuesday, service: { durationMin: 60, bufferMin: 0 }, hours, exceptions: [], busy: [], policy: { ...policy, minNoticeHours: 1 }, now });
    expect(slots.map((s) => s.label)).toEqual(["13:00", "14:00", "15:00"]);
    expect(daySummary({ dateISO: nextTuesday, service: { durationMin: 60, bufferMin: 0 }, hours, exceptions: [], busy: [], policy: { ...policy, horizonDays: 1 }, now: DateTime.fromISO(nextTuesday).minus({ days: 5 }).toJSDate() })).toBe("closed");
  });
  it("handles the DST transition day correctly (clocks go back, last Sunday of October)", () => {
    const sunday = DateTime.fromObject({ year: 2026, month: 10, day: 25 }, { zone: ZONE });
    expect(sunday.weekday).toBe(7);
    const slots = computeSlots({ dateISO: "2026-10-25", service: { durationMin: 60, bufferMin: 0 }, hours: [{ weekday: 7, startTime: "01:00", endTime: "05:00", active: true }], exceptions: [], busy: [], policy, now: new Date("2026-10-01") });
    // 01:00–05:00 local spans five real hours on fall-back day (02:00 happens twice): five 60-min slots, none overlapping
    expect(slots.length).toBe(5);
    for (const s of slots) expect((s.end.getTime() - s.start.getTime()) / 60000).toBe(60);
    for (let i = 1; i < slots.length; i++) expect(slots[i].start.getTime()).toBe(slots[i - 1].end.getTime());
  });
});

describe("acceptance scenario: Tuesday 12–16, 60-min sessions", () => {
  it("books three, offers only 15:00, then the day is full; cancelling frees exactly one interval", async () => {
    const iso = (h: string) => DateTime.fromISO(`${nextTuesday}T${h}`, { zone: ZONE }).toISO()!;
    const a1 = await booking.bookAppointment({ serviceId, startISO: iso("12:00"), patient: patient(1) });
    const a2 = await booking.bookAppointment({ serviceId, startISO: iso("13:00"), patient: patient(2) });
    await booking.bookAppointment({ serviceId, startISO: iso("14:00"), patient: patient(3) });
    expect(a1.appointment.reference).toHaveLength(8);
    expect(a1.manageToken).toBeTruthy();

    let { slots } = await booking.slotsForDay(serviceId, nextTuesday);
    expect(slots.map((s) => s.label)).toEqual(["15:00"]);

    const a4 = await booking.bookAppointment({ serviceId, startISO: iso("15:00"), patient: patient(4) });
    ({ slots } = await booking.slotsForDay(serviceId, nextTuesday));
    expect(slots).toEqual([]);

    // double booking attempt on a taken slot
    await expect(booking.bookAppointment({ serviceId, startISO: iso("13:00"), patient: patient(5) })).rejects.toMatchObject({ code: "slot_taken" });

    // a 30-min service cannot squeeze in either
    const db = await getDb();
    const dn = await db.query.services.findFirst({ where: eq(schema.services.slug, "dry-needling") });
    expect((await booking.slotsForDay(dn!.id, nextTuesday)).slots).toEqual([]);

    // notification jobs were created once per booking (email to patient; admin WhatsApp only if configured)
    const jobs = await db.query.notificationJobs.findMany({ where: eq(schema.notificationJobs.appointmentId, a4.appointment.id) });
    expect(jobs.filter((j) => j.template === "patient_confirmation").length).toBe(1);
    expect(jobs.filter((j) => j.template === "patient_reminder").length).toBe(1);
    const notifs = await db.query.adminNotifications.findMany();
    expect(notifs.length).toBe(4);

    // worker sends (mock) and failure never touches the appointment
    const r = await processNotificationJobs();
    expect(r.sent).toBeGreaterThanOrEqual(4);
    const still = await db.query.appointments.findFirst({ where: eq(schema.appointments.id, a4.appointment.id) });
    expect(still!.status).toBe("confirmed");

    // cancel a2 → exactly 13:00 comes back
    await booking.cancelAppointment(a2.appointment.id);
    ({ slots } = await booking.slotsForDay(serviceId, nextTuesday));
    expect(slots.map((s) => s.label)).toEqual(["13:00"]);
    const reminders = await db.query.notificationJobs.findMany({ where: eq(schema.notificationJobs.appointmentId, a2.appointment.id) });
    expect(reminders.find((j) => j.template === "patient_reminder")!.status).toBe("cancelled");
  });

  it("manage token works, wrong token is rejected", async () => {
    const db = await getDb();
    const appt = (await db.query.appointments.findMany())[0];
    await expect(booking.findByManageToken(appt.reference, "nope")).rejects.toMatchObject({ code: "not_found" });
  });

  it("reschedule locks the new slot and releases the old one atomically", async () => {
    const iso = (h: string) => DateTime.fromISO(`${nextTuesday}T${h}`, { zone: ZONE }).toISO()!;
    const db = await getDb();
    const a1 = await db.query.appointments.findFirst({ where: eq(schema.appointments.status, "confirmed") });
    const moved = await booking.rescheduleAppointment(a1!.id, iso("13:00"));
    expect(moved.status).toBe("rescheduled");
    const { slots } = await booking.slotsForDay(serviceId, nextTuesday);
    expect(slots.map((s) => s.label)).toEqual([DateTime.fromJSDate(a1!.startsAt, { zone: ZONE }).toFormat("HH:mm")]);
    // cannot reschedule onto an occupied slot
    await expect(booking.rescheduleAppointment(a1!.id, iso("15:00"))).rejects.toMatchObject({ code: "slot_taken" });
  });

  it("a manually entered appointment blocks online bookings", async () => {
    const iso = (h: string) => DateTime.fromISO(`${nextTuesday}T${h}`, { zone: ZONE }).toISO()!;
    const { slots } = await booking.slotsForDay(serviceId, nextTuesday);
    const free = slots[0];
    await booking.bookAppointment({ serviceId, startISO: free.start.toISOString(), patient: { name: "Telefono", email: "tel@example.com", phone: "+39000", locale: "it" }, source: "manual", admin: true });
    await expect(booking.bookAppointment({ serviceId, startISO: iso(free.label), patient: patient(9) })).rejects.toMatchObject({ code: "slot_taken" });
  });

  it("two simultaneous visitors can never confirm overlapping sessions", async () => {
    // Open a fresh Tuesday one week later
    const nextNext = DateTime.fromISO(nextTuesday).plus({ weeks: 1 }).toISODate()!;
    const iso = DateTime.fromISO(`${nextNext}T12:00`, { zone: ZONE }).toISO()!;
    const results = await Promise.allSettled(Array.from({ length: 6 }, (_, i) => booking.bookAppointment({ serviceId, startISO: iso, patient: patient(20 + i) })));
    const ok = results.filter((r) => r.status === "fulfilled");
    const taken = results.filter((r) => r.status === "rejected" && (r.reason as { code: string }).code === "slot_taken");
    expect(ok.length).toBe(1);
    expect(taken.length).toBe(5);
    // overlapping but different-duration race: 90-min posturale at 13:30 vs 60-min at 14:00 — both valid alone, never together
    const db = await getDb();
    const post = await db.query.services.findFirst({ where: eq(schema.services.slug, "posturale") });
    const r2 = await Promise.allSettled([
      booking.bookAppointment({ serviceId: post!.id, startISO: DateTime.fromISO(`${nextNext}T13:30`, { zone: ZONE }).toISO()!, patient: patient(30) }),
      booking.bookAppointment({ serviceId, startISO: DateTime.fromISO(`${nextNext}T14:00`, { zone: ZONE }).toISO()!, patient: patient(31) }),
    ]);
    expect(r2.filter((r) => r.status === "fulfilled").length).toBe(1);
  });

  it("public slot query returns no patient data", async () => {
    const { slots } = await booking.slotsForDay(serviceId, nextTuesday);
    for (const s of slots) expect(Object.keys(s).sort()).toEqual(["end", "label", "start"]);
  });

  it("pending-approval mode blocks the slot too", async () => {
    await setSetting("bookingPolicy", BookingPolicy.parse({ requireApproval: true }));
    const nn = DateTime.fromISO(nextTuesday).plus({ weeks: 2 }).toISODate()!;
    const iso = DateTime.fromISO(`${nn}T14:00`, { zone: ZONE }).toISO()!;
    const p = await booking.bookAppointment({ serviceId, startISO: iso, patient: patient(40) });
    expect(p.appointment.status).toBe("pending");
    await expect(booking.bookAppointment({ serviceId, startISO: iso, patient: patient(41) })).rejects.toMatchObject({ code: "slot_taken" });
    const approved = await booking.setAppointmentStatus(p.appointment.id, "confirmed");
    expect(approved.status).toBe("confirmed");
    await setSetting("bookingPolicy", BookingPolicy.parse({}));
  });
});
