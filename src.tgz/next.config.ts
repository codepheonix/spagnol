import type { NextConfig } from "next";
import createNextIntlPlugin from "next-intl/plugin";

const withNextIntl = createNextIntlPlugin("./src/i18n/request.ts");

const nextConfig: NextConfig = {
  turbopack: { rules: { "*.css": { loaders: ["@tailwindcss/turbopack"], as: "*.css" } } },
  serverExternalPackages: ["@electric-sql/pglite", "postgres"],
  headers: async () => [{
    source: "/(.*)",
    headers: [
      { key: "X-Frame-Options", value: "SAMEORIGIN" },
      { key: "X-Content-Type-Options", value: "nosniff" },
      { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
      { key: "Permissions-Policy", value: "camera=(), microphone=(self), geolocation=()" },
      { key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains; preload" },
      { key: "X-DNS-Prefetch-Control", value: "on" },
      // CSP: self + Google Fonts, Cloudflare Turnstile, Vercel Blob (attachments, models), Google Maps embed, Cloudflare Realtime.
      { key: "Content-Security-Policy", value: [
        "default-src 'self'", "base-uri 'self'", "frame-ancestors 'self'", "object-src 'none'",
        "script-src 'self' 'unsafe-inline' 'wasm-unsafe-eval' https://challenges.cloudflare.com",
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com", "font-src 'self' https://fonts.gstatic.com data:",
        "img-src 'self' data: blob: https://*.public.blob.vercel-storage.com https://maps.googleapis.com https://maps.gstatic.com",
        "media-src 'self' blob: https://*.public.blob.vercel-storage.com",
        "connect-src 'self' blob: data: https://*.public.blob.vercel-storage.com https://challenges.cloudflare.com https://rtc.live.cloudflare.com wss://*.cloudflare.com",
        "frame-src https://www.google.com https://challenges.cloudflare.com", "worker-src 'self'", "form-action 'self'", "upgrade-insecure-requests",
      ].join("; ") },
    ],
  }],
};

export default withNextIntl(nextConfig);
