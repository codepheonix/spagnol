#!/usr/bin/env bash
# Vercel install step when the source is shipped inline (no Blob store): fetch the heavy media files from a
# deployment that already serves them, then install dependencies.
set -euo pipefail
MEDIA_BASE="${MEDIA_BASE:-https://sara-physio-nyd0uvux0-elvas-projects-316a8e95.vercel.app}"
for f in apple-icon.png brand/logo-brown.png brand/logo-white.png brand/mark-brown.png brand/mark-white.png favicon.png icon-192.png icon-512.png \
  img/gym.webp img/reception.webp img/sara.webp img/treatment.webp models/character.glb \
  video/hero-1080.mp4 video/hero-1440.mp4 video/hero-mobile.mp4 video/hero-tablet.mp4 video/hero-poster-mobile.webp video/hero-poster-tablet.webp video/hero-poster.webp; do
  mkdir -p "public/$(dirname "$f")"; curl -sfL --retry 3 -o "public/$f" "$MEDIA_BASE/$f" || { echo "media fetch failed: $f"; exit 1; }
done
ls -la public/video
npm ci --legacy-peer-deps
