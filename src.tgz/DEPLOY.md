# Deployment notes

## Current demo deployment (Vercel)
- Project: `sara-physio` on team `elvas-projects-316a8e95` (region fra1, Node 22)
- URL: https://sara-physio-elvas-projects-316a8e95.vercel.app
- Database: embedded PGlite in `/tmp` → **demo only**: bookings reset on cold starts / redeploys.
  Add `DATABASE_URL` (Neon / Supabase / Vercel Postgres) in Project → Settings → Environment Variables to persist data.
- Notifications: `NOTIFICATIONS_MODE=mock` — nothing is sent, jobs are logged and visible in Admin → Settings → Notification queue.
- Admin login: `ADMIN_EMAIL` / `ADMIN_PASSWORD` env vars (set at project creation). Change the password after first login.
- Source delivery: until a GitHub repo is connected, the install command downloads `deploy/src-*.tgz` + `deploy/lock-*.tgz`
  from the project's Vercel Blob store (`sara-physio-deploy`) and runs `npm ci --legacy-peer-deps`.
  Once the repo is on GitHub: Vercel → Project → Settings → Git → connect, and reset Install Command to default.

## Redeploy after code changes (no GitHub)
```bash
git ls-files | grep -v -E "package-lock.json|favicon.ico|scripts/(chk|e2e|shot).mjs" | xargs tar -czf /tmp/src.tgz
curl -X PUT "https://blob.vercel-storage.com/deploy/src-<sha>.tgz" -H "Authorization: Bearer $BLOB_READ_WRITE_TOKEN" \
  -H "x-api-version: 7" -H "x-add-random-suffix: 0" --data-binary @/tmp/src.tgz
# update the Install Command URL, then trigger a deployment (Vercel dashboard → Redeploy, or the API)
```
