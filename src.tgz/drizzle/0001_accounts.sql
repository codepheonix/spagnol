ALTER TABLE "patients" ADD COLUMN "password_hash" text;--> statement-breakpoint
ALTER TABLE "patients" ADD COLUMN "email_verified_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "patients" ADD COLUMN "last_seen_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "patients" ADD COLUMN "birth_date" date;--> statement-breakpoint
CREATE UNIQUE INDEX "patients_account_email_idx" ON "patients" ("email") WHERE "password_hash" IS NOT NULL;--> statement-breakpoint
CREATE TABLE "auth_tokens" (
	"id" text PRIMARY KEY DEFAULT gen_random_uuid()::text NOT NULL,
	"patient_id" text NOT NULL REFERENCES "patients"("id"),
	"token_hash" text NOT NULL,
	"purpose" text NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"used_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);--> statement-breakpoint
CREATE UNIQUE INDEX "auth_tokens_hash_idx" ON "auth_tokens" ("token_hash");--> statement-breakpoint
CREATE TABLE "messages" (
	"id" text PRIMARY KEY DEFAULT gen_random_uuid()::text NOT NULL,
	"patient_id" text NOT NULL REFERENCES "patients"("id"),
	"sender" text NOT NULL,
	"body" text NOT NULL,
	"read_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);--> statement-breakpoint
CREATE INDEX "messages_patient_created_idx" ON "messages" ("patient_id","created_at");--> statement-breakpoint
CREATE TABLE "reschedule_requests" (
	"id" text PRIMARY KEY DEFAULT gen_random_uuid()::text NOT NULL,
	"appointment_id" text NOT NULL REFERENCES "appointments"("id"),
	"patient_id" text NOT NULL REFERENCES "patients"("id"),
	"proposed_starts_at" timestamp with time zone NOT NULL,
	"note" text,
	"status" text DEFAULT 'pending' NOT NULL,
	"decided_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);--> statement-breakpoint
CREATE INDEX "reschedule_status_idx" ON "reschedule_requests" ("status");--> statement-breakpoint
CREATE TABLE "calls" (
	"id" text PRIMARY KEY DEFAULT gen_random_uuid()::text NOT NULL,
	"patient_id" text NOT NULL REFERENCES "patients"("id"),
	"started_by" text NOT NULL,
	"status" text DEFAULT 'ringing' NOT NULL,
	"provider" text DEFAULT 'demo' NOT NULL,
	"room" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"answered_at" timestamp with time zone,
	"ended_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);--> statement-breakpoint
CREATE INDEX "calls_patient_idx" ON "calls" ("patient_id","created_at");
