import {
  pgTable, text, integer, boolean, timestamp, jsonb, date, time, pgEnum, uniqueIndex, index,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const appointmentStatus = pgEnum("appointment_status", [
  "pending", "confirmed", "rescheduled", "completed", "cancelled", "no_show",
]);
export const exceptionKind = pgEnum("exception_kind", ["closed", "open", "break", "block"]);
export const jobStatus = pgEnum("job_status", ["queued", "sent", "failed", "cancelled", "mock"]);
export const jobChannel = pgEnum("job_channel", ["whatsapp", "email", "sms", "push"]);

const id = () => text("id").primaryKey().default(sql`gen_random_uuid()::text`);
const createdAt = () => timestamp("created_at", { withTimezone: true }).notNull().defaultNow();

export const admins = pgTable("admins", {
  id: id(),
  email: text("email").notNull(),
  name: text("name").notNull(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").notNull().default("owner"),
  totpSecret: text("totp_secret"),
  locale: text("locale").notNull().default("it"),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("admins_email_idx").on(t.email)]);

export const patients = pgTable("patients", {
  id: id(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  locale: text("locale").notNull().default("it"),
  smsOptIn: boolean("sms_opt_in").notNull().default(false),
  emailOptIn: boolean("email_opt_in").notNull().default(true),
  notes: text("notes"),
  passwordHash: text("password_hash"), // set = has a patient account
  emailVerifiedAt: timestamp("email_verified_at", { withTimezone: true }),
  lastSeenAt: timestamp("last_seen_at", { withTimezone: true }),
  birthDate: date("birth_date"),
  createdAt: createdAt(),
}, (t) => [index("patients_email_idx").on(t.email), index("patients_phone_idx").on(t.phone)]);

export const authTokens = pgTable("auth_tokens", {
  id: id(),
  patientId: text("patient_id").notNull().references(() => patients.id),
  tokenHash: text("token_hash").notNull(),
  purpose: text("purpose").notNull(), // magic | verify | reset
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  usedAt: timestamp("used_at", { withTimezone: true }),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("auth_tokens_hash_idx").on(t.tokenHash)]);

export const messages = pgTable("messages", {
  id: id(),
  patientId: text("patient_id").notNull().references(() => patients.id),
  sender: text("sender").notNull(), // patient | admin
  body: text("body").notNull(),
  replyToId: text("reply_to_id"),
  attachments: jsonb("attachments").$type<Attachment[]>().notNull().default(sql`'[]'::jsonb`),
  readAt: timestamp("read_at", { withTimezone: true }),
  createdAt: createdAt(),
}, (t) => [index("messages_patient_created_idx").on(t.patientId, t.createdAt)]);

export type Attachment = { url: string; name: string; size: number; type: string };

export const pushSubscriptions = pgTable("push_subscriptions", {
  id: id(),
  ownerType: text("owner_type").notNull(), // patient | admin
  ownerId: text("owner_id").notNull(),
  endpoint: text("endpoint").notNull(),
  keys: jsonb("keys").$type<{ p256dh: string; auth: string }>().notNull(),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("push_endpoint_idx").on(t.endpoint), index("push_owner_idx").on(t.ownerType, t.ownerId)]);

export const rescheduleRequests = pgTable("reschedule_requests", {
  id: id(),
  appointmentId: text("appointment_id").notNull().references(() => appointments.id),
  patientId: text("patient_id").notNull().references(() => patients.id),
  proposedStartsAt: timestamp("proposed_starts_at", { withTimezone: true }).notNull(),
  note: text("note"),
  status: text("status").notNull().default("pending"), // pending | accepted | declined | withdrawn
  decidedAt: timestamp("decided_at", { withTimezone: true }),
  createdAt: createdAt(),
}, (t) => [index("reschedule_status_idx").on(t.status)]);

export const calls = pgTable("calls", {
  id: id(),
  patientId: text("patient_id").notNull().references(() => patients.id),
  startedBy: text("started_by").notNull(), // patient | admin
  status: text("status").notNull().default("ringing"), // ringing | active | ended | missed | declined
  provider: text("provider").notNull().default("demo"), // demo | cloudflare
  room: jsonb("room").$type<Record<string, unknown>>().notNull().default(sql`'{}'::jsonb`),
  answeredAt: timestamp("answered_at", { withTimezone: true }),
  endedAt: timestamp("ended_at", { withTimezone: true }),
  createdAt: createdAt(),
}, (t) => [index("calls_patient_idx").on(t.patientId, t.createdAt)]);

export const services = pgTable("services", {
  id: id(),
  slug: text("slug").notNull(),
  titleIt: text("title_it").notNull(),
  titleEn: text("title_en").notNull(),
  descriptionIt: text("description_it").notNull().default(""),
  descriptionEn: text("description_en").notNull().default(""),
  durationMin: integer("duration_min").notNull(),
  bufferMin: integer("buffer_min").notNull().default(0),
  priceCents: integer("price_cents"), // informational only, never charged
  active: boolean("active").notNull().default(true),
  sort: integer("sort").notNull().default(0),
}, (t) => [uniqueIndex("services_slug_idx").on(t.slug)]);

export const workingHours = pgTable("working_hours", {
  id: id(),
  providerId: text("provider_id").notNull().default("main"),
  weekday: integer("weekday").notNull(), // 1 = Monday … 7 = Sunday (ISO)
  startTime: time("start_time").notNull(),
  endTime: time("end_time").notNull(),
  active: boolean("active").notNull().default(true),
});

export const availabilityExceptions = pgTable("availability_exceptions", {
  id: id(),
  providerId: text("provider_id").notNull().default("main"),
  date: date("date").notNull(),
  startTime: time("start_time"), // null = whole day
  endTime: time("end_time"),
  kind: exceptionKind("kind").notNull(),
  note: text("note"),
  createdAt: createdAt(),
}, (t) => [index("exceptions_date_idx").on(t.date)]);

export const appointments = pgTable("appointments", {
  id: id(),
  reference: text("reference").notNull(),
  patientId: text("patient_id").notNull().references(() => patients.id),
  serviceId: text("service_id").notNull().references(() => services.id),
  providerId: text("provider_id").notNull().default("main"),
  startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
  endsAt: timestamp("ends_at", { withTimezone: true }).notNull(),
  blocksUntil: timestamp("blocks_until", { withTimezone: true }).notNull(), // ends_at + buffer
  status: appointmentStatus("status").notNull().default("confirmed"),
  source: text("source").notNull().default("online"), // online | manual
  manageTokenHash: text("manage_token_hash"),
  adminNotes: text("admin_notes"),
  patientNotes: text("patient_notes"),
  locale: text("locale").notNull().default("it"),
  bookedAt: createdAt(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex("appointments_reference_idx").on(t.reference),
  index("appointments_starts_idx").on(t.startsAt),
  index("appointments_patient_idx").on(t.patientId),
]);

export const appointmentEvents = pgTable("appointment_events", {
  id: id(),
  appointmentId: text("appointment_id").notNull().references(() => appointments.id),
  type: text("type").notNull(), // booked | rescheduled | cancelled | completed | no_show | note | manual
  actor: text("actor").notNull().default("patient"), // patient | admin | system
  data: jsonb("data").$type<Record<string, unknown>>().notNull().default(sql`'{}'::jsonb`),
  createdAt: createdAt(),
}, (t) => [index("events_appointment_idx").on(t.appointmentId)]);

export const notificationJobs = pgTable("notification_jobs", {
  id: id(),
  channel: jobChannel("channel").notNull(),
  recipient: text("recipient").notNull(),
  template: text("template").notNull(),
  locale: text("locale").notNull().default("it"),
  payload: jsonb("payload").$type<Record<string, unknown>>().notNull().default(sql`'{}'::jsonb`),
  appointmentId: text("appointment_id").references(() => appointments.id),
  dedupeKey: text("dedupe_key").notNull(),
  status: jobStatus("status").notNull().default("queued"),
  attempts: integer("attempts").notNull().default(0),
  runAt: timestamp("run_at", { withTimezone: true }).notNull().defaultNow(),
  sentAt: timestamp("sent_at", { withTimezone: true }),
  providerMessageId: text("provider_message_id"),
  lastError: text("last_error"),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("jobs_dedupe_idx").on(t.dedupeKey), index("jobs_status_run_idx").on(t.status, t.runAt)]);

export const adminNotifications = pgTable("admin_notifications", {
  id: id(),
  type: text("type").notNull(), // new_booking | cancelled | rescheduled | pending
  titleIt: text("title_it").notNull(),
  titleEn: text("title_en").notNull(),
  appointmentId: text("appointment_id").references(() => appointments.id),
  read: boolean("read").notNull().default(false),
  createdAt: createdAt(),
});

export const webhookEvents = pgTable("webhook_events", {
  id: text("id").primaryKey(), // provider event id, for idempotency
  provider: text("provider").notNull(),
  payload: jsonb("payload").notNull(),
  createdAt: createdAt(),
});

export const contentSettings = pgTable("content_settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Service = typeof services.$inferSelect;
export type Appointment = typeof appointments.$inferSelect;
export type Patient = typeof patients.$inferSelect;
export type WorkingHour = typeof workingHours.$inferSelect;
export type AvailabilityException = typeof availabilityExceptions.$inferSelect;
export type NotificationJob = typeof notificationJobs.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type RescheduleRequest = typeof rescheduleRequests.$inferSelect;
export type Call = typeof calls.$inferSelect;
