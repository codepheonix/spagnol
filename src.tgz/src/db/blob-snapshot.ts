// Demo persistence without a Postgres server: the embedded PGlite database is snapshotted to Vercel Blob after
// every write and reloaded when another serverless instance has published a newer snapshot.
// Eventually consistent (≈ one request of lag) and last-writer-wins under concurrent writes — fine for a demo,
// NOT for production: set DATABASE_URL (Neon, Supabase, …) and this file is never used.
const API = "https://blob.vercel-storage.com";
const PREFIX = `db/${process.env.VERCEL_ENV ?? "local"}/pglite-`;
const KEEP = 3;

declare global { var __saraSnapOff: string | undefined }
/** Called when the Blob store is unreachable (e.g. quota suspended): run on a plain in-memory database for this instance. */
export function disableSnapshots(reason: string) { globalThis.__saraSnapOff = reason; }
export function snapshotEnabled() {
  return !globalThis.__saraSnapOff && !!(process.env.VERCEL && process.env.BLOB_READ_WRITE_TOKEN && !process.env.DATABASE_URL && !process.env.POSTGRES_URL);
}
const headers = () => ({ Authorization: `Bearer ${process.env.BLOB_READ_WRITE_TOKEN}`, "x-api-version": "7" });

export type Snap = { url: string; pathname: string; size: number };

/** Newest snapshot (names carry a timestamp, so the lexicographically last one is the latest). */
export async function latestSnapshot(): Promise<Snap | null> {
  const r = await fetch(`${API}/?prefix=${encodeURIComponent(PREFIX)}&limit=1000`, { headers: headers(), cache: "no-store" });
  if (!r.ok) return null;
  const j = (await r.json()) as { blobs?: Snap[] };
  const list = (j.blobs ?? []).sort((a, b) => a.pathname.localeCompare(b.pathname));
  return list.at(-1) ?? null;
}

export async function downloadSnapshot(s: Snap): Promise<Blob> {
  const r = await fetch(s.url, { cache: "no-store" });
  if (!r.ok) throw new Error(`snapshot download ${r.status}`);
  return new Blob([await r.arrayBuffer()], { type: "application/gzip" });
}

export async function uploadSnapshot(data: Blob): Promise<Snap> {
  const pathname = `${PREFIX}${String(Date.now()).padStart(14, "0")}.tar.gz`;
  const r = await fetch(`${API}/${pathname}`, { method: "PUT", headers: { ...headers(), "x-add-random-suffix": "0", "content-type": "application/gzip" }, body: data });
  if (!r.ok) throw new Error(`snapshot upload ${r.status}: ${(await r.text()).slice(0, 200)}`);
  const j = (await r.json()) as Snap;
  pruneSnapshots(j.pathname).catch(() => {});
  return { url: j.url, pathname: j.pathname ?? pathname, size: data.size };
}

async function pruneSnapshots(current: string) {
  const r = await fetch(`${API}/?prefix=${encodeURIComponent(PREFIX)}&limit=1000`, { headers: headers(), cache: "no-store" });
  if (!r.ok) return;
  const j = (await r.json()) as { blobs?: Snap[] };
  const list = (j.blobs ?? []).sort((a, b) => a.pathname.localeCompare(b.pathname)).filter((b) => b.pathname !== current);
  const old = list.slice(0, Math.max(0, list.length - (KEEP - 1)));
  if (old.length) await fetch(`${API}/delete`, { method: "POST", headers: { ...headers(), "content-type": "application/json" }, body: JSON.stringify({ urls: old.map((b) => b.url) }) });
}
