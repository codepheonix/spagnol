import bcrypt from "bcryptjs";
import { and, count, eq, isNotNull } from "drizzle-orm";
import { getDb, schema } from "./index";
import { setSetting, BookingPolicy, ClinicInfo, NotificationSettings } from "@/lib/settings";

/** Demo patient account (public demo only; remove or change DEMO_PATIENT_PASSWORD for real use). */
export const DEMO_PATIENT = { name: "Anna Rossi", email: "paziente@example.com", phone: "+39 333 000 1111", password: process.env.DEMO_PATIENT_PASSWORD ?? "PazienteDemo-2026!" };
export async function ensureDemoPatient() {
  if (process.env.DEMO_PATIENT_PASSWORD === "off") return;
  const db = await getDb();
  const exists = await db.query.patients.findFirst({ where: and(eq(schema.patients.email, DEMO_PATIENT.email), isNotNull(schema.patients.passwordHash)) });
  if (exists) return;
  await db.insert(schema.patients).values({ name: DEMO_PATIENT.name, email: DEMO_PATIENT.email, phone: DEMO_PATIENT.phone, locale: "it", passwordHash: await bcrypt.hash(DEMO_PATIENT.password, 10), emailVerifiedAt: new Date() });
}

export async function seedIfEmpty(opts: { adminEmail?: string; adminPassword?: string; tuesdayAcceptance?: boolean } = {}) {
  const db = await getDb();
  const [{ n }] = await db.select({ n: count() }).from(schema.services);
  if (Number(n) > 0) { if (process.env.NODE_ENV !== "test") await ensureDemoPatient(); return { seeded: false }; }

  await db.insert(schema.services).values([
    { slug: "valutazione", titleIt: "Prima valutazione", titleEn: "Initial assessment", durationMin: 60, bufferMin: 0, priceCents: 7000, sort: 1,
      descriptionIt: "Un'ora dedicata a capire la tua storia, il dolore e gli obiettivi. Esame funzionale completo e piano di trattamento.",
      descriptionEn: "An hour dedicated to your history, your pain and your goals. Full functional exam and a treatment plan." },
    { slug: "terapia-manuale", titleIt: "Terapia manuale", titleEn: "Manual therapy", durationMin: 45, bufferMin: 0, priceCents: 6000, sort: 2,
      descriptionIt: "Mobilizzazioni, manipolazioni e tecniche sui tessuti molli per ridurre il dolore e recuperare il movimento.",
      descriptionEn: "Mobilisations, manipulations and soft-tissue techniques to reduce pain and restore movement." },
    { slug: "riabilitazione", titleIt: "Riabilitazione post-operatoria", titleEn: "Post-surgery rehabilitation", durationMin: 60, bufferMin: 0, priceCents: 7000, sort: 3,
      descriptionIt: "Percorsi personalizzati dopo interventi a ginocchio, spalla, anca e colonna, in coordinamento con il chirurgo.",
      descriptionEn: "Personalised programmes after knee, shoulder, hip and spine surgery, coordinated with your surgeon." },
    { slug: "sportiva", titleIt: "Fisioterapia sportiva", titleEn: "Sports physiotherapy", durationMin: 60, bufferMin: 0, priceCents: 7000, sort: 4,
      descriptionIt: "Prevenzione e recupero degli infortuni, return-to-play e ottimizzazione del gesto atletico.",
      descriptionEn: "Injury prevention and recovery, return-to-play and movement optimisation for athletes." },
    { slug: "dry-needling", titleIt: "Dry needling", titleEn: "Dry needling", durationMin: 30, bufferMin: 0, priceCents: 4500, sort: 5,
      descriptionIt: "Trattamento dei trigger point con aghi sottili, in combinazione con esercizio terapeutico.",
      descriptionEn: "Trigger-point treatment with fine needles, combined with therapeutic exercise." },
    { slug: "posturale", titleIt: "Rieducazione posturale", titleEn: "Postural re-education", durationMin: 90, bufferMin: 0, priceCents: 9000, sort: 6,
      descriptionIt: "Seduta estesa di analisi posturale e lavoro globale sulle catene muscolari.",
      descriptionEn: "Extended session of postural analysis and global work on the muscle chains." },
  ]);

  const hours = opts.tuesdayAcceptance
    ? [{ weekday: 2, startTime: "12:00", endTime: "16:00" }]
    : [1, 2, 3, 4, 5].flatMap((weekday) => [{ weekday, startTime: "09:00", endTime: "13:00" }, { weekday, startTime: "14:30", endTime: "19:00" }]);
  await db.insert(schema.workingHours).values(hours.map((h) => ({ ...h, providerId: "main", active: true })));

  await setSetting("bookingPolicy", BookingPolicy.parse({}));
  await setSetting("clinicInfo", ClinicInfo.parse({}));
  await setSetting("notifications", NotificationSettings.parse({ adminWhatsapp: process.env.ADMIN_WHATSAPP ?? "", adminEmail: opts.adminEmail ?? process.env.ADMIN_EMAIL ?? "" }));

  const email = (opts.adminEmail ?? process.env.ADMIN_EMAIL ?? "sara@example.com").toLowerCase();
  const password = opts.adminPassword ?? process.env.ADMIN_PASSWORD ?? "changeme-123";
  await db.insert(schema.admins).values({ email, name: "Sara", passwordHash: await bcrypt.hash(password, 10) });
  if (process.env.NODE_ENV !== "test") await ensureDemoPatient();
  return { seeded: true, adminEmail: email };
}
