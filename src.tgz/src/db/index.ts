import * as schema from "./schema";
import type { PgDatabase, PgQueryResultHKT } from "drizzle-orm/pg-core";
import path from "node:path";
import { after } from "next/server";
import { snapshotEnabled, latestSnapshot, downloadSnapshot, uploadSnapshot, disableSnapshots } from "./blob-snapshot";

export type Db = PgDatabase<PgQueryResultHKT, typeof schema>;

const MIGRATIONS = path.join(process.cwd(), "drizzle");

declare global {
  // eslint-disable-next-line no-var
  var __saraDb: Promise<Db> | undefined;
  // eslint-disable-next-line no-var
  var __saraFlushNow: (() => Promise<void>) | undefined;
  // eslint-disable-next-line no-var
  var __saraSnap: { loaded: string | null; checkedAt: number; pushing: Promise<void> | null; checking: Promise<void> | null; client: { close(): Promise<void> } | null } | undefined;
}

async function create(): Promise<Db> {
  const url = process.env.DATABASE_URL || process.env.POSTGRES_URL || process.env.DATABASE_URL_UNPOOLED;
  if (url) {
    const { drizzle } = await import("drizzle-orm/postgres-js");
    const { migrate } = await import("drizzle-orm/postgres-js/migrator");
    const postgres = (await import("postgres")).default;
    const client = postgres(url, { max: process.env.NODE_ENV === "production" ? 5 : 2, prepare: false });
    const db = drizzle(client, { schema });
    if (process.env.DB_AUTO_MIGRATE !== "false") await migrate(db, { migrationsFolder: MIGRATIONS });
    return db as unknown as Db;
  }
  // No DATABASE_URL: embedded Postgres (PGlite). Memory in tests, on disk in dev.
  const { PGlite } = await import("@electric-sql/pglite");
  const { btree_gist } = await import("@electric-sql/pglite/contrib/btree_gist");
  const { drizzle } = await import("drizzle-orm/pglite");
  const { migrate } = await import("drizzle-orm/pglite/migrator");
  // On Vercel without DATABASE_URL the only writable path is /tmp: fine for a demo, but data does not survive
  // cold starts or redeploys. Set DATABASE_URL (Neon, Supabase, Vercel Postgres…) for real use.
  if (snapshotEnabled()) {
    // Serverless demo mode: in-memory database restored from the latest Vercel Blob snapshot, re-published after writes.
    let snap: Awaited<ReturnType<typeof latestSnapshot>> = null, data: Blob | undefined;
    try { snap = await latestSnapshot(); if (snap) data = await downloadSnapshot(snap); } catch (e) {
      // Blob store unreachable (quota suspended, token revoked…): the site must still load. Fall back to a fresh
      // in-memory demo database for this instance; writes are not persisted until the store or DATABASE_URL is back.
      disableSnapshots((e as Error).message); console.error("[db snapshot] unavailable, running without persistence:", (e as Error).message);
    }
    if (!snapshotEnabled()) return createLocal();
    console.log("[db snapshot] loading", snap?.pathname ?? "(none, fresh database)");
    const client = await PGlite.create({ loadDataDir: data, extensions: { btree_gist } });
    const state: NonNullable<typeof globalThis.__saraSnap> = (globalThis.__saraSnap = { loaded: snap?.pathname ?? null, checkedAt: Date.now(), pushing: null, checking: null, client });
    let dirty = false;
    const flush = async () => {
      if (!dirty) return;
      dirty = false;
      try {
        const blob = await client.dumpDataDir("gzip");
        const up = await uploadSnapshot(blob);
        state.loaded = up.pathname; state.checkedAt = Date.now();
        console.log("[db snapshot] published", up.pathname);
      } catch (e) { const m = (e as Error).message; if (/403|blocked/i.test(m)) { dirty = false; disableSnapshots(m); } else dirty = true; console.error("[db snapshot] push failed:", m); }
    };
    const job = () => { const p: Promise<void> = (state.pushing ?? Promise.resolve()).then(flush, flush).finally(() => { if (state.pushing === p) state.pushing = null; }); state.pushing = p; return p; };
    globalThis.__saraFlushNow = async () => { if (dirty) await job(); else await (state.pushing ?? Promise.resolve()); };
    const schedule = () => {
      dirty = true;
      // Publish after the response is sent (Next keeps the function alive for after() callbacks) unless the request
      // awaits flushDb() first (mutating actions/routes do, so the user's next navigation sees the write). Serialised.
      try { after(job); } catch { setTimeout(job, 50); }
    };
    let booting = true; // migrations/seed on boot must not republish an unchanged database
    const isWrite = (q: unknown) => !booting && typeof q === "string" && /(^|;)\s*(insert|update|delete)\b/i.test(q);
    const c = client as unknown as { query: (...a: unknown[]) => Promise<unknown>; exec: (...a: unknown[]) => Promise<unknown>; transaction: (...a: unknown[]) => Promise<unknown> };
    const [q0, e0, t0] = [c.query.bind(client), c.exec.bind(client), c.transaction.bind(client)];
    const changed = (r: unknown) => ((r as { affectedRows?: number })?.affectedRows ?? 1) > 0; // skip no-op UPDATE/DELETE
    c.query = async (...a) => { const r = await q0(...a); if (isWrite(a[0]) && changed(r)) schedule(); return r; };
    c.exec = async (...a) => { const r = await e0(...a); if (isWrite(a[0])) schedule(); return r; };
    c.transaction = async (...a) => { const r = await t0(...a); if (!booting) schedule(); return r; };
    const db = drizzle(client, { schema });
    await migrate(db, { migrationsFolder: MIGRATIONS });
    globalThis.__saraDb = Promise.resolve(db as unknown as Db);
    const { seedIfEmpty } = await import("./seed");
    await seedIfEmpty();
    booting = false;
    if (!snap) schedule(); // brand-new database: publish the seeded state once
    return db as unknown as Db;
  }
  return createLocal();
}

/** Embedded PGlite on disk (dev) or in /tmp (serverless without a snapshot store). */
async function createLocal(): Promise<Db> {
  const { PGlite } = await import("@electric-sql/pglite");
  const { btree_gist } = await import("@electric-sql/pglite/contrib/btree_gist");
  const { drizzle } = await import("drizzle-orm/pglite");
  const { migrate } = await import("drizzle-orm/pglite/migrator");
  const dataDir = process.env.PGLITE_DATA ?? (process.env.NODE_ENV === "test" ? undefined : process.env.VERCEL ? "/tmp/pglite" : path.join(process.cwd(), ".data", "pglite"));
  if (dataDir) (await import("node:fs")).mkdirSync(dataDir, { recursive: true });
  const client = await PGlite.create({ dataDir, extensions: { btree_gist } });
  const db = drizzle(client, { schema });
  await migrate(db, { migrationsFolder: MIGRATIONS });
  globalThis.__saraDb = Promise.resolve(db as unknown as Db);
  if (process.env.NODE_ENV !== "test") {
    // Embedded DB may be brand new on every instance (e.g. /tmp on serverless): seed demo data so every route works.
    const { seedIfEmpty } = await import("./seed");
    await seedIfEmpty();
  }
  return db as unknown as Db;
}

export async function getDb(): Promise<Db> {
  const st = globalThis.__saraSnap;
  // snapshot mode: at most twice a second, check whether another instance published a newer snapshot and reload if so.
  // The check is a shared promise so that components rendering in parallel (layout + page) all wait for the same answer.
  if (st && globalThis.__saraDb && !st.pushing) {
    if (!st.checking && Date.now() - st.checkedAt > 500) {
      st.checkedAt = Date.now();
      st.checking = (async () => {
        try {
          const latest = await latestSnapshot();
          if (latest && latest.pathname !== st.loaded && !st.pushing && globalThis.__saraSnap === st) {
            console.log("[db snapshot] newer snapshot found, reloading", latest.pathname, "was", st.loaded);
            const old = st.client; globalThis.__saraDb = undefined; globalThis.__saraSnap = undefined;
            setTimeout(() => old?.close().catch(() => {}), 30_000); // in-flight queries on the old copy finish first
          }
        } catch { /* keep the current copy */ }
      })().finally(() => { st.checking = null; });
    }
    if (st.checking) await st.checking;
  }
  if (!globalThis.__saraDb) globalThis.__saraDb = create().catch((e) => { globalThis.__saraDb = undefined; throw e; });
  return globalThis.__saraDb;
}

/** Snapshot mode: publish pending writes now (no-op with a real Postgres). Call before responding to a mutation. */
export async function flushDb() {
  try { await globalThis.__saraFlushNow?.(); } catch { /* best effort */ }
}

/** Test helper: drop the cached connection so each test file gets a fresh in-memory database. */
export function resetDbForTests() {
  globalThis.__saraDb = undefined;
}

export { schema };
