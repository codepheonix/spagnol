import { NextResponse } from "next/server";
import { z } from "zod";
import { getDb, schema, flushDb } from "@/db";
import { getSetting } from "@/lib/settings";
import { clientIp, rateLimit } from "@/lib/ratelimit";
import { processNotificationJobs } from "@/lib/notify/worker";

export const dynamic = "force-dynamic";
const Body = z.object({ name: z.string().trim().min(2).max(120), email: z.string().trim().email(), message: z.string().trim().min(5).max(4000), website: z.string().optional(), locale: z.string().optional() });

/** Public contact form → practitioner e-mail (if configured) + dashboard notification. Honeypot + rate limit. */
export async function POST(req: Request) {
  if (!rateLimit(`contact:${clientIp(req)}`, 5, 10 * 60_000).ok) return NextResponse.json({ error: "rate_limited" }, { status: 429 });
  const parsed = Body.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return NextResponse.json({ error: "invalid" }, { status: 400 });
  const b = parsed.data;
  if (b.website) return NextResponse.json({ ok: true }); // bot
  const db = await getDb();
  const notif = await getSetting("notifications");
  const text = `${b.name} <${b.email}>\n\n${b.message}`;
  if (notif.adminEmail) await db.insert(schema.notificationJobs).values({ channel: "email", recipient: notif.adminEmail, template: "contact_form", locale: "it", payload: { name: b.name, email: b.email, message: b.message, text }, dedupeKey: `contact:${Date.now()}:${b.email}` });
  await db.insert(schema.adminNotifications).values({ type: "contact", titleIt: `Messaggio dal sito — ${b.name}`, titleEn: `Website message — ${b.name}` });
  processNotificationJobs().catch(() => {});
  await flushDb();
  return NextResponse.json({ ok: true });
}
