import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { getPatientSession } from "@/lib/patient-auth";
import { getCall, updateCall } from "@/lib/care";
import { sfu, cloudflareConfigured } from "@/lib/calls/cloudflare";
import { flushDb } from "@/db";

export const dynamic = "force-dynamic";

/** Call signalling. Both parties poll "status"; Cloudflare SFU calls are proxied so the app secret never reaches the browser. */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = (await req.json().catch(() => ({}))) as Record<string, string>;
  const call = await getCall(id);
  if (!call) return NextResponse.json({ error: "not_found" }, { status: 404 });
  // authorise: the practitioner, or the patient who owns the call
  const admin = await getSession();
  const patient = admin ? null : await getPatientSession();
  const role = admin ? "admin" : patient?.sub === call.patientId ? "patient" : null;
  if (!role) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const noStore = { headers: { "Cache-Control": "no-store" } };

  try {
    switch (body.action) {
      case "status":
        return NextResponse.json({ id: call.id, status: call.status, provider: call.provider, room: call.room, answeredAt: call.answeredAt, startedBy: call.startedBy }, noStore);
      case "join": {
        // the second party joining moves the call from ringing → active
        const joined = { ...(call.room as Record<string, string>), [`${role}Joined`]: "1" };
        const both = joined.adminJoined && joined.patientJoined;
        const c = await updateCall(id, { room: joined, ...(both && call.status === "ringing" ? { status: "active", answeredAt: new Date() } : {}) });
        await flushDb();
        return NextResponse.json({ status: c?.status }, noStore);
      }
      case "end": {
        const c = await updateCall(id, { status: call.status === "ringing" && role !== call.startedBy ? "declined" : "ended", endedAt: new Date() });
        await flushDb();
        return NextResponse.json({ status: c?.status }, noStore);
      }
      case "push": {
        if (!cloudflareConfigured()) return NextResponse.json({ error: "cloudflare_not_configured" }, { status: 400 });
        const { sessionId } = await sfu.newSession();
        const r = await sfu.push(sessionId, body.sdp, [{ location: "local", mid: body.mid, trackName: body.trackName }]);
        await updateCall(id, { room: { [`${role}Session`]: sessionId, [`${role}Track`]: body.trackName } });
        await flushDb();
        return NextResponse.json({ sessionId, ...r }, noStore);
      }
      case "pull": {
        if (!cloudflareConfigured()) return NextResponse.json({ error: "cloudflare_not_configured" }, { status: 400 });
        const mine = (call.room as Record<string, string>)[`${role}Session`];
        const r = await sfu.pull(mine, [{ location: "remote", sessionId: body.otherSession, trackName: body.otherTrack }]);
        return NextResponse.json(r, noStore);
      }
      case "renegotiate": {
        const mine = (call.room as Record<string, string>)[`${role}Session`];
        return NextResponse.json(await sfu.renegotiate(mine, body.sdp), noStore);
      }
      default:
        return NextResponse.json({ error: "bad_action" }, { status: 400 });
    }
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 502 });
  }
}
