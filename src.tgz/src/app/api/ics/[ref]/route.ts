import { findByManageToken, getAppointmentFull, BookingError } from "@/lib/booking";
import { getSetting } from "@/lib/settings";

export const dynamic = "force-dynamic";
const fmt = (d: Date) => d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
const esc = (s: string) => s.replace(/\\/g, "\\\\").replace(/;/g, "\;").replace(/,/g, "\\,").replace(/\n/g, "\\n");

export async function GET(req: Request, { params }: { params: Promise<{ ref: string }> }) {
  const { ref } = await params;
  const token = new URL(req.url).searchParams.get("t") ?? "";
  try {
    const a = await findByManageToken(ref, token);
    const { appointment, service } = await getAppointmentFull(a.id);
    const clinic = await getSetting("clinicInfo");
    const title = appointment.locale === "en" ? service.titleEn : service.titleIt;
    const ics = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Studio Fisioterapia//Booking//IT", "METHOD:PUBLISH", "BEGIN:VEVENT",
      `UID:${appointment.reference}@fisioterapia`, `DTSTAMP:${fmt(new Date())}`, `DTSTART:${fmt(appointment.startsAt)}`, `DTEND:${fmt(appointment.endsAt)}`,
      `SUMMARY:${esc(title + " — " + clinic.practice)}`, `LOCATION:${esc(clinic.address)}`, `DESCRIPTION:${esc(`Ref ${appointment.reference}`)}`,
      "BEGIN:VALARM", "TRIGGER:-PT2H", "ACTION:DISPLAY", `DESCRIPTION:${esc(title)}`, "END:VALARM", "END:VEVENT", "END:VCALENDAR"].join("\r\n");
    return new Response(ics, { headers: { "Content-Type": "text/calendar; charset=utf-8", "Content-Disposition": `attachment; filename="appuntamento-${appointment.reference}.ics"` } });
  } catch (e) {
    if (e instanceof BookingError) return new Response("Not found", { status: 404 });
    throw e;
  }
}
