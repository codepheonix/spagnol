import { NextResponse } from "next/server";
import { DateTime } from "luxon";
import { eq, or } from "drizzle-orm";
import { getDb, schema } from "@/db";
import { loadAvailabilityContext, slotsForDay, busyIntervals, BookingError } from "@/lib/booking";
import { daySummary } from "@/lib/availability";
import { clientIp, rateLimit } from "@/lib/ratelimit";

export const dynamic = "force-dynamic";

/** Public availability. Returns only free times — never appointment or patient details. */
export async function GET(req: Request) {
  if (!rateLimit(`avail:${clientIp(req)}`, 240, 60_000).ok) return NextResponse.json({ error: "rate_limited" }, { status: 429 });
  const url = new URL(req.url);
  const serviceKey = url.searchParams.get("service") ?? "";
  const month = url.searchParams.get("month");
  const date = url.searchParams.get("date");
  const db = await getDb();
  const service = await db.query.services.findFirst({ where: or(eq(schema.services.slug, serviceKey), eq(schema.services.id, serviceKey)) });
  if (!service || !service.active) return NextResponse.json({ error: "service_not_found" }, { status: 404 });

  try {
    if (date) {
      // "exclude" lets a patient propose a new time for their own appointment without colliding with it
      const exclude = url.searchParams.get("exclude") ?? undefined;
      const { slots } = await slotsForDay(service.id, date, { excludeAppointmentId: exclude });
      return NextResponse.json({ date, slots: slots.map((s) => ({ start: s.start.toISOString(), label: s.label })) }, { headers: { "Cache-Control": "no-store" } });
    }
    const m = DateTime.fromFormat(month ?? DateTime.now().toFormat("yyyy-MM"), "yyyy-MM", { zone: "Europe/Rome" });
    if (!m.isValid) return NextResponse.json({ error: "bad_month" }, { status: 400 });
    const ctx = await loadAvailabilityContext((await import("@/lib/settings")).BookingPolicy.parse({}).providerId);
    const zone = ctx.policy.timezone;
    const start = m.setZone(zone).startOf("month"), end = m.setZone(zone).endOf("month");
    const busy = await busyIntervals(db, ctx.policy.providerId, start.toJSDate(), end.toJSDate());
    const days: Record<string, string> = {};
    for (let d = start; d <= end; d = d.plus({ days: 1 })) {
      const iso = d.toISODate()!;
      days[iso] = daySummary({ dateISO: iso, service, hours: ctx.hours, exceptions: ctx.exceptions, busy, policy: ctx.policy });
    }
    return NextResponse.json({ month: m.toFormat("yyyy-MM"), timezone: zone, days, policy: { horizonDays: ctx.policy.horizonDays, cancelCutoffHours: ctx.policy.cancelCutoffHours } }, { headers: { "Cache-Control": "no-store" } });
  } catch (e) {
    if (e instanceof BookingError) return NextResponse.json({ error: e.code }, { status: 400 });
    throw e;
  }
}
