import { NextResponse, after } from "next/server";
import { z } from "zod";
import { flushDb } from "@/db";
import { findByManageToken, getAppointmentFull, cancelAppointment, rescheduleAppointment, BookingError } from "@/lib/booking";
import { getSetting } from "@/lib/settings";
import { processNotificationJobs } from "@/lib/notify/worker";
import { clientIp, rateLimit } from "@/lib/ratelimit";

export const dynamic = "force-dynamic";
type Ctx = { params: Promise<{ ref: string }> };

async function load(ref: string, token: string | null) {
  if (!token) throw new BookingError("not_found");
  const appt = await findByManageToken(ref, token);
  const full = await getAppointmentFull(appt.id);
  const policy = await getSetting("bookingPolicy");
  const now = Date.now();
  return {
    reference: full.appointment.reference, status: full.appointment.status, start: full.appointment.startsAt.toISOString(), end: full.appointment.endsAt.toISOString(),
    service: { id: full.service.id, slug: full.service.slug, titleIt: full.service.titleIt, titleEn: full.service.titleEn, durationMin: full.service.durationMin },
    patientFirst: full.patient.name.split(" ")[0],
    canCancel: full.appointment.startsAt.getTime() - now > policy.cancelCutoffHours * 3_600_000,
    canReschedule: full.appointment.startsAt.getTime() - now > policy.rescheduleCutoffHours * 3_600_000,
    id: full.appointment.id,
  };
}

export async function GET(req: Request, { params }: Ctx) {
  if (!rateLimit(`manage:${clientIp(req)}`, 60, 60_000).ok) return NextResponse.json({ error: "rate_limited" }, { status: 429 });
  const { ref } = await params;
  try {
    const { id: _id, ...data } = await load(ref, new URL(req.url).searchParams.get("t"));
    void _id;
    return NextResponse.json(data, { headers: { "Cache-Control": "no-store" } });
  } catch (e) {
    if (e instanceof BookingError) return NextResponse.json({ error: e.code }, { status: 404 });
    throw e;
  }
}

const Action = z.discriminatedUnion("action", [
  z.object({ action: z.literal("cancel") }),
  z.object({ action: z.literal("reschedule"), start: z.string().datetime({ offset: true }) }),
]);

export async function POST(req: Request, { params }: Ctx) {
  if (!rateLimit(`manage:${clientIp(req)}`, 20, 60_000).ok) return NextResponse.json({ error: "rate_limited" }, { status: 429 });
  const { ref } = await params;
  const body = Action.safeParse(await req.json().catch(() => null));
  if (!body.success) return NextResponse.json({ error: "invalid" }, { status: 400 });
  try {
    const data = await load(ref, new URL(req.url).searchParams.get("t"));
    const updated = body.data.action === "cancel" ? await cancelAppointment(data.id) : await rescheduleAppointment(data.id, body.data.start);
    await flushDb();
    after(() => processNotificationJobs().catch(() => {}));
    return NextResponse.json({ status: updated.status, start: updated.startsAt.toISOString() });
  } catch (e) {
    if (e instanceof BookingError) return NextResponse.json({ error: e.code }, { status: e.code === "not_found" ? 404 : e.code === "slot_taken" ? 409 : 400 });
    throw e;
  }
}
