import { NextResponse } from "next/server";
import { createHmac, timingSafeEqual } from "node:crypto";
import { eq } from "drizzle-orm";
import { getDb, schema } from "@/db";

export const dynamic = "force-dynamic";

/** Meta webhook verification handshake. */
export async function GET(req: Request) {
  const u = new URL(req.url);
  if (u.searchParams.get("hub.mode") === "subscribe" && u.searchParams.get("hub.verify_token") === process.env.WHATSAPP_VERIFY_TOKEN) {
    return new Response(u.searchParams.get("hub.challenge") ?? "", { status: 200 });
  }
  return new Response("forbidden", { status: 403 });
}

/** Delivery status updates. Idempotent: each Meta event id is stored once. */
export async function POST(req: Request) {
  const raw = await req.text();
  const secret = process.env.WHATSAPP_APP_SECRET;
  if (secret) {
    const sig = req.headers.get("x-hub-signature-256") ?? "";
    const expected = "sha256=" + createHmac("sha256", secret).update(raw).digest("hex");
    if (sig.length !== expected.length || !timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return new Response("bad signature", { status: 401 });
  }
  const body = JSON.parse(raw || "{}");
  const db = await getDb();
  for (const entry of body.entry ?? []) {
    for (const change of entry.changes ?? []) {
      for (const st of change.value?.statuses ?? []) {
        const eventId = `${st.id}:${st.status}:${st.timestamp}`;
        const inserted = await db.insert(schema.webhookEvents).values({ id: eventId, provider: "whatsapp", payload: st }).onConflictDoNothing().returning();
        if (!inserted.length) continue; // duplicate delivery
        if (st.status === "failed") {
          await db.update(schema.notificationJobs).set({ status: "failed", lastError: JSON.stringify(st.errors ?? st).slice(0, 1000) }).where(eq(schema.notificationJobs.providerMessageId, st.id));
        }
      }
    }
  }
  return NextResponse.json({ ok: true });
}
