import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { getDb } from "@/db";
import { latestSnapshot, snapshotEnabled } from "@/db/blob-snapshot";

export const dynamic = "force-dynamic";
/** Diagnostics for the demo snapshot store (admin only). */
export async function GET() {
  if (!(await getSession())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  await getDb();
  const st = globalThis.__saraSnap;
  return NextResponse.json({ snapshotMode: snapshotEnabled(), loaded: st?.loaded ?? null, pushing: !!st?.pushing, checkedAt: st?.checkedAt ?? null, latest: snapshotEnabled() ? (await latestSnapshot())?.pathname ?? null : null, instance: process.env.VERCEL_DEPLOYMENT_ID ?? null, pid: process.pid, up: Math.round(process.uptime()) }, { headers: { "Cache-Control": "no-store" } });
}
