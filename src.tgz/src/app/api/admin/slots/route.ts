import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { slotsForDay, BookingError } from "@/lib/booking";

export const dynamic = "force-dynamic";
/** Admin slots: same engine, but bypasses minimum notice / horizon so Sara can book by phone for today. */
export async function GET(req: Request) {
  if (!(await getSession())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const u = new URL(req.url);
  try {
    const { slots } = await slotsForDay(u.searchParams.get("service") ?? "", u.searchParams.get("date") ?? "", { admin: true, excludeAppointmentId: u.searchParams.get("exclude") ?? undefined });
    return NextResponse.json({ slots: slots.map((s) => ({ start: s.start.toISOString(), label: s.label })) });
  } catch (e) { if (e instanceof BookingError) return NextResponse.json({ error: e.code }, { status: 400 }); throw e; }
}
