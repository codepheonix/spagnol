import { NextResponse } from "next/server";
import { count, eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { getDb, schema } from "@/db";
import { getSetting } from "@/lib/settings";
import { ringingCalls, unreadCount } from "@/lib/care";

export const dynamic = "force-dynamic";
export async function GET() {
  if (!(await getSession())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const db = await getDb();
  const [{ n }] = await db.select({ n: count() }).from(schema.adminNotifications).where(eq(schema.adminNotifications.read, false));
  const s = await getSetting("notifications");
  const [calls, chat] = await Promise.all([ringingCalls(), unreadCount(null, "admin")]);
  const ringing = calls.filter((c) => c.c.status === "ringing" && c.c.startedBy === "patient").map((c) => ({ id: c.c.id, patient: c.p.name, patientId: c.p.id }));
  return NextResponse.json({ unread: Number(n), chat, ringing, sound: s.dashboardSound }, { headers: { "Cache-Control": "no-store" } });
}
