import { NextResponse } from "next/server";
import { processNotificationJobs } from "@/lib/notify/worker";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/** Called by Vercel Cron (see vercel.json) or any scheduler. Protect with CRON_SECRET. */
export async function GET(req: Request) {
  const secret = process.env.CRON_SECRET;
  const auth = req.headers.get("authorization");
  if (secret && auth !== `Bearer ${secret}`) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const r = await processNotificationJobs(50);
  return NextResponse.json(r);
}
