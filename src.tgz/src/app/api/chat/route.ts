import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { getPatientSession } from "@/lib/patient-auth";
import { thread, sendMessage, markRead, activeCall } from "@/lib/care";
import { processNotificationJobs } from "@/lib/notify/worker";
import { flushDb } from "@/db";
import { clientIp, rateLimit } from "@/lib/ratelimit";

export const dynamic = "force-dynamic";

async function who(req: Request) {
  const admin = await getSession();
  if (admin) return { role: "admin" as const, patientId: new URL(req.url).searchParams.get("patient") ?? "" };
  const p = await getPatientSession();
  if (p) return { role: "patient" as const, patientId: p.sub };
  return null;
}

/** GET ?since=ISO → new messages for the thread (+ an incoming call, if any). Polled every few seconds by the chat UI. */
export async function GET(req: Request) {
  const me = await who(req);
  if (!me || !me.patientId) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const since = new URL(req.url).searchParams.get("since") ?? undefined;
  const [messages, call] = await Promise.all([thread(me.patientId, since), activeCall(me.patientId)]);
  if (messages.some((m) => m.sender !== me.role && !m.readAt)) await markRead(me.patientId, me.role);
  return NextResponse.json({ messages, call: call ? { id: call.id, status: call.status, startedBy: call.startedBy } : null, now: new Date().toISOString() }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(req: Request) {
  if (!rateLimit(`chat:${clientIp(req)}`, 60, 60_000).ok) return NextResponse.json({ error: "rate_limited" }, { status: 429 });
  const me = await who(req);
  const body = (await req.json().catch(() => ({}))) as { body?: string; patient?: string; attachments?: { url: string; name: string; size: number; type: string }[]; replyToId?: string };
  const patientId = me?.role === "admin" ? body.patient ?? "" : me?.patientId ?? "";
  if (!me || !patientId) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  try {
    const atts = (body.attachments ?? []).filter((a) => typeof a?.url === "string" && a.url.includes(".blob.vercel-storage.com/")).map((a) => ({ url: a.url, name: String(a.name).slice(0, 120), size: Number(a.size) || 0, type: String(a.type) }));
    const m = await sendMessage(patientId, me.role, String(body.body ?? ""), { attachments: atts, replyToId: body.replyToId });
    processNotificationJobs().catch(() => {});
    await flushDb();
    return NextResponse.json({ message: m });
  } catch { return NextResponse.json({ error: "empty" }, { status: 400 }); }
}
