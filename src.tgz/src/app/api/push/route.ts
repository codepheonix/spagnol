import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { getPatientSession } from "@/lib/patient-auth";
import { saveSubscription, removeSubscription, pushConfigured } from "@/lib/push";
import { flushDb } from "@/db";

export const dynamic = "force-dynamic";
async function who() { const a = await getSession(); if (a) return { type: "admin" as const, id: a.sub }; const p = await getPatientSession(); if (p) return { type: "patient" as const, id: p.sub }; return null; }

export async function GET() { return NextResponse.json({ enabled: pushConfigured(), publicKey: process.env.VAPID_PUBLIC_KEY ?? null }); }

export async function POST(req: Request) {
  const me = await who(); if (!me) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sub = (await req.json().catch(() => null)) as { endpoint?: string; keys?: { p256dh: string; auth: string } } | null;
  if (!sub?.endpoint || !sub.keys) return NextResponse.json({ error: "invalid" }, { status: 400 });
  await saveSubscription(me.type, me.id, { endpoint: sub.endpoint, keys: sub.keys }); await flushDb();
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: Request) {
  const me = await who(); if (!me) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const { endpoint } = (await req.json().catch(() => ({}))) as { endpoint?: string };
  if (endpoint) { await removeSubscription(endpoint); await flushDb(); }
  return NextResponse.json({ ok: true });
}
