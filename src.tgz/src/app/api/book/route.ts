import { NextResponse, after } from "next/server";
import { z } from "zod";
import { eq, or } from "drizzle-orm";
import { getDb, schema, flushDb } from "@/db";
import { bookAppointment, BookingError } from "@/lib/booking";
import { processNotificationJobs } from "@/lib/notify/worker";
import { clientIp, rateLimit } from "@/lib/ratelimit";

export const dynamic = "force-dynamic";

const Body = z.object({
  service: z.string().min(1),
  start: z.string().datetime({ offset: true }),
  name: z.string().trim().min(2).max(80),
  email: z.string().trim().email().max(120),
  phone: z.string().trim().regex(/^\+?[0-9 ()\-]{7,20}$/),
  locale: z.enum(["it", "en"]).default("it"),
  smsOptIn: z.boolean().optional(),
  notes: z.string().max(500).optional(),
  consent: z.literal(true),
  website: z.string().max(0).optional(), // honeypot
});

export async function POST(req: Request) {
  if (!rateLimit(`book:${clientIp(req)}`, 10, 10 * 60_000).ok) return NextResponse.json({ error: "rate_limited" }, { status: 429 });
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "invalid", issues: parsed.error.flatten().fieldErrors }, { status: 400 });
  const b = parsed.data;
  const db = await getDb();
  const service = await db.query.services.findFirst({ where: or(eq(schema.services.slug, b.service), eq(schema.services.id, b.service)) });
  if (!service || !service.active) return NextResponse.json({ error: "service_not_found" }, { status: 404 });
  try {
    const r = await bookAppointment({ serviceId: service.id, startISO: b.start, patient: { name: b.name, email: b.email, phone: b.phone, locale: b.locale, smsOptIn: b.smsOptIn, notes: b.notes } });
    after(() => processNotificationJobs().catch((e) => console.error("notify", e))); // send after the response; the booking is already committed
    await flushDb();
    return NextResponse.json({ reference: r.appointment.reference, token: r.manageToken, status: r.appointment.status, start: r.appointment.startsAt.toISOString() });
  } catch (e) {
    if (e instanceof BookingError) return NextResponse.json({ error: e.code }, { status: e.code === "slot_taken" ? 409 : 400 });
    console.error(e);
    return NextResponse.json({ error: "server" }, { status: 500 });
  }
}
