import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { getPatientSession } from "@/lib/patient-auth";
import { clientIp, rateLimit } from "@/lib/ratelimit";

export const dynamic = "force-dynamic";
const ALLOWED = new Set(["image/jpeg", "image/png", "image/webp", "image/heic", "application/pdf"]);
const MAX = 10 * 1024 * 1024;

/** Chat attachments → Vercel Blob (unguessable URLs, scoped per patient). Allowed: images and PDF, max 10 MB. */
export async function POST(req: Request) {
  if (!rateLimit(`upload:${clientIp(req)}`, 30, 10 * 60_000).ok) return NextResponse.json({ error: "rate_limited" }, { status: 429 });
  const admin = await getSession(); const patient = admin ? null : await getPatientSession();
  if (!admin && !patient) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const token = process.env.BLOB_READ_WRITE_TOKEN;
  if (!token) return NextResponse.json({ error: "storage_not_configured" }, { status: 503 });
  const form = await req.formData();
  const file = form.get("file"); const scope = String(form.get("patient") ?? patient?.sub ?? "shared").replace(/[^a-zA-Z0-9-]/g, "");
  if (!(file instanceof File)) return NextResponse.json({ error: "no_file" }, { status: 400 });
  if (!ALLOWED.has(file.type) || file.size > MAX) return NextResponse.json({ error: "unsupported" }, { status: 415 });
  const safe = file.name.replace(/[^\w.\-]+/g, "_").slice(0, 80);
  const r = await fetch(`https://blob.vercel-storage.com/uploads/${scope}/${safe}`, { method: "PUT", headers: { Authorization: `Bearer ${token}`, "x-api-version": "7", "x-add-random-suffix": "1", "content-type": file.type }, body: file });
  if (!r.ok) return NextResponse.json({ error: "upload_failed" }, { status: 502 });
  const j = (await r.json()) as { url: string };
  return NextResponse.json({ url: j.url, name: file.name, size: file.size, type: file.type });
}
