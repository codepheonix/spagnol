import type { MetadataRoute } from "next";
import { appUrl } from "@/lib/url";
export default function sitemap(): MetadataRoute.Sitemap {
  const base = appUrl();
  return ["", "/book", "/privacy", "/cookies", "/terms"].flatMap((p) => ["it", "en"].map((l) => ({ url: `${base}/${l}${p}`, changeFrequency: "weekly" as const, priority: p === "" ? 1 : 0.6 })));
}
