import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { getTranslations, setRequestLocale } from "next-intl/server";
import { count, eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { getDb, schema } from "@/db";
import { seedIfEmpty } from "@/db/seed";
import AdminShell from "@/components/admin/AdminShell";
import { openRequests, unreadCount } from "@/lib/care";

export const dynamic = "force-dynamic";

export default async function AdminLayout({ children, params }: { children: ReactNode; params: Promise<{ locale: string }> }) {
  const { locale } = await params; setRequestLocale(locale);
  await seedIfEmpty();
  const session = await getSession();
  if (!session) redirect(`/${locale}/app/login`);
  const t = await getTranslations("admin.nav");
  const db = await getDb();
  const [{ n }] = await db.select({ n: count() }).from(schema.adminNotifications).where(eq(schema.adminNotifications.read, false));
  const [req, chat, c] = await Promise.all([openRequests(), unreadCount(null, "admin"), getTranslations("admin.calls")]);
  const nav = [
    ["", t("overview")], ["/requests", t("requests")], ["/calendar", t("calendar")], ["/appointments", t("appointments")], ["/messages", t("messages")], ["/calls", t("calls")],
    ["/availability", t("availability")], ["/patients", t("patients")], ["/content", t("content")], ["/settings", t("settings")],
  ] as [string, string][];
  return <AdminShell nav={nav} unread={Number(n)} counts={{ requests: req.appointments.length + req.reschedules.length, chat }} user={session.name} labels={{ logout: t("logout"), site: t("site"), newBooking: t("newBooking"), incoming: c("incoming"), answer: c("answer") }}>{children}</AdminShell>;
}
