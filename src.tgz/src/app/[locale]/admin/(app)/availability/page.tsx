import { getTranslations, setRequestLocale } from "next-intl/server";
import { asc, gte } from "drizzle-orm";
import { DateTime } from "luxon";
import { getDb, schema } from "@/db";
import AvailabilityEditor from "@/components/admin/AvailabilityEditor";

export default async function AvailabilityPage({ params }: { params: Promise<{ locale: "it" | "en" }> }) {
  const { locale } = await params; setRequestLocale(locale);
  const t = await getTranslations("admin.avail");
  const db = await getDb();
  const hours = await db.query.workingHours.findMany({ orderBy: [asc(schema.workingHours.weekday), asc(schema.workingHours.startTime)] });
  const exceptions = await db.query.availabilityExceptions.findMany({ where: gte(schema.availabilityExceptions.date, DateTime.now().minus({ days: 7 }).toISODate()!), orderBy: asc(schema.availabilityExceptions.date) });
  return (
    <div className="grid gap-6">
      <h1 className="display text-3xl">{t("title")}</h1>
      <AvailabilityEditor hours={hours.map((h) => ({ weekday: h.weekday, startTime: h.startTime.slice(0, 5), endTime: h.endTime.slice(0, 5) }))}
        exceptions={exceptions.map((e) => ({ id: e.id, date: e.date, kind: e.kind, startTime: e.startTime?.slice(0, 5) ?? null, endTime: e.endTime?.slice(0, 5) ?? null, note: e.note }))} />
    </div>
  );
}
