import { getTranslations, setRequestLocale } from "next-intl/server";
import { asc } from "drizzle-orm";
import { getDb, schema } from "@/db";
import { ringingCalls, callHistory, callProvider } from "@/lib/care";
import AdminCalls from "@/components/admin/AdminCalls";

export default async function Calls({ params, searchParams }: { params: Promise<{ locale: "it" | "en" }>; searchParams: Promise<{ answer?: string; call?: string }> }) {
  const { locale } = await params; const sp = await searchParams; setRequestLocale(locale);
  const t = await getTranslations("admin.calls");
  const db = await getDb();
  const [live, history, patients] = await Promise.all([ringingCalls(), callHistory(), db.query.patients.findMany({ orderBy: asc(schema.patients.name), limit: 500 })]);
  const labels = { title: t("title"), incoming: t("incoming"), none: t("none"), history: t("history"), answer: t("answer"), decline: t("decline"), start: t("start"), pick: t("pick"), demo: t("demo"), calling: t("calling", { name: "{name}" }),
    status: { ringing: t("status.ringing"), active: t("status.active"), ended: t("status.ended"), missed: t("status.missed"), declined: t("status.declined") } };
  const c = await getTranslations("app.call");
  const panel = { ringing: c("ringing"), connecting: c("connecting"), active: c("active"), ended: c("ended"), missed: c("missed"), declined: c("declined"), hangup: c("hangup"), mute: c("mute"), unmute: c("unmute"), micDenied: c("micDenied"), demo: t("demo") };
  return <AdminCalls provider={callProvider()} live={live.map(({ c, p }) => ({ id: c.id, status: c.status, startedBy: c.startedBy, patient: p.name, patientId: p.id, createdAt: c.createdAt.toISOString() }))}
    history={history.map(({ c, p }) => ({ id: c.id, status: c.status, patient: p.name, createdAt: c.createdAt.toISOString(), seconds: c.answeredAt && c.endedAt ? Math.round((c.endedAt.getTime() - c.answeredAt.getTime()) / 1000) : 0 }))}
    patients={patients.map((p) => ({ id: p.id, name: p.name }))} answer={sp.answer ?? null} callPatient={sp.call ?? null} labels={labels} panel={panel} />;
}
