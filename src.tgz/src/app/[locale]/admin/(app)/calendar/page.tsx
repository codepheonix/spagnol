import { getTranslations, setRequestLocale } from "next-intl/server";
import { DateTime } from "luxon";
import { and, gte, lte } from "drizzle-orm";
import { appointmentsBetween } from "@/lib/admin-queries";
import { getSetting } from "@/lib/settings";
import { getDb, schema } from "@/db";
import CalendarView from "@/components/admin/CalendarView";

export default async function CalendarPage({ params, searchParams }: { params: Promise<{ locale: "it" | "en" }>; searchParams: Promise<{ view?: string; date?: string }> }) {
  const { locale } = await params; setRequestLocale(locale);
  const sp = await searchParams;
  const policy = await getSetting("bookingPolicy");
  const view = (["day", "week", "month"].includes(sp.view ?? "") ? sp.view : "week") as "day" | "week" | "month";
  const anchor = (sp.date ? DateTime.fromISO(sp.date, { zone: policy.timezone }) : DateTime.now().setZone(policy.timezone)).startOf("day");
  const start = view === "day" ? anchor : view === "week" ? anchor.startOf("week") : anchor.startOf("month").startOf("week");
  const end = view === "day" ? anchor.endOf("day") : view === "week" ? anchor.endOf("week") : anchor.endOf("month").endOf("week");
  const rows = await appointmentsBetween(start.toJSDate(), end.toJSDate());
  const db = await getDb();
  const exceptions = await db.query.availabilityExceptions.findMany({ where: and(gte(schema.availabilityExceptions.date, start.toISODate()!), lte(schema.availabilityExceptions.date, end.toISODate()!)) });
  const hours = await db.query.workingHours.findMany();
  const t = await getTranslations("admin.calendar");
  return (
    <CalendarView view={view} anchorISO={anchor.toISODate()!} timezone={policy.timezone}
      labels={{ day: t("day"), week: t("week"), month: t("month"), today: t("today"), prev: t("prev"), next: t("next"), none: t("noAppointments"), blocked: t("blocked") }}
      events={rows.map(({ a, p, s }) => ({ id: a.id, start: a.startsAt.toISOString(), end: a.endsAt.toISOString(), status: a.status, title: p.name, sub: locale === "it" ? s.titleIt : s.titleEn }))}
      exceptions={exceptions.map((e) => ({ date: e.date, kind: e.kind, startTime: e.startTime, endTime: e.endTime, note: e.note }))}
      hours={hours.map((h) => ({ weekday: h.weekday, startTime: h.startTime, endTime: h.endTime }))} />
  );
}
