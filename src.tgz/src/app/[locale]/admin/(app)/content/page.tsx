import { getTranslations, setRequestLocale } from "next-intl/server";
import { asc } from "drizzle-orm";
import { getDb, schema } from "@/db";
import { getSetting } from "@/lib/settings";
import ContentEditor from "@/components/admin/ContentEditor";

export default async function ContentPage({ params }: { params: Promise<{ locale: "it" | "en" }> }) {
  const { locale } = await params; setRequestLocale(locale);
  const t = await getTranslations("admin.content");
  const db = await getDb();
  const services = await db.query.services.findMany({ orderBy: asc(schema.services.sort) });
  const clinic = await getSetting("clinicInfo");
  return <div className="grid gap-6"><h1 className="display text-3xl">{t("title")}</h1><ContentEditor services={services} clinic={clinic} /></div>;
}
