import { getTranslations, setRequestLocale } from "next-intl/server";
import { notFound } from "next/navigation";
import { DateTime } from "luxon";
import { desc, eq, or } from "drizzle-orm";
import { getDb, schema } from "@/db";
import { Link } from "@/i18n/navigation";
import StatusChip from "@/components/admin/StatusChip";

export default async function PatientDetail({ params }: { params: Promise<{ locale: "it" | "en"; id: string }> }) {
  const { locale, id } = await params; setRequestLocale(locale);
  const t = await getTranslations("admin.patients");
  const db = await getDb();
  const p = await db.query.patients.findFirst({ where: eq(schema.patients.id, id) });
  if (!p) notFound();
  const rows = await db.select({ a: schema.appointments, s: schema.services }).from(schema.appointments)
    .innerJoin(schema.patients, eq(schema.appointments.patientId, schema.patients.id)).innerJoin(schema.services, eq(schema.appointments.serviceId, schema.services.id))
    .where(or(eq(schema.patients.email, p.email), eq(schema.patients.phone, p.phone))).orderBy(desc(schema.appointments.startsAt));
  return (
    <div className="grid gap-6">
      <div className="card p-6"><h1 className="display text-3xl">{p.name}</h1><p className="mt-2 text-ink-2">{p.email} · <a href={`tel:${p.phone}`}>{p.phone}</a> · {p.locale.toUpperCase()}{p.smsOptIn ? " · SMS ✓" : ""}</p></div>
      <div className="card p-6">
        <h2 className="mb-3 font-semibold">{t("history")}</h2>
        <ul className="divide-y divide-line text-sm">
          {rows.map(({ a, s }) => <li key={a.id} className="flex items-center justify-between gap-3 py-2"><Link href={`/admin/appointments/${a.id}`} className="no-underline"><strong>{DateTime.fromJSDate(a.startsAt, { zone: "Europe/Rome" }).setLocale(locale).toFormat("ccc d LLL yyyy · HH:mm")}</strong> · {locale === "it" ? s.titleIt : s.titleEn}</Link><StatusChip status={a.status} /></li>)}
        </ul>
      </div>
    </div>
  );
}
