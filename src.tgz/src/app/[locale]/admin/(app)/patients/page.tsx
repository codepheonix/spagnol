import { getTranslations, setRequestLocale } from "next-intl/server";
import { DateTime } from "luxon";
import { count, desc, eq, ilike, max, or, sql } from "drizzle-orm";
import { getDb, schema } from "@/db";
import { Link } from "@/i18n/navigation";

export default async function PatientsPage({ params, searchParams }: { params: Promise<{ locale: "it" | "en" }>; searchParams: Promise<{ q?: string }> }) {
  const { locale } = await params; setRequestLocale(locale);
  const { q } = await searchParams;
  const t = await getTranslations("admin.patients");
  const db = await getDb();
  // One row per contact (email+phone), latest name wins.
  const rows = await db.select({ email: schema.patients.email, phone: schema.patients.phone, name: max(schema.patients.name), n: count(schema.appointments.id), last: max(schema.appointments.startsAt), id: max(schema.patients.id) })
    .from(schema.patients).leftJoin(schema.appointments, eq(schema.appointments.patientId, schema.patients.id))
    .where(q ? or(ilike(schema.patients.name, `%${q}%`), ilike(schema.patients.email, `%${q}%`), ilike(schema.patients.phone, `%${q}%`)) : sql`${schema.patients.email} not like 'noemail+%'`)
    .groupBy(schema.patients.email, schema.patients.phone).orderBy(desc(max(schema.appointments.startsAt))).limit(300);
  return (
    <div className="grid gap-5">
      <h1 className="display text-3xl">{t("title")}</h1>
      <form className="card flex gap-3 p-4"><input name="q" defaultValue={q} className="input" placeholder={t("search")} /><button className="btn btn-ghost btn-sm" type="submit">OK</button></form>
      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-left text-xs uppercase tracking-widest text-muted"><tr><th className="p-3">{t("name")}</th><th className="p-3">{t("email")}</th><th className="p-3">{t("phone")}</th><th className="p-3">{t("count")}</th><th className="p-3">{t("last")}</th></tr></thead>
          <tbody className="divide-y divide-line">
            {rows.map((r) => (
              <tr key={r.email + r.phone} className="hover:bg-bg-2">
                <td className="p-3 font-semibold"><Link href={`/admin/patients/${r.id}`} className="no-underline">{r.name}</Link></td><td className="p-3">{r.email}</td><td className="p-3">{r.phone}</td><td className="p-3">{r.n}</td>
                <td className="p-3 text-muted">{r.last ? DateTime.fromJSDate(r.last).setLocale(locale).toFormat("d LLL yyyy") : "—"}</td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td className="p-4 text-muted" colSpan={5}>{t("empty")}</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
