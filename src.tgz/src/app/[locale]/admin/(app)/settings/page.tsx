import { getTranslations, setRequestLocale } from "next-intl/server";
import { desc, eq } from "drizzle-orm";
import { getDb, schema } from "@/db";
import { getSetting } from "@/lib/settings";
import { requireSession } from "@/lib/auth";
import PushButton from "@/components/PushButton";
import SettingsForm from "@/components/admin/SettingsForm";

export default async function SettingsPage({ params }: { params: Promise<{ locale: "it" | "en" }> }) {
  const { locale } = await params; setRequestLocale(locale);
  const t = await getTranslations("admin.settings");
  const session = await requireSession();
  const db = await getDb();
  const [policy, notif, admin, jobs] = await Promise.all([getSetting("bookingPolicy"), getSetting("notifications"), db.query.admins.findFirst({ where: eq(schema.admins.id, session.sub) }), db.query.notificationJobs.findMany({ orderBy: desc(schema.notificationJobs.createdAt), limit: 50 })]);
  const providers = {
    whatsapp: !!(process.env.WHATSAPP_TOKEN && process.env.WHATSAPP_PHONE_NUMBER_ID) && process.env.NOTIFICATIONS_MODE !== "mock",
    email: !!process.env.RESEND_API_KEY && process.env.NOTIFICATIONS_MODE !== "mock",
    sms: !!(process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN && process.env.TWILIO_FROM) && process.env.NOTIFICATIONS_MODE !== "mock",
  };
  return <div className="grid gap-6"><h1 className="display text-3xl">{t("title")}</h1><section className="card p-5"><h2 className="font-semibold">{t("push.title")}</h2><div className="mt-3"><PushButton labels={{ on: t("push.on"), off: t("push.off"), unsupported: t("push.unsupported") }} /></div></section><SettingsForm policy={policy} notif={notif} totpEnabled={!!admin?.totpSecret} providers={providers} jobs={jobs.map((j) => ({ id: j.id, channel: j.channel, template: j.template, recipient: j.recipient, status: j.status, attempts: j.attempts, lastError: j.lastError, createdAt: j.createdAt.toISOString() }))} /></div>;
}
