import { getTranslations, setRequestLocale } from "next-intl/server";
import { Link } from "@/i18n/navigation";
import { openRequests } from "@/lib/care";
import { getSetting } from "@/lib/settings";
import { formatInZone } from "@/lib/availability";
import RequestActions from "@/components/admin/RequestActions";
import { fmtDate } from "@/lib/fmt";

export default async function Requests({ params }: { params: Promise<{ locale: "it" | "en" }> }) {
  const { locale } = await params; setRequestLocale(locale);
  const [t, req, policy] = await Promise.all([getTranslations("admin.requests"), openRequests(), getSetting("bookingPolicy")]);
  const f = (d: Date) => { const w = formatInZone(d, policy.timezone, locale); return `${w.date} · ${w.time}`; };
  const empty = req.appointments.length === 0 && req.reschedules.length === 0;
  return (
    <div className="grid gap-8">
      <div><h1 className="display text-4xl">{t("title")}</h1><p className="mt-2 text-ink-2">{t("lead")}</p></div>
      {empty && <p className="card p-8 text-center text-muted">{t("empty")}</p>}
      {req.appointments.length > 0 && (
        <section><h2 className="eyebrow mb-3">{t("appointments")} · {req.appointments.length}</h2>
          <ul className="grid gap-3">{req.appointments.map(({ a, p, s }) => (
            <li key={a.id} className="card grid gap-4 p-5 lg:grid-cols-[1fr_auto] lg:items-center">
              <div>
                <p className="font-semibold"><Link href={`/admin/patients/${p.id}`} className="no-underline hover:text-accent">{p.name}</Link> · {locale === "it" ? s.titleIt : s.titleEn}</p>
                <p className="mt-1 text-sm text-ink-2">{f(a.startsAt)} · {s.durationMin} min · {p.phone}</p>
                {a.patientNotes && <p className="mt-2 rounded-xl bg-bg-2 p-3 text-sm"><span className="text-xs font-semibold uppercase tracking-wider text-muted">{t("note")}</span><br />{a.patientNotes}</p>}
                <p className="mt-1 text-xs text-muted">{t("requested")} {fmtDate(a.bookedAt, locale, { dateStyle: "medium", timeStyle: "short" })}</p>
              </div>
              <RequestActions kind="appointment" id={a.id} patientId={p.id} labels={{ approve: t("approve"), decline: t("decline"), chat: t("openChat") }} />
            </li>))}</ul>
        </section>)}
      {req.reschedules.length > 0 && (
        <section><h2 className="eyebrow mb-3">{t("reschedules")} · {req.reschedules.length}</h2>
          <ul className="grid gap-3">{req.reschedules.map(({ r, a, p, s }) => (
            <li key={r.id} className="card grid gap-4 p-5 lg:grid-cols-[1fr_auto] lg:items-center">
              <div>
                <p className="font-semibold"><Link href={`/admin/patients/${p.id}`} className="no-underline hover:text-accent">{p.name}</Link> · {locale === "it" ? s.titleIt : s.titleEn}</p>
                <p className="mt-1 text-sm text-ink-2"><span className="text-muted">{t("from")}</span> {f(a.startsAt)} <span className="text-muted">→ {t("proposed").toLowerCase()}</span> <strong>{f(r.proposedStartsAt)}</strong></p>
                {r.note && <p className="mt-2 rounded-xl bg-bg-2 p-3 text-sm">{r.note}</p>}
              </div>
              <RequestActions kind="reschedule" id={r.id} patientId={p.id} labels={{ approve: t("accept"), decline: t("decline"), chat: t("openChat") }} />
            </li>))}</ul>
        </section>)}
    </div>
  );
}
