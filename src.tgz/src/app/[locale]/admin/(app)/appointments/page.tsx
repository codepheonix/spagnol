import { getTranslations, setRequestLocale } from "next-intl/server";
import { DateTime } from "luxon";
import { and, asc, desc, eq, gte, ilike, or, type SQL } from "drizzle-orm";
import { getDb, schema } from "@/db";
import { getSetting } from "@/lib/settings";
import { Link } from "@/i18n/navigation";
import StatusChip from "@/components/admin/StatusChip";

const STATUSES = ["pending", "confirmed", "rescheduled", "completed", "cancelled", "no_show"] as const;

export default async function AppointmentsPage({ params, searchParams }: { params: Promise<{ locale: "it" | "en" }>; searchParams: Promise<{ q?: string; status?: string; upcoming?: string }> }) {
  const { locale } = await params; setRequestLocale(locale);
  const sp = await searchParams;
  const t = await getTranslations("admin.appt");
  const ts = await getTranslations("admin.status");
  const policy = await getSetting("bookingPolicy");
  const db = await getDb();
  const where: SQL[] = [];
  if (sp.q) where.push(or(ilike(schema.patients.name, `%${sp.q}%`), ilike(schema.patients.email, `%${sp.q}%`), ilike(schema.appointments.reference, `%${sp.q}%`))!);
  if (sp.status && (STATUSES as readonly string[]).includes(sp.status)) where.push(eq(schema.appointments.status, sp.status as (typeof STATUSES)[number]));
  const upcoming = sp.upcoming !== "0";
  if (upcoming) where.push(gte(schema.appointments.startsAt, DateTime.now().startOf("day").toJSDate()));
  const rows = await db.select({ a: schema.appointments, p: schema.patients, s: schema.services }).from(schema.appointments)
    .innerJoin(schema.patients, eq(schema.appointments.patientId, schema.patients.id)).innerJoin(schema.services, eq(schema.appointments.serviceId, schema.services.id))
    .where(where.length ? and(...where) : undefined).orderBy(upcoming ? asc(schema.appointments.startsAt) : desc(schema.appointments.startsAt)).limit(200);
  return (
    <div className="grid gap-5">
      <div className="flex flex-wrap items-center justify-between gap-3"><h1 className="display text-3xl">{t("list")}</h1><Link href="/admin/appointments/new" className="btn btn-solid btn-sm">+ {t("manualTitle")}</Link></div>
      <form className="card flex flex-wrap items-end gap-3 p-4">
        <div className="flex-1 min-w-[200px]"><label className="label" htmlFor="q">{t("search")}</label><input id="q" name="q" defaultValue={sp.q} className="input" /></div>
        <div><label className="label" htmlFor="status">{t("filterStatus")}</label><select id="status" name="status" defaultValue={sp.status ?? ""} className="input"><option value="">{t("all")}</option>{STATUSES.map((s) => <option key={s} value={s}>{ts(s)}</option>)}</select></div>
        <label className="flex h-12 items-center gap-2 text-sm"><input type="checkbox" name="upcoming" value="1" defaultChecked={upcoming} />{t("upcomingOnly")}<input type="hidden" name="upcoming" value="0" /></label>
        <button className="btn btn-ghost btn-sm" type="submit">OK</button>
      </form>
      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-left text-xs uppercase tracking-widest text-muted"><tr><th className="p-3">{t("when")}</th><th className="p-3">{t("patient")}</th><th className="p-3">{t("service")}</th><th className="p-3">{t("status")}</th><th className="p-3">{t("source")}</th></tr></thead>
          <tbody className="divide-y divide-line">
            {rows.map(({ a, p, s }) => (
              <tr key={a.id} className="hover:bg-bg-2">
                <td className="p-3 whitespace-nowrap"><Link href={`/admin/appointments/${a.id}`} className="font-semibold no-underline">{DateTime.fromJSDate(a.startsAt, { zone: policy.timezone }).setLocale(locale).toFormat("ccc d LLL · HH:mm")}</Link></td>
                <td className="p-3">{p.name}<br /><span className="text-muted">{p.phone}</span></td>
                <td className="p-3">{locale === "it" ? s.titleIt : s.titleEn} · {s.durationMin} {"min"}</td>
                <td className="p-3"><StatusChip status={a.status} /></td>
                <td className="p-3 text-muted">{a.source === "manual" ? t("manual") : t("online")} · {a.reference}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
