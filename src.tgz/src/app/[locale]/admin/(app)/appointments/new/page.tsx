import { getTranslations, setRequestLocale } from "next-intl/server";
import { asc } from "drizzle-orm";
import { getDb, schema } from "@/db";
import ManualBooking from "@/components/admin/ManualBooking";

export default async function NewAppointment({ params }: { params: Promise<{ locale: "it" | "en" }> }) {
  const { locale } = await params; setRequestLocale(locale);
  const t = await getTranslations("admin.appt");
  const db = await getDb();
  const services = await db.query.services.findMany({ orderBy: asc(schema.services.sort) });
  return (
    <div className="mx-auto max-w-2xl grid gap-4">
      <div><h1 className="display text-3xl">{t("manualTitle")}</h1><p className="text-muted">{t("manualHint")}</p></div>
      <ManualBooking services={services.map((s) => ({ id: s.id, title: locale === "it" ? s.titleIt : s.titleEn, durationMin: s.durationMin, active: s.active }))} />
    </div>
  );
}
