import { getTranslations, setRequestLocale } from "next-intl/server";
import { notFound } from "next/navigation";
import { DateTime } from "luxon";
import { asc, eq } from "drizzle-orm";
import { getDb, schema } from "@/db";
import { getSetting } from "@/lib/settings";
import { Link } from "@/i18n/navigation";
import StatusChip from "@/components/admin/StatusChip";
import AppointmentActions from "@/components/admin/AppointmentActions";

export default async function AppointmentDetail({ params }: { params: Promise<{ locale: "it" | "en"; id: string }> }) {
  const { locale, id } = await params; setRequestLocale(locale);
  const t = await getTranslations("admin.appt");
  const policy = await getSetting("bookingPolicy");
  const db = await getDb();
  const a = await db.query.appointments.findFirst({ where: eq(schema.appointments.id, id) });
  if (!a) notFound();
  const [p, s, events, jobs] = await Promise.all([
    db.query.patients.findFirst({ where: eq(schema.patients.id, a.patientId) }),
    db.query.services.findFirst({ where: eq(schema.services.id, a.serviceId) }),
    db.query.appointmentEvents.findMany({ where: eq(schema.appointmentEvents.appointmentId, id), orderBy: asc(schema.appointmentEvents.createdAt) }),
    db.query.notificationJobs.findMany({ where: eq(schema.notificationJobs.appointmentId, id), orderBy: asc(schema.notificationJobs.createdAt) }),
  ]);
  const when = DateTime.fromJSDate(a.startsAt, { zone: policy.timezone }).setLocale(locale);
  return (
    <div className="grid gap-6 lg:grid-cols-[1.3fr_1fr]">
      <div className="grid gap-6">
        <div className="card p-6">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div><p className="eyebrow">{a.reference}</p><h1 className="display text-3xl capitalize">{when.toFormat("cccc d LLLL · HH:mm")}</h1></div>
            <StatusChip status={a.status} />
          </div>
          <dl className="mt-6 grid gap-4 sm:grid-cols-2 text-sm">
            <div><dt className="text-xs uppercase tracking-widest text-muted">{t("patient")}</dt><dd className="text-base font-semibold"><Link href={`/admin/patients/${p!.id}`} className="no-underline">{p!.name}</Link></dd><dd className="text-muted">{p!.email}<br /><a href={`tel:${p!.phone}`}>{p!.phone}</a></dd></div>
            <div><dt className="text-xs uppercase tracking-widest text-muted">{t("service")}</dt><dd className="text-base font-semibold">{locale === "it" ? s!.titleIt : s!.titleEn}</dd><dd className="text-muted">{s!.durationMin} min{s!.bufferMin ? ` + ${s!.bufferMin}` : ""}</dd></div>
            <div><dt className="text-xs uppercase tracking-widest text-muted">{t("booked")}</dt><dd>{DateTime.fromJSDate(a.bookedAt, { zone: policy.timezone }).setLocale(locale).toFormat("d LLL yyyy HH:mm")} · {a.source === "manual" ? t("manual") : t("online")}</dd></div>
            {a.patientNotes && <div><dt className="text-xs uppercase tracking-widest text-muted">{t("patientNotes")}</dt><dd>{a.patientNotes}</dd></div>}
          </dl>
          <AppointmentActions id={a.id} status={a.status} notes={a.adminNotes ?? ""} serviceId={s!.id} startISO={a.startsAt.toISOString()} />
        </div>
      </div>
      <div className="grid gap-6 content-start">
        <div className="card p-6">
          <h2 className="mb-3 font-semibold">{t("history")}</h2>
          <ul className="grid gap-2 text-sm">
            {events.map((e) => <li key={e.id} className="flex justify-between gap-3 border-b border-line pb-2 last:border-0"><span>{e.type} <span className="text-muted">· {e.actor}</span></span><span className="text-muted whitespace-nowrap">{DateTime.fromJSDate(e.createdAt, { zone: policy.timezone }).toFormat("d LLL HH:mm")}</span></li>)}
          </ul>
        </div>
        <div className="card p-6">
          <h2 className="mb-3 font-semibold">Notifiche</h2>
          <ul className="grid gap-2 text-xs">
            {jobs.map((j) => <li key={j.id} className="flex justify-between gap-2 border-b border-line pb-2 last:border-0"><span>{j.channel} · {j.template}<br /><span className="text-muted">{j.recipient}</span></span><span className={`chip ${j.status === "failed" ? "bg-danger/10 text-danger" : j.status === "queued" ? "bg-warn/10 text-warn" : "bg-bg-2 text-ink-2"}`}>{j.status}</span></li>)}
            {jobs.length === 0 && <li className="text-muted">—</li>}
          </ul>
        </div>
      </div>
    </div>
  );
}
