import { getTranslations, setRequestLocale } from "next-intl/server";
import { inbox } from "@/lib/care";
import InboxList from "@/components/admin/InboxList";

export default async function MessagesInbox({ params }: { params: Promise<{ locale: "it" | "en" }> }) {
  const { locale } = await params; setRequestLocale(locale);
  const t = await getTranslations("admin.messages");
  const rows = (await inbox()) as { patientId: string; name: string; lastAt: string; lastBody: string; unread: number }[];
  return (
    <div className="grid gap-6">
      <h1 className="display text-4xl">{t("title")}</h1>
      <div className="grid gap-6 lg:grid-cols-[360px_1fr]">
        <InboxList rows={rows} empty={t("empty")} />
        <div className="card hidden place-items-center p-10 text-muted lg:grid">{t("select")}</div>
      </div>
    </div>
  );
}
