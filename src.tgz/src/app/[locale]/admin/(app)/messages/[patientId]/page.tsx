import { getTranslations, setRequestLocale } from "next-intl/server";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { Phone, UserRound } from "lucide-react";
import { getDb, schema } from "@/db";
import { inbox, thread, markRead, patientAppointments } from "@/lib/care";
import { getSetting } from "@/lib/settings";
import { formatInZone } from "@/lib/availability";
import { Link } from "@/i18n/navigation";
import InboxList from "@/components/admin/InboxList";
import ChatThread from "@/components/ChatThread";
import StatusChip from "@/components/admin/StatusChip";

export default async function AdminThread({ params }: { params: Promise<{ locale: "it" | "en"; patientId: string }> }) {
  const { locale, patientId } = await params; setRequestLocale(locale);
  const t = await getTranslations("admin.messages");
  const db = await getDb();
  const p = await db.query.patients.findFirst({ where: eq(schema.patients.id, patientId) });
  if (!p) notFound();
  const [rows, msgs, appts, policy] = await Promise.all([inbox(), thread(patientId), patientAppointments(patientId), getSetting("bookingPolicy")]);
  await markRead(patientId, "admin");
  const next = appts.filter((x) => x.upcoming).sort((x, y) => x.a.startsAt.getTime() - y.a.startsAt.getTime())[0];
  const list = rows as { patientId: string; name: string; lastAt: string; lastBody: string; unread: number }[];
  if (!list.some((r) => r.patientId === patientId)) list.unshift({ patientId, name: p.name, lastAt: new Date().toISOString(), lastBody: "", unread: 0 });
  return (
    <div className="grid gap-6">
      <h1 className="display text-4xl">{t("title")}</h1>
      <div className="grid gap-6 lg:grid-cols-[360px_1fr]">
        <div className="hidden lg:block"><InboxList rows={list} empty={t("empty")} /></div>
        <div className="card p-4 sm:p-6">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3 border-b border-line pb-4">
            <div><p className="font-semibold">{p.name}</p><p className="text-sm text-muted">{p.email} · {p.phone}</p>
              {next && <p className="mt-1 flex items-center gap-2 text-xs text-muted">{t("nextAppt")}: {(() => { const w = formatInZone(next.a.startsAt, policy.timezone, locale); return `${w.date} ${w.time}`; })()} <StatusChip status={next.a.status} /></p>}</div>
            <div className="flex gap-2"><Link href={`/admin/patients/${p.id}`} className="btn btn-ghost btn-sm"><UserRound size={14} /> {t("profile")}</Link><Link href={`/admin/calls?call=${p.id}`} className="btn btn-solid btn-sm"><Phone size={14} /> {t("call")}</Link></div>
          </div>
          <ChatThread me="admin" patientId={patientId} compact initial={msgs.map((m) => ({ id: m.id, sender: m.sender, body: m.body, createdAt: m.createdAt.toISOString(), replyToId: m.replyToId, attachments: m.attachments }))} labels={{ placeholder: t("placeholder", { name: p.name.split(" ")[0] }), send: t("send"), empty: t("empty"), you: "Sara", other: p.name.split(" ")[0], reply: t("reply"), attach: t("attach"), uploading: t("uploading"), tooBig: t("tooBig") }} />
        </div>
      </div>
    </div>
  );
}
