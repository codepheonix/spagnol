import { getTranslations, setRequestLocale } from "next-intl/server";
import { DateTime } from "luxon";
import { Link } from "@/i18n/navigation";
import { overviewStats } from "@/lib/admin-queries";
import StatusChip from "@/components/admin/StatusChip";
import MarkReadButton from "@/components/admin/MarkReadButton";
import { openRequests, unreadCount } from "@/lib/care";

export default async function Overview({ params }: { params: Promise<{ locale: "it" | "en" }> }) {
  const { locale } = await params; setRequestLocale(locale);
  const t = await getTranslations("admin.overview");
  const [s, req, chat] = await Promise.all([overviewStats(), openRequests(), unreadCount(null, "admin")]);
  const tiles: [string, number, string?][] = [[t("requests"), req.appointments.length + req.reschedules.length, "/admin/requests"], [t("chat"), chat, "/admin/messages"], [t("today"), s.today.length], [t("free"), s.free], [t("upcoming"), s.upcoming], [t("new"), s.newWeek], [t("cancelled"), s.cancelledWeek], [t("noShow"), s.noShow30]];
  return (
    <div className="grid gap-8">
      <div><p className="eyebrow">{DateTime.now().setZone(s.timezone).setLocale(locale).toFormat("cccc d LLLL yyyy")}</p><h1 className="display text-4xl">{t("title")}</h1></div>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {tiles.map(([l, v, href]) => href ? <Link key={l} href={href} className={`card p-5 no-underline ${v > 0 ? "border-accent" : ""}`}><p className="text-xs font-semibold uppercase tracking-widest text-muted">{l}</p><p className="display mt-2 text-4xl">{v}</p></Link> : <div key={l} className="card p-5"><p className="text-xs font-semibold uppercase tracking-widest text-muted">{l}</p><p className="display mt-2 text-4xl">{v}</p></div>)}
      </div>
      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <section className="card p-5">
          <h2 className="mb-4 text-lg font-semibold">{t("today")}</h2>
          {s.today.length === 0 ? <p className="text-muted">{t("none")}</p> : (
            <ul className="divide-y divide-line">
              {s.today.map(({ a, p, s: sv }) => (
                <li key={a.id}><Link href={`/admin/appointments/${a.id}`} className="flex items-center gap-4 py-3 no-underline hover:text-accent">
                  <span className="display w-16 text-2xl">{DateTime.fromJSDate(a.startsAt, { zone: s.timezone }).toFormat("HH:mm")}</span>
                  <span className="flex-1"><strong>{p.name}</strong><br /><span className="text-sm text-muted">{locale === "it" ? sv.titleIt : sv.titleEn} · {sv.durationMin} min</span></span>
                  <StatusChip status={a.status} />
                </Link></li>
              ))}
            </ul>
          )}
        </section>
        <section className="card p-5">
          <div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-semibold">{t("notifications")}</h2>{s.unread > 0 && <MarkReadButton label={t("markAllRead")} />}</div>
          <ul className="grid gap-2 text-sm">
            {s.notifications.map((n) => (
              <li key={n.id} className={`rounded-xl px-3 py-2 ${n.read ? "text-muted" : "bg-accent-soft font-medium"}`}>
                {n.appointmentId ? <Link href={`/admin/appointments/${n.appointmentId}`} className="no-underline">{locale === "it" ? n.titleIt : n.titleEn}</Link> : (locale === "it" ? n.titleIt : n.titleEn)}
                <span className="block text-[11px] text-muted">{DateTime.fromJSDate(n.createdAt).setLocale(locale).toRelative()}</span>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
}
