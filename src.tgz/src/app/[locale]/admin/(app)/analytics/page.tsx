import { getTranslations, setRequestLocale } from "next-intl/server";
import { analytics } from "@/lib/admin-queries";

export default async function AnalyticsPage({ params }: { params: Promise<{ locale: "it" | "en" }> }) {
  const { locale } = await params; setRequestLocale(locale);
  const t = await getTranslations("admin.analytics");
  const a = await analytics(90);
  const pct = (n: number) => (a.total ? Math.round((n / a.total) * 100) : 0) + "%";
  const maxW = Math.max(1, ...a.byWeek.map(([, n]) => n));
  const maxS = Math.max(1, ...a.byService.map((s) => s.n));
  return (
    <div className="grid gap-6">
      <div><p className="eyebrow">{t("period")}</p><h1 className="display text-3xl">{t("title")}</h1></div>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[[t("total"), String(a.total)], [t("cancelRate"), pct(a.cancelled)], [t("noShowRate"), pct(a.noShow)], [t("returning"), `${a.returning} / ${a.uniquePatients}`]].map(([l, v]) => <div key={l} className="card p-5"><p className="text-xs font-semibold uppercase tracking-widest text-muted">{l}</p><p className="display mt-2 text-4xl">{v}</p></div>)}
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <section className="card p-5"><h2 className="mb-4 font-semibold">{t("byWeek")}</h2>
          <div className="flex h-48 items-end gap-1">{a.byWeek.map(([w, n]) => <div key={w} className="flex-1 rounded-t bg-accent" style={{ height: `${(n / maxW) * 100}%` }} title={`${w}: ${n}`} />)}{a.byWeek.length === 0 && <p className="text-muted">—</p>}</div>
        </section>
        <section className="card p-5"><h2 className="mb-4 font-semibold">{t("byService")}</h2>
          <ul className="grid gap-2 text-sm">{a.byService.map((s) => <li key={s.it}><div className="flex justify-between"><span>{locale === "it" ? s.it : s.en}</span><strong>{s.n}</strong></div><div className="h-2 rounded bg-bg-2"><div className="h-2 rounded bg-accent" style={{ width: `${(s.n / maxS) * 100}%` }} /></div></li>)}</ul>
        </section>
      </div>
    </div>
  );
}
