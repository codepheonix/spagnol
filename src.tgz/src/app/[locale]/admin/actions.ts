"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { z } from "zod";
import { and, eq, inArray, desc } from "drizzle-orm";
import { getDb, schema, flushDb } from "@/db";
import { login, logout, requireSession, changePassword, setupTotp, enableTotp, disableTotp } from "@/lib/auth";
import { BookingPolicy, ClinicInfo, NotificationSettings, getSetting, setSetting } from "@/lib/settings";
import { bookAppointment, cancelAppointment, rescheduleAppointment, setAppointmentStatus, BookingError } from "@/lib/booking";
import { processNotificationJobs } from "@/lib/notify/worker";
import { verifyTurnstile } from "@/lib/security/turnstile";
import { decideReschedule, startCall, updateCall } from "@/lib/care";

type LoginState = { reason: "invalid" | "totp_required" | "rate_limited" } | null;
export async function loginAction(_prev: LoginState, form: FormData): Promise<LoginState> {
  const h = await headers();
  const ip = (h.get("x-forwarded-for") ?? "").split(",")[0].trim() || "local";
  if (!(await verifyTurnstile(String(form.get("cf-turnstile-response") ?? ""), ip))) return { reason: "invalid" };
  const r = await login(String(form.get("email") ?? ""), String(form.get("password") ?? ""), String(form.get("totp") ?? "") || undefined, ip);
  if (!r.ok) return { reason: r.reason };
  const locale = h.get("x-next-intl-locale") ?? "it";
  redirect(`/${locale}/admin`);
}

export async function logoutAction(locale: string) {
  await logout();
  redirect(`/${locale}/app/login`);
}

const ok = () => ({ ok: true as const });
const all = async (locale: string) => { await flushDb(); revalidatePath(`/${locale}/admin`, "layout"); };

// ── Appointments ──────────────────────────────────────────────────────────────
export async function saveAdminNotes(id: string, notes: string, locale: string) {
  await requireSession();
  const db = await getDb();
  await db.update(schema.appointments).set({ adminNotes: notes.slice(0, 2000), updatedAt: new Date() }).where(eq(schema.appointments.id, id));
  await db.insert(schema.appointmentEvents).values({ appointmentId: id, type: "note", actor: "admin", data: {} });
  await all(locale); return ok();
}

export async function appointmentStatusAction(id: string, status: "confirmed" | "completed" | "no_show" | "cancelled", locale: string) {
  const s = await requireSession();
  if (status === "cancelled") await cancelAppointment(id, { admin: true, actor: s.email });
  else await setAppointmentStatus(id, status, s.email);
  processNotificationJobs().catch(() => {});
  await all(locale); return ok();
}

export async function rescheduleAction(id: string, startISO: string, locale: string) {
  const s = await requireSession();
  try { await rescheduleAppointment(id, startISO, { admin: true, actor: s.email }); }
  catch (e) { if (e instanceof BookingError) return { ok: false as const, error: e.code }; throw e; }
  processNotificationJobs().catch(() => {});
  await all(locale); return ok();
}

const Manual = z.object({ serviceId: z.string().min(1), start: z.string().datetime({ offset: true }), name: z.string().trim().min(2), email: z.string().trim().email().optional().or(z.literal("")), phone: z.string().trim().min(5), notes: z.string().max(500).optional(), notify: z.boolean().optional() });
export async function manualBookingAction(input: z.infer<typeof Manual>, locale: string) {
  const s = await requireSession();
  const b = Manual.parse(input);
  try {
    const r = await bookAppointment({ serviceId: b.serviceId, startISO: b.start, source: "manual", admin: true, actor: s.email,
      patient: { name: b.name, email: b.email || "noemail+" + Date.now() + "@local.invalid", phone: b.phone, locale: locale === "en" ? "en" : "it", notes: b.notes } });
    if (!b.email) { // no email → silently drop patient jobs
      const db = await getDb();
      await db.update(schema.notificationJobs).set({ status: "cancelled" }).where(and(eq(schema.notificationJobs.appointmentId, r.appointment.id), inArray(schema.notificationJobs.channel, ["email", "sms"])));
    }
    processNotificationJobs().catch(() => {});
    await all(locale);
    return { ok: true as const, id: r.appointment.id };
  } catch (e) { if (e instanceof BookingError) return { ok: false as const, error: e.code }; throw e; }
}

// ── Availability ──────────────────────────────────────────────────────────────
const Hours = z.array(z.object({ weekday: z.number().int().min(1).max(7), startTime: z.string().regex(/^\d{2}:\d{2}$/), endTime: z.string().regex(/^\d{2}:\d{2}$/) }));
export async function saveHoursAction(hours: z.infer<typeof Hours>, locale: string) {
  await requireSession();
  const rows = Hours.parse(hours).filter((h) => h.startTime < h.endTime);
  const db = await getDb();
  await db.transaction(async (tx) => {
    await tx.delete(schema.workingHours).where(eq(schema.workingHours.providerId, "main"));
    if (rows.length) await tx.insert(schema.workingHours).values(rows.map((r) => ({ ...r, providerId: "main", active: true })));
  });
  await all(locale); revalidatePath(`/${locale}/book`); return ok();
}
const Exception = z.object({ date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), kind: z.enum(["closed", "open", "break", "block"]), startTime: z.string().regex(/^\d{2}:\d{2}$/).nullable(), endTime: z.string().regex(/^\d{2}:\d{2}$/).nullable(), note: z.string().max(200).optional() });
export async function addExceptionAction(input: z.infer<typeof Exception>, locale: string) {
  await requireSession();
  const e = Exception.parse(input);
  if (e.kind !== "closed" && (!e.startTime || !e.endTime)) return { ok: false as const, error: "range_required" };
  const db = await getDb();
  await db.insert(schema.availabilityExceptions).values({ ...e, startTime: e.kind === "closed" ? null : e.startTime, endTime: e.kind === "closed" ? null : e.endTime, providerId: "main" });
  await all(locale); return ok();
}
export async function deleteExceptionAction(id: string, locale: string) {
  await requireSession();
  const db = await getDb();
  await db.delete(schema.availabilityExceptions).where(eq(schema.availabilityExceptions.id, id));
  await all(locale); return ok();
}

// ── Content ───────────────────────────────────────────────────────────────────
const ServiceInput = z.object({ id: z.string().optional(), slug: z.string().regex(/^[a-z0-9-]{2,40}$/), titleIt: z.string().min(1), titleEn: z.string().min(1), descriptionIt: z.string(), descriptionEn: z.string(), durationMin: z.number().int().min(5).max(480), bufferMin: z.number().int().min(0).max(120), priceCents: z.number().int().min(0).nullable(), active: z.boolean(), sort: z.number().int() });
export async function saveServiceAction(input: z.infer<typeof ServiceInput>, locale: string) {
  await requireSession();
  const s = ServiceInput.parse(input);
  const db = await getDb();
  if (s.id) await db.update(schema.services).set({ ...s, id: undefined }).where(eq(schema.services.id, s.id));
  else await db.insert(schema.services).values(s);
  await all(locale); revalidatePath(`/${locale}`); return ok();
}
export async function saveClinicAction(input: ClinicInfo, locale: string) {
  await requireSession();
  await setSetting("clinicInfo", ClinicInfo.parse(input));
  await all(locale); revalidatePath(`/${locale}`); return ok();
}

// ── Settings ──────────────────────────────────────────────────────────────────
export async function savePolicyAction(input: BookingPolicy, locale: string) {
  await requireSession();
  await setSetting("bookingPolicy", BookingPolicy.parse(input));
  await all(locale); return ok();
}
export async function saveNotificationSettingsAction(input: NotificationSettings, locale: string) {
  await requireSession();
  await setSetting("notifications", NotificationSettings.parse(input));
  await all(locale); return ok();
}
export async function changePasswordAction(current: string, next: string) {
  const s = await requireSession();
  if (next.length < 10) return { ok: false as const, error: "short" };
  return (await changePassword(s.sub, current, next)) ? ok() : { ok: false as const, error: "wrong" };
}
export async function totpSetupAction() { const s = await requireSession(); return setupTotp(s.sub); }
export async function totpEnableAction(secret: string, code: string, locale: string) { const s = await requireSession(); const r = await enableTotp(s.sub, secret, code); await all(locale); return r; }
export async function totpDisableAction(locale: string) { const s = await requireSession(); await disableTotp(s.sub); await all(locale); return ok(); }
export async function runJobsAction(locale: string) { await requireSession(); const r = await processNotificationJobs(50); await all(locale); return r; }

// ── Notifications (in-app) ────────────────────────────────────────────────────
export async function markNotificationsRead(locale: string) {
  await requireSession();
  const db = await getDb();
  await db.update(schema.adminNotifications).set({ read: true }).where(eq(schema.adminNotifications.read, false));
  await all(locale); return ok();
}

export async function recentNotifications() {
  await requireSession();
  const db = await getDb();
  return db.query.adminNotifications.findMany({ orderBy: desc(schema.adminNotifications.createdAt), limit: 20 });
}
export { getSetting };

// ── Requests, calls ───────────────────────────────────────────────────────────
export async function decideRescheduleAction(id: string, accept: boolean, locale: string) {
  const s = await requireSession();
  try { await decideReschedule(id, accept, s.email); } catch (e) { if (e instanceof BookingError) return { ok: false as const, error: e.code }; throw e; }
  processNotificationJobs().catch(() => {});
  await all(locale); return ok();
}

export async function startAdminCallAction(patientId: string) {
  await requireSession();
  const c = await startCall(patientId, "admin");
  await flushDb();
  return { id: c.id };
}

export async function declineCallAction(id: string, locale: string) {
  await requireSession();
  await updateCall(id, { status: "declined", endedAt: new Date() });
  await all(locale); return ok();
}
