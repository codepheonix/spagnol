import { redirect } from "next/navigation";
/** The practitioner signs in from the same page as patients; the old address just forwards there. */
export default async function AdminLogin({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  redirect(`/${locale}/app/login`);
}
