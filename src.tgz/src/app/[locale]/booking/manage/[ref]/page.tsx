import { getTranslations, setRequestLocale } from "next-intl/server";
import { asc, eq } from "drizzle-orm";
import { DateTime } from "luxon";
import { getDb, schema } from "@/db";
import { findByManageToken, getAppointmentFull } from "@/lib/booking";
import { getSetting } from "@/lib/settings";
import SubpageShell from "@/components/SubpageShell";
import ManageActions from "@/components/ManageActions";

export const dynamic = "force-dynamic";

export default async function ManagePage({ params, searchParams }: { params: Promise<{ locale: "it" | "en"; ref: string }>; searchParams: Promise<{ t?: string; moved?: string; action?: string }> }) {
  const { locale, ref } = await params; setRequestLocale(locale);
  const sp = await searchParams;
  const tm = await getTranslations("manage");
  let data: Awaited<ReturnType<typeof getAppointmentFull>> | null = null;
  try { const a = await findByManageToken(ref, sp.t ?? ""); data = await getAppointmentFull(a.id); } catch { data = null; }
  if (!data) return <SubpageShell title={tm("notFound")}><p /></SubpageShell>;
  const policy = await getSetting("bookingPolicy");
  const { appointment: a, service: s } = data;
  const when = DateTime.fromJSDate(a.startsAt, { zone: policy.timezone }).setLocale(locale);
  const active = ["pending", "confirmed", "rescheduled"].includes(a.status);
  const canCancel = active && a.startsAt.getTime() - Date.now() > policy.cancelCutoffHours * 3_600_000;
  const canMove = false; // rescheduling now happens in the patient area (proposal reviewed by the practitioner)

  return (
    <SubpageShell title={tm("title")} eyebrow={a.reference}>
      <div className="mx-auto max-w-3xl">
        {sp.moved && <p className="mb-4 rounded-xl bg-accent-soft px-4 py-3 text-sm font-semibold text-accent">{tm("rescheduled")}</p>}
        <div className="card p-7">
          <span className={`chip ${a.status === "cancelled" ? "bg-danger/10 text-danger" : a.status === "pending" ? "bg-warn/10 text-warn" : "bg-accent-soft text-accent"}`}>{tm(`status.${a.status}`)}</span>
          <dl className="mt-5 grid gap-4 sm:grid-cols-2">
            <div><dt className="text-xs font-semibold uppercase tracking-widest text-muted">{locale === "it" ? "Trattamento" : "Treatment"}</dt><dd className="display text-2xl">{locale === "it" ? s.titleIt : s.titleEn}</dd></div>
            <div><dt className="text-xs font-semibold uppercase tracking-widest text-muted">{locale === "it" ? "Quando" : "When"}</dt><dd className="display text-2xl capitalize">{when.toFormat("cccc d LLLL")}<br />{when.toFormat("HH:mm")} · {s.durationMin} min</dd></div>
          </dl>
          <ManageActions reference={a.reference} token={sp.t ?? ""} canCancel={canCancel} canMove={canMove} active={active} />
        </div>
      </div>
    </SubpageShell>
  );
}
