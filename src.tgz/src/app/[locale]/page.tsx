import { getTranslations, setRequestLocale } from "next-intl/server";
import { ArrowRight, Activity, Hand, Dumbbell, MessageCircle, Bone, PersonStanding, Footprints, Trophy, ScanLine, HeartPulse } from "lucide-react";
import { getSetting } from "@/lib/settings";
import { Link } from "@/i18n/navigation";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import Reveal from "@/components/Reveal";
import VideoHero from "@/components/home/VideoHero";
import Testimonials from "@/components/home/Testimonials";
import { Card, CardGrid } from "@/components/home/Cards";
import { seedIfEmpty } from "@/db/seed";

export const dynamic = "force-dynamic";

export default async function Landing({ params }: { params: Promise<{ locale: "it" | "en" }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  const t = await getTranslations();
  await seedIfEmpty();
  const clinic = await getSetting("clinicInfo");
  const pointIcons = [ScanLine, Hand, Dumbbell, MessageCircle];
  const areaIcons = [Bone, Activity, Footprints, Trophy, PersonStanding, HeartPulse];
  const jsonLd = { "@context": "https://schema.org", "@type": "Physiotherapy", name: clinic.practice, address: clinic.address, telephone: clinic.phone, email: clinic.email, openingHours: "Mo-Fr 09:00-19:00", url: "/" };

  return (
    <>
      <SiteHeader name={clinic.name.split(" ").slice(-1)[0]} />
      <main id="main">
        <VideoHero eyebrow={t("hero.eyebrow")} title={t("hero.title")} titleAccent={t("hero.titleAccent")} text={t("hero.text")} cta={{ label: t("hero.cta"), href: "/app/signup" }} secondary={{ label: t("hero.secondary"), href: "#method" }} pauseLabel={t("hero.pause")} playLabel={t("hero.play")} />

        {/* Method */}
        <section id="method" className="gut py-[12vh]">
          <div className="mx-auto grid max-w-6xl gap-12 lg:grid-cols-[1fr_1.15fr] lg:items-start">
            <Reveal className="lg:sticky lg:top-28">
              <p className="eyebrow mb-3">{t("intro.eyebrow")}</p>
              <h2 className="display max-w-[16ch] text-[clamp(34px,4.6vw,64px)]">{t("intro.title")}</h2>
              <p className="lede mt-6">{t("intro.text")}</p>
              <Link href="/about" className="btn btn-ghost mt-8">{t("nav.about")} <ArrowRight size={16} /></Link>
            </Reveal>
            <CardGrid className="grid gap-4 sm:grid-cols-2">
              {t.raw("intro.points").map((p: { t: string; d: string }, i: number) => { const I = pointIcons[i]; return (
                <Card key={p.t} className="p-7"><span className="grid h-11 w-11 place-items-center rounded-2xl bg-accent-soft text-accent"><I size={20} /></span><h3 className="mt-5 text-lg font-semibold">{p.t}</h3><p className="mt-2 text-[15px] text-ink-2">{p.d}</p></Card>
              ); })}
            </CardGrid>
          </div>
        </section>

        {/* Areas (no prices) */}
        <section className="gut bg-bg-2 py-[12vh]">
          <div className="mx-auto max-w-6xl">
            <Reveal className="max-w-3xl"><p className="eyebrow mb-3">{t("areas.eyebrow")}</p><h2 className="display text-[clamp(32px,4.4vw,60px)]">{t("areas.title")}</h2></Reveal>
            <CardGrid className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {t.raw("areas.items").map((p: { t: string; d: string }, i: number) => { const I = areaIcons[i]; return (
                <Card key={p.t} className="flex gap-4 p-6"><span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-bg-2 text-accent"><I size={18} /></span><div><h3 className="font-semibold">{p.t}</h3><p className="mt-1 text-[15px] text-ink-2">{p.d}</p></div></Card>
              ); })}
            </CardGrid>
          </div>
        </section>

        {/* How */}
        <section className="gut py-[12vh]">
          <div className="mx-auto max-w-6xl">
            <Reveal className="max-w-3xl"><p className="eyebrow mb-3">{t("how.eyebrow")}</p><h2 className="display text-[clamp(32px,4.4vw,60px)]">{t("how.title")}</h2></Reveal>
            <ol className="mt-12 grid gap-8 md:grid-cols-3">
              {t.raw("how.steps").map((s: { t: string; d: string }, i: number) => (
                <Reveal key={s.t} delay={i * 100}><li className="relative border-t border-line pt-6"><span className="display text-5xl text-accent">0{i + 1}</span><h3 className="mt-4 text-xl font-semibold">{s.t}</h3><p className="mt-2 text-ink-2">{s.d}</p></li></Reveal>
              ))}
            </ol>
          </div>
        </section>

        {/* Testimonials */}
        <section className="gut bg-bg-2 py-[12vh]">
          <div className="mx-auto max-w-4xl">
            <Reveal className="mb-8 text-center"><p className="eyebrow mb-3">{t("testimonials.eyebrow")}</p><h2 className="display text-[clamp(30px,4vw,52px)]">{t("testimonials.title")}</h2></Reveal>
            <Testimonials items={clinic.testimonials.map((x) => ({ name: x.name, text: x[locale] }))} />
          </div>
        </section>

        {/* CTA */}
        <section className="gut py-[14vh]">
          <Reveal className="mx-auto max-w-4xl text-center">
            <h2 className="display text-[clamp(40px,6vw,84px)]">{t("cta.title")}</h2>
            <p className="lede mx-auto mt-5">{t("cta.sub")}</p>
            <div className="mt-9 flex flex-wrap items-center justify-center gap-4">
              <Link href="/app/signup" className="btn btn-solid">{t("cta.button")} <ArrowRight size={16} /></Link>
              <span className="text-sm text-muted">{t("cta.note")} <Link href="/app/login" className="font-semibold text-accent">{t("cta.login")}</Link></span>
            </div>
          </Reveal>
        </section>
      </main>
      <SiteFooter clinic={clinic} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
    </>
  );
}
