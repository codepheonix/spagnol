import { getTranslations, setRequestLocale } from "next-intl/server";
import SubpageShell from "@/components/SubpageShell";
import { getSetting } from "@/lib/settings";
import { legalText } from "@/lib/legal";

export const dynamic = "force-dynamic";

export default async function Page({ params }: { params: Promise<{ locale: "it" | "en" }> }) {
  const { locale } = await params; setRequestLocale(locale);
  const t = await getTranslations("legal");
  const clinic = await getSetting("clinicInfo");
  return (
    <SubpageShell title={t("termsTitle")}>
      <article className="prose mx-auto max-w-3xl text-ink-2 [&_h2]:display [&_h2]:mt-8 [&_h2]:text-2xl [&_h2]:text-ink [&_p]:mt-3">
        {legalText("terms", locale, clinic).map((b, i) => b.startsWith("## ") ? <h2 key={i}>{b.slice(3)}</h2> : <p key={i}>{b}</p>)}
      </article>
    </SubpageShell>
  );
}
