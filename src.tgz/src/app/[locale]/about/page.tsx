import { getTranslations, setRequestLocale } from "next-intl/server";
import { ArrowRight, GraduationCap } from "lucide-react";
import { getSetting } from "@/lib/settings";
import { Link } from "@/i18n/navigation";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import Reveal from "@/components/Reveal";
import { Card, CardGrid } from "@/components/home/Cards";
import Testimonials from "@/components/home/Testimonials";
import Image from "next/image";

export const dynamic = "force-dynamic";
export async function generateMetadata() { const t = await getTranslations("about"); return { title: t("title") }; }

export default async function About({ params }: { params: Promise<{ locale: "it" | "en" }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  const t = await getTranslations("about");
  const clinic = await getSetting("clinicInfo");
  return (
    <>
      <SiteHeader name={clinic.name.split(" ").slice(-1)[0]} solid />
      <main id="main" className="pt-[68px] sm:pt-[76px] lg:pt-[88px]">
        <section className="gut relative overflow-hidden py-[12vh]">
          <div aria-hidden="true" className="absolute -right-40 top-0 h-[60vh] w-[60vh] rounded-full bg-[radial-gradient(circle,var(--accent-soft),transparent_70%)]" />
          <div className="relative mx-auto grid max-w-6xl gap-12 lg:grid-cols-[1.1fr_0.9fr] lg:items-end">
            <Reveal>
              <p className="eyebrow mb-4">{t("eyebrow")}</p>
              <h1 className="display text-[clamp(40px,6vw,88px)]">{t("title")}</h1>
              <p className="lede mt-6">{t("lead")}</p>
            </Reveal>
            <Reveal delay={150} className="card overflow-hidden p-0">
              <Image src="/img/sara.webp" alt={clinic.name} width={1600} height={1200} priority className="aspect-[4/3] w-full object-cover" />
            </Reveal>
          </div>
        </section>

        <section className="gut bg-bg-2 py-[10vh]">
          <div className="mx-auto grid max-w-6xl gap-12 lg:grid-cols-2">
            <Reveal><p className="text-[clamp(19px,1.6vw,24px)] leading-relaxed text-ink-2">{t("story")}</p></Reveal>
            <Reveal delay={100}>
              <p className="eyebrow mb-4">{t("qualTitle")}</p>
              <ul className="grid gap-3">
                {clinic.qualifications.map((q) => <li key={q.it} className="flex items-start gap-3 border-t border-line pt-3"><GraduationCap size={18} className="mt-1 shrink-0 text-accent" /><span>{q[locale]}</span></li>)}
              </ul>
            </Reveal>
          </div>
        </section>

        {/* Facilities */}
        <section className="gut py-[10vh]">
          <div className="mx-auto max-w-6xl">
            <Reveal className="max-w-3xl"><p className="eyebrow mb-3">{t("facilities.eyebrow")}</p><h2 className="display text-[clamp(32px,4.4vw,60px)]">{t("facilities.title")}</h2><p className="lede mt-5">{t("facilities.text")}</p></Reveal>
            <CardGrid className="mt-10 grid gap-5 sm:grid-cols-2">
              {(["reception", "treatment", "gym", "sara"] as const).map((k, i) => { const it = (t.raw("facilities.items") as { t: string; d: string }[])[i]; return (
                <Card key={k} className="overflow-hidden p-0">
                  <Image src={`/img/${k}.webp`} alt={it.t} width={1600} height={1200} className="aspect-[4/3] w-full object-cover" />
                  <div className="p-5"><h3 className="font-semibold">{it.t}</h3><p className="mt-1 text-[15px] text-ink-2">{it.d}</p></div>
                </Card>); })}
              {[1, 2].map((n) => <Card key={n} className="grid aspect-[4/3] place-items-center p-0 sm:aspect-auto"><p className="p-6 text-center text-sm text-muted">{t("facilities.photosNote")}</p></Card>)}
            </CardGrid>
          </div>
        </section>

        <section className="gut bg-bg-2 py-[10vh]">
          <div className="mx-auto max-w-6xl">
            <Reveal><p className="eyebrow mb-3">{t("valuesTitle")}</p></Reveal>
            <CardGrid className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {t.raw("values").map((v: { t: string; d: string }, i: number) => <Card key={v.t} className="p-6"><span className="display text-4xl text-accent">0{i + 1}</span><h3 className="mt-4 font-semibold">{v.t}</h3><p className="mt-1 text-[15px] text-ink-2">{v.d}</p></Card>)}
            </CardGrid>
          </div>
        </section>

        <section className="gut bg-bg-2 py-[10vh]">
          <div className="mx-auto max-w-4xl"><Testimonials items={clinic.testimonials.map((x) => ({ name: x.name, text: x[locale] }))} /></div>
        </section>

        <section className="gut py-[12vh] text-center">
          <Reveal><Link href="/app/signup" className="btn btn-solid">{t("cta")} <ArrowRight size={16} /></Link></Reveal>
        </section>
      </main>
      <SiteFooter clinic={clinic} />
    </>
  );
}
