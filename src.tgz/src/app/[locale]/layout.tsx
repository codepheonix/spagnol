import type { Metadata } from "next";
import type { ReactNode } from "react";
import { NextIntlClientProvider, hasLocale } from "next-intl";
import { setRequestLocale } from "next-intl/server";
import { notFound } from "next/navigation";
import { cookies } from "next/headers";
import { Fraunces, Inter } from "next/font/google";
import { routing } from "@/i18n/routing";
import { ClinicInfo } from "@/lib/settings";
import { appUrl } from "@/lib/url";
import "../globals.css";

const fraunces = Fraunces({ subsets: ["latin"], variable: "--font-fraunces", display: "swap", axes: ["opsz"] });
const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });

const clinic = ClinicInfo.parse({});

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale } = await params;
  const it = locale === "it";
  return {
    metadataBase: new URL(appUrl()),
    title: { default: `${clinic.practice} — ${it ? "Fisioterapia a Trieste" : "Physiotherapy in Trieste"}`, template: `%s · ${clinic.name}` },
    description: it ? "Terapia manuale, riabilitazione e fisioterapia sportiva a Trieste. Prenota online in un minuto, nessun pagamento anticipato." : "Manual therapy, rehabilitation and sports physiotherapy in Trieste. Book online in a minute, nothing to pay upfront.",
    alternates: { canonical: `/${locale}`, languages: { it: "/it", en: "/en" } },
    openGraph: { type: "website", locale: it ? "it_IT" : "en_GB", siteName: clinic.practice },
    manifest: "/manifest.webmanifest",
    icons: { icon: [{ url: "/favicon.png", type: "image/png", sizes: "64x64" }, { url: "/icon-192.png", sizes: "192x192" }], apple: "/apple-icon.png" },
  };
}

export const viewport = { themeColor: [{ media: "(prefers-color-scheme: light)", color: "#fafaf8" }, { media: "(prefers-color-scheme: dark)", color: "#1b1815" }] };

export function generateStaticParams() {
  return routing.locales.map((locale) => ({ locale }));
}

// Theme: the toggle writes both a cookie (read here, so the class is server-rendered and survives locale switches /
// re-renders of <html>) and localStorage; the inline script handles the no-cookie first visit (system preference).
const themeScript = `(function(){try{var m=document.cookie.match(/(?:^|; )theme=(dark|light)/);var t=m?m[1]:localStorage.getItem('theme');var d=t?t==='dark':matchMedia('(prefers-color-scheme: dark)').matches;document.documentElement.classList.toggle('dark',d);if(!m)document.cookie='theme='+(d?'dark':'light')+'; path=/; max-age=31536000; SameSite=Lax';}catch(e){}})();`;

export default async function LocaleLayout({ children, params }: { children: ReactNode; params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  if (!hasLocale(routing.locales, locale)) notFound();
  setRequestLocale(locale);
  const theme = (await cookies()).get("theme")?.value;
  return (
    <html lang={locale} className={`${fraunces.variable} ${inter.variable}${theme === "dark" ? " dark" : ""}`} suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: themeScript }} /></head>
      <body>
        <NextIntlClientProvider>{children}</NextIntlClientProvider>
      </body>
    </html>
  );
}
