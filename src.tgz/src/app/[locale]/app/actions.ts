"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { z } from "zod";
import { eq } from "drizzle-orm";
import { getDb, schema, flushDb } from "@/db";
import { signup, patientLogin, patientLogout, requestMagicLink, requirePatient, resetPassword, updateProfile, changePatientPassword, findAccount, issueToken } from "@/lib/patient-auth";
import { requestAppointment, patientCancel, requestReschedule, withdrawReschedule, startCall } from "@/lib/care";
import { BookingError } from "@/lib/booking";
import { login as adminLogin } from "@/lib/auth";
import { processNotificationJobs } from "@/lib/notify/worker";
import { verifyTurnstile } from "@/lib/security/turnstile";

async function ctx() {
  const h = await headers();
  return { ip: (h.get("x-forwarded-for") ?? "").split(",")[0].trim() || "local", locale: (h.get("x-next-intl-locale") ?? "it") as "it" | "en" };
}
const after = () => { processNotificationJobs().catch(() => {}); };

export type AuthState = { error?: string; sent?: boolean } | null;

export async function loginAction(_p: AuthState, form: FormData): Promise<AuthState> {
  const { ip, locale } = await ctx();
  if (!(await verifyTurnstile(String(form.get("cf-turnstile-response") ?? ""), ip))) return { error: "captcha" };
  const email = String(form.get("email") ?? "").trim().toLowerCase(), password = String(form.get("password") ?? "");
  // One door for everyone: an e-mail that belongs to the practitioner goes to the dashboard, any other to the patient area.
  const db = await getDb();
  const admin = await db.query.admins.findFirst({ where: eq(schema.admins.email, email) });
  if (admin) {
    const r = await adminLogin(email, password, String(form.get("totp") ?? "") || undefined, ip);
    if (!r.ok) return { error: r.reason === "totp_required" ? "totp" : r.reason };
    redirect(`/${locale}/admin`);
  }
  const r = await patientLogin(email, password, ip);
  if (!r.ok) return { error: r.reason };
  await flushDb();
  redirect(`/${locale}/app`);
}

const Signup = z.object({ name: z.string().trim().min(2).max(120), email: z.string().trim().email(), phone: z.string().trim().min(5).max(30), password: z.string().min(8).max(200), smsOptIn: z.boolean() });
export async function signupAction(_p: AuthState, form: FormData): Promise<AuthState> {
  const { ip, locale } = await ctx();
  if (!(await verifyTurnstile(String(form.get("cf-turnstile-response") ?? ""), ip))) return { error: "captcha" };
  const parsed = Signup.safeParse({ name: form.get("name"), email: form.get("email"), phone: form.get("phone"), password: form.get("password"), smsOptIn: form.get("smsOptIn") === "on" });
  if (!parsed.success) return { error: "invalid" };
  const r = await signup({ ...parsed.data, locale }, ip);
  if (!r.ok) return { error: r.reason };
  after(); await flushDb();
  redirect(`/${locale}/app?welcome=1`);
}

export async function magicAction(_p: AuthState, form: FormData): Promise<AuthState> {
  const { ip } = await ctx();
  const r = await requestMagicLink(String(form.get("email") ?? ""), ip);
  after(); await flushDb();
  return r.ok ? { sent: true } : { error: r.reason };
}

export async function forgotAction(_p: AuthState, form: FormData): Promise<AuthState> {
  const { ip } = await ctx();
  const p = await findAccount(String(form.get("email") ?? ""));
  if (p) { await issueToken(p, "reset"); after(); await flushDb(); }
  void ip;
  return { sent: true };
}

export async function resetAction(_p: AuthState, form: FormData): Promise<AuthState> {
  const { locale } = await ctx();
  const pw = String(form.get("password") ?? "");
  if (pw.length < 8) return { error: "invalid" };
  const ok = await resetPassword(String(form.get("token") ?? ""), pw);
  if (!ok) return { error: "token" };
  await flushDb();
  redirect(`/${locale}/app`);
}

export async function logoutPatientAction() {
  const { locale } = await ctx();
  await patientLogout();
  redirect(`/${locale}`);
}

// ── Portal ────────────────────────────────────────────────────────────────────
async function me() {
  const s = await requirePatient();
  const db = await getDb();
  const p = await db.query.patients.findFirst({ where: eq(schema.patients.id, s.sub) });
  if (!p) throw new Error("UNAUTHENTICATED");
  return p;
}
const reval = (locale: string) => revalidatePath(`/${locale}/app`, "layout");

export async function requestAppointmentAction(input: { serviceId: string; startISO: string; notes?: string }) {
  const p = await me(); const { locale } = await ctx();
  try { await requestAppointment(p, input.serviceId, input.startISO, input.notes); }
  catch (e) { if (e instanceof BookingError) return { ok: false as const, error: e.code }; throw e; }
  after(); await flushDb(); reval(locale); return { ok: true as const };
}

export async function cancelAppointmentAction(id: string) {
  const p = await me(); const { locale } = await ctx();
  try { await patientCancel(p.id, id); } catch (e) { if (e instanceof BookingError) return { ok: false as const, error: e.code }; throw e; }
  after(); await flushDb(); reval(locale); return { ok: true as const };
}

export async function requestRescheduleAction(input: { appointmentId: string; startISO: string; note?: string }) {
  const p = await me(); const { locale } = await ctx();
  try { await requestReschedule(p, input.appointmentId, input.startISO, input.note); } catch (e) { if (e instanceof BookingError) return { ok: false as const, error: e.code }; throw e; }
  after(); await flushDb(); reval(locale); return { ok: true as const };
}

export async function withdrawRescheduleAction(id: string) {
  const p = await me(); const { locale } = await ctx();
  await withdrawReschedule(p.id, id); await flushDb(); reval(locale); return { ok: true as const };
}

export async function startCallAction() {
  const p = await me();
  const c = await startCall(p.id, "patient");
  after(); await flushDb();
  return { id: c.id };
}

const Profile = z.object({ name: z.string().trim().min(2).max(120), phone: z.string().trim().min(5).max(30), locale: z.enum(["it", "en"]), smsOptIn: z.boolean(), emailOptIn: z.boolean(), birthDate: z.string().optional() });
export async function profileAction(_p: AuthState, form: FormData): Promise<AuthState> {
  const p = await me(); const { locale } = await ctx();
  const parsed = Profile.safeParse({ name: form.get("name"), phone: form.get("phone"), locale: form.get("locale"), smsOptIn: form.get("smsOptIn") === "on", emailOptIn: form.get("emailOptIn") === "on", birthDate: form.get("birthDate") || undefined });
  if (!parsed.success) return { error: "invalid" };
  await updateProfile(p.id, { ...parsed.data, birthDate: parsed.data.birthDate ?? null });
  await flushDb(); reval(locale); return { sent: true };
}

export async function passwordAction(_p: AuthState, form: FormData): Promise<AuthState> {
  const p = await me();
  const next = String(form.get("new") ?? "");
  if (next.length < 8) return { error: "invalid" };
  const ok = await changePatientPassword(p.id, String(form.get("current") ?? ""), next);
  await flushDb();
  return ok ? { sent: true } : { error: "wrong" };
}
