import { getTranslations } from "next-intl/server";
import { FileText, Image as ImageIcon } from "lucide-react";
import { requirePatientPage } from "@/lib/patient-auth";
import { documents } from "@/lib/care";
import { fmtDate } from "@/lib/fmt";

export default async function Documents({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const s = await requirePatientPage();
  const [t, docs] = await Promise.all([getTranslations("app.documents"), documents(s.sub)]);
  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="display text-3xl sm:text-4xl">{t("title")}</h1><p className="mt-2 text-ink-2">{t("lead")}</p>
      {docs.length === 0 ? <p className="mt-8 text-sm text-muted">{t("empty")}</p> : (
        <ul className="mt-8 grid gap-2">{docs.map((d) => (
          <li key={d.url + d.messageId}><a href={d.url} target="_blank" rel="noreferrer" className="card flex items-center gap-3 p-4 no-underline transition hover:-translate-y-0.5">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-accent-soft text-accent">{d.type.startsWith("image/") ? <ImageIcon size={18} /> : <FileText size={18} />}</span>
            <span className="min-w-0 flex-1"><span className="block truncate font-medium">{d.name}</span><span className="text-xs text-muted">{t("from")} {d.sender === "admin" ? "Sara" : s.name.split(" ")[0]} · {fmtDate(d.at, locale, { dateStyle: "medium" })} · {Math.round(d.size / 1024)} KB</span></span>
          </a></li>))}</ul>)}
    </div>
  );
}
