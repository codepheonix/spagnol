import type { ReactNode } from "react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import { redirect } from "next/navigation";
import { getPatientSession } from "@/lib/patient-auth";
import { getSetting } from "@/lib/settings";
import { unreadCount } from "@/lib/care";
import PatientShell from "@/components/portal/PatientShell";

export const dynamic = "force-dynamic";

export default async function PortalLayout({ children, params }: { children: ReactNode; params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  const s = await getPatientSession();
  if (!s) redirect(`/${locale}/app/login`);
  const [t, a, clinic, unread] = await Promise.all([getTranslations("app.nav"), getTranslations("app.auth"), getSetting("clinicInfo"), unreadCount(s.sub, "patient")]);
  const nav: [string, string][] = [["", t("overview")], ["/appointments", t("appointments")], ["/messages", t("messages")], ["/documents", t("documents")], ["/call", t("call")], ["/profile", t("profile")]];
  return <PatientShell nav={nav} name={s.name} practice={clinic.practice} unread={unread} labels={{ logout: a("logout"), site: t("site") }}>{children}</PatientShell>;
}
