import { getTranslations } from "next-intl/server";
import { requirePatientPage } from "@/lib/patient-auth";
import { activeCall, callHistory, callProvider } from "@/lib/care";
import { getSetting } from "@/lib/settings";
import PatientCall from "@/components/portal/PatientCall";
import { fmtDate } from "@/lib/fmt";

export default async function CallPage({ params, searchParams }: { params: Promise<{ locale: string }>; searchParams: Promise<{ answer?: string }> }) {
  const { locale } = await params; const { answer } = await searchParams;
  const s = await requirePatientPage();
  const [t, clinic, current, history] = await Promise.all([getTranslations("app.call"), getSetting("clinicInfo"), activeCall(s.sub), callHistory(s.sub)]);
  const labels = { ringing: t("ringing"), connecting: t("connecting"), active: t("active"), ended: t("ended"), missed: t("missed"), declined: t("declined"), hangup: t("hangup"), mute: t("mute"), unmute: t("unmute"), micDenied: t("micDenied"), demo: t("demo") };
  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="display text-3xl sm:text-4xl">{t("title")}</h1><p className="mt-2 text-ink-2">{t("lead")}</p>
      <div className="mt-8"><PatientCall name={clinic.name} provider={callProvider()} initialCallId={answer ?? current?.id ?? null} labels={{ ...labels, start: t("start") }} /></div>
      <h2 className="eyebrow mt-12">{t("history")}</h2>
      {history.length === 0 ? <p className="mt-3 text-sm text-muted">{t("none")}</p> : (
        <ul className="mt-3 grid gap-2">{history.map(({ c }) => <li key={c.id} className="card flex items-center justify-between p-4 text-sm"><span>{fmtDate(c.createdAt, locale, { dateStyle: "medium", timeStyle: "short" })}</span><span className="text-muted">{c.status}{c.answeredAt && c.endedAt ? ` · ${t("duration", { m: Math.max(1, Math.round((c.endedAt.getTime() - c.answeredAt.getTime()) / 60000)) })}` : ""}</span></li>)}</ul>)}
    </div>
  );
}
