import { getTranslations } from "next-intl/server";
import { eq } from "drizzle-orm";
import { getDb, schema } from "@/db";
import { requirePatientPage } from "@/lib/patient-auth";
import ProfileForms from "@/components/portal/ProfileForms";
import PushButton from "@/components/PushButton";

export default async function Profile() {
  const s = await requirePatientPage();
  const t = await getTranslations("app.profile");
  const db = await getDb();
  const p = (await db.query.patients.findFirst({ where: eq(schema.patients.id, s.sub) }))!;
  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="display text-3xl sm:text-4xl">{t("title")}</h1>
      <ProfileForms patient={{ name: p.name, email: p.email, phone: p.phone, locale: p.locale, smsOptIn: p.smsOptIn, emailOptIn: p.emailOptIn, birthDate: p.birthDate ?? "" }} />
      <section className="card mt-6 p-6"><h2 className="font-semibold">{t("push.title")}</h2><div className="mt-3"><PushButton labels={{ on: t("push.on"), off: t("push.off"), unsupported: t("push.unsupported") }} /></div></section>
      <section className="card mt-6 p-6"><h2 className="font-semibold">{t("danger")}</h2><p className="mt-2 text-sm text-ink-2">{t("export")}</p></section>
    </div>
  );
}
