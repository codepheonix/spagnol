import { getTranslations } from "next-intl/server";
import { ArrowRight, CalendarPlus, MessageCircle, Phone, CheckCircle2 } from "lucide-react";
import { requirePatientPage } from "@/lib/patient-auth";
import { patientAppointments, unreadCount } from "@/lib/care";
import { getSetting } from "@/lib/settings";
import { formatInZone } from "@/lib/availability";
import { Link } from "@/i18n/navigation";
import StatusChip from "@/components/admin/StatusChip";

export default async function Overview({ params, searchParams }: { params: Promise<{ locale: "it" | "en" }>; searchParams: Promise<{ welcome?: string; verified?: string }> }) {
  const { locale } = await params; const sp = await searchParams;
  const s = await requirePatientPage();
  const [t, a, appts, unread, policy] = await Promise.all([getTranslations("app.overview"), getTranslations("app.auth"), patientAppointments(s.sub), unreadCount(s.sub, "patient"), getSetting("bookingPolicy")]);
  const next = appts.filter((x) => x.upcoming).sort((x, y) => x.a.startsAt.getTime() - y.a.startsAt.getTime())[0];
  const pending = appts.filter((x) => x.a.status === "pending").length;
  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="display text-3xl sm:text-4xl">{t("hello", { name: s.name.split(" ")[0] })}</h1>
      {(sp.welcome || sp.verified) && <p className="mt-4 flex items-center gap-2 rounded-xl bg-accent-soft p-3 text-sm font-medium text-accent"><CheckCircle2 size={16} /> {sp.verified ? a("verified") : a("verifyHint")}</p>}
      <div className="mt-8 grid gap-4 lg:grid-cols-[1.2fr_1fr]">
        <section className="card p-6 sm:p-8">
          <p className="eyebrow">{t("next")}</p>
          {next ? (() => { const w = formatInZone(next.a.startsAt, policy.timezone, locale); return (
            <div className="mt-4">
              <p className="display text-3xl">{w.date}</p>
              <p className="mt-1 text-xl">{w.time} · {locale === "it" ? next.s.titleIt : next.s.titleEn}</p>
              <div className="mt-3 flex items-center gap-3"><StatusChip status={next.a.status} />{pending > 0 && <span className="text-sm text-muted">{t("pending")}: {pending}</span>}</div>
              <Link href="/app/appointments" className="btn btn-ghost btn-sm mt-6">{locale === "it" ? "Tutti gli appuntamenti" : "All appointments"} <ArrowRight size={14} /></Link>
            </div>); })() : (
            <div className="mt-4"><p className="text-ink-2">{t("none")}</p><Link href="/app/appointments/new" className="btn btn-solid mt-6"><CalendarPlus size={16} /> {t("request")}</Link></div>
          )}
        </section>
        <div className="grid gap-4">
          <Link href="/app/messages" className="card flex items-center gap-4 p-6 no-underline transition hover:-translate-y-0.5">
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-accent-soft text-accent"><MessageCircle size={22} /></span>
            <div><p className="font-semibold">{t("unread", { n: unread })}</p><p className="text-sm text-muted">{t("openChat")} →</p></div>
          </Link>
          <section className="card p-6">
            <div className="flex items-start gap-4">
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-accent-soft text-accent"><Phone size={22} /></span>
              <div><p className="font-semibold">{t("callTitle")}</p><p className="mt-1 text-sm text-ink-2">{t("callText")}</p><Link href="/app/call" className="btn btn-solid btn-sm mt-4">{t("callBtn")}</Link></div>
            </div>
          </section>
        </div>
      </div>
      {next && <Link href="/app/appointments/new" className="btn btn-ghost mt-6"><CalendarPlus size={16} /> {t("request")}</Link>}
      <section className="mt-10">
        <p className="eyebrow mb-3">{t("tips")}</p>
        <ul className="grid gap-2 text-ink-2 sm:grid-cols-3">{t.raw("tipsList").map((x: string) => <li key={x} className="card p-4 text-sm">{x}</li>)}</ul>
      </section>
    </div>
  );
}
