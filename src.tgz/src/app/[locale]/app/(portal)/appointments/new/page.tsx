import { getTranslations } from "next-intl/server";
import { asc, eq } from "drizzle-orm";
import { getDb, schema } from "@/db";
import RequestFlow from "@/components/portal/RequestFlow";

export default async function NewRequest() {
  const t = await getTranslations("app.request");
  const db = await getDb();
  const services = await db.query.services.findMany({ where: eq(schema.services.active, true), orderBy: asc(schema.services.sort) });
  return (
    <div className="mx-auto max-w-4xl">
      <h1 className="display text-3xl sm:text-4xl">{t("title")}</h1><p className="mt-2 text-ink-2">{t("lead")}</p>
      <div className="mt-8"><RequestFlow mode="new" services={services} /></div>
    </div>
  );
}
