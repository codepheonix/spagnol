import { getTranslations } from "next-intl/server";
import { notFound } from "next/navigation";
import { requirePatientPage } from "@/lib/patient-auth";
import { getAppointmentFull } from "@/lib/booking";
import { getSetting } from "@/lib/settings";
import { formatInZone } from "@/lib/availability";
import RequestFlow from "@/components/portal/RequestFlow";

export default async function Reschedule({ params }: { params: Promise<{ locale: "it" | "en"; id: string }> }) {
  const { locale, id } = await params;
  const s = await requirePatientPage();
  const t = await getTranslations("app.request");
  const { appointment, service } = await getAppointmentFull(id).catch(() => ({ appointment: null, service: null }));
  if (!appointment || appointment.patientId !== s.sub || !service) notFound();
  const policy = await getSetting("bookingPolicy");
  const w = formatInZone(appointment.startsAt, policy.timezone, locale);
  return (
    <div className="mx-auto max-w-4xl">
      <h1 className="display text-3xl sm:text-4xl">{t("rescheduleTitle")}</h1>
      <p className="mt-2 text-ink-2">{t("rescheduleLead")} — {locale === "it" ? service.titleIt : service.titleEn}, {w.date} {w.time}</p>
      <div className="mt-8"><RequestFlow mode="reschedule" appointmentId={appointment.id} fixedServiceId={service.id} services={[service]} /></div>
    </div>
  );
}
