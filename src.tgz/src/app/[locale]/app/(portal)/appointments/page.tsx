import { getTranslations } from "next-intl/server";
import { CalendarPlus } from "lucide-react";
import { requirePatientPage } from "@/lib/patient-auth";
import { patientAppointments } from "@/lib/care";
import { getSetting } from "@/lib/settings";
import { formatInZone } from "@/lib/availability";
import { Link } from "@/i18n/navigation";
import StatusChip from "@/components/admin/StatusChip";
import ApptActions from "@/components/portal/ApptActions";

export default async function Appointments({ params }: { params: Promise<{ locale: "it" | "en" }> }) {
  const { locale } = await params;
  const s = await requirePatientPage();
  const [t, appts, policy] = await Promise.all([getTranslations("app.appointments"), patientAppointments(s.sub), getSetting("bookingPolicy")]);
  const up = appts.filter((x) => x.upcoming).sort((x, y) => x.a.startsAt.getTime() - y.a.startsAt.getTime());
  const past = appts.filter((x) => !x.upcoming);
  const row = (x: (typeof appts)[number]) => { const w = formatInZone(x.a.startsAt, policy.timezone, locale); const pw = x.reschedule ? formatInZone(x.reschedule.proposedStartsAt, policy.timezone, locale) : null; const editable = x.upcoming && x.a.startsAt.getTime() - Date.now() > policy.rescheduleCutoffHours * 3_600_000; return (
    <li key={x.a.id} className="card grid gap-4 p-5 sm:grid-cols-[1fr_auto] sm:items-center">
      <div>
        <div className="flex flex-wrap items-center gap-2"><p className="font-semibold">{w.date} · {w.time}</p><StatusChip status={x.a.status} /></div>
        <p className="mt-1 text-sm text-ink-2">{locale === "it" ? x.s.titleIt : x.s.titleEn} · {x.s.durationMin} min · {t("ref")} {x.a.reference}</p>
        {pw && <p className="mt-2 text-sm text-warn">{t("reschedulePending", { when: `${pw.date} ${pw.time}` })}</p>}
      </div>
      {x.upcoming && <ApptActions id={x.a.id} reference={x.a.reference} editable={editable} rescheduleId={x.reschedule?.id ?? null} labels={{ reschedule: t("reschedule"), cancel: t("cancel"), cancelConfirm: t("cancelConfirm"), cutoff: t("cutoff"), withdraw: t("withdraw"), ics: t("ics") }} />}
    </li>); };
  return (
    <div className="mx-auto max-w-4xl">
      <div className="flex flex-wrap items-end justify-between gap-4"><h1 className="display text-3xl sm:text-4xl">{t("title")}</h1><Link href="/app/appointments/new" className="btn btn-solid"><CalendarPlus size={16} /> {t("request")}</Link></div>
      <h2 className="eyebrow mt-10">{t("upcoming")}</h2>
      {up.length ? <ul className="mt-4 grid gap-3">{up.map(row)}</ul> : <p className="mt-4 text-ink-2">{t("empty")}</p>}
      {past.length > 0 && <><h2 className="eyebrow mt-10">{t("past")}</h2><ul className="mt-4 grid gap-3 opacity-80">{past.map(row)}</ul></>}
    </div>
  );
}
