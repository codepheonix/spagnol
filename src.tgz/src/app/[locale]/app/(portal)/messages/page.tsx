import { getTranslations } from "next-intl/server";
import { requirePatientPage } from "@/lib/patient-auth";
import { thread, markRead } from "@/lib/care";
import PatientChat from "@/components/portal/PatientChat";

export default async function Messages() {
  const s = await requirePatientPage();
  const t = await getTranslations("app.messages");
  const msgs = await thread(s.sub);
  await markRead(s.sub, "patient");
  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="display text-3xl sm:text-4xl">{t("title")}</h1><p className="mt-2 text-ink-2">{t("lead")}</p>
      <div className="mt-6"><PatientChat initial={msgs.map((m) => ({ id: m.id, sender: m.sender, body: m.body, createdAt: m.createdAt.toISOString(), replyToId: m.replyToId, attachments: m.attachments }))} labels={{ placeholder: t("placeholder"), send: t("send"), empty: t("empty"), you: t("you"), other: t("her"), incoming: t("incoming"), answer: t("answer"), reply: t("reply"), attach: t("attach"), uploading: t("uploading"), tooBig: t("tooBig") }} /></div>
    </div>
  );
}
