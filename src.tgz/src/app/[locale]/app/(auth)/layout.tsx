import type { ReactNode } from "react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import { redirect } from "next/navigation";
import { getPatientSession } from "@/lib/patient-auth";
import { getSession } from "@/lib/auth";
import { getSetting } from "@/lib/settings";
import ThemeToggle from "@/components/ThemeToggle";
import LocaleSwitch from "@/components/LocaleSwitch";
import Logo from "@/components/Logo";

export const dynamic = "force-dynamic";

export default async function AuthLayout({ children, params }: { children: ReactNode; params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  if (await getSession()) redirect(`/${locale}/admin`);
  if (await getPatientSession()) redirect(`/${locale}/app`);
  const clinic = await getSetting("clinicInfo");
  const t = await getTranslations("app");
  return (
    <div className="grid min-h-screen lg:grid-cols-[1fr_1fr]">
      <aside className="relative hidden overflow-hidden bg-[linear-gradient(160deg,var(--accent-soft),var(--bg-2)_55%,var(--bg))] p-12 lg:flex lg:flex-col lg:justify-between">
        <Logo h={48} alt={clinic.practice} />
        <div>
          <p className="eyebrow mb-4">{t("brand")}</p>
          <p className="display max-w-[14ch] text-[clamp(36px,4vw,64px)]">{clinic.tagline[locale as "it" | "en"]}</p>
        </div>
        <p className="text-sm text-muted">{clinic.address}</p>
      </aside>
      <main className="flex flex-col px-6 py-8 sm:px-12">
        <div className="flex items-center justify-between">
          <Logo h={40} alt={clinic.practice} className="lg:invisible" />
          <div className="flex gap-2"><LocaleSwitch /><ThemeToggle /></div>
        </div>
        <div className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center py-10">{children}</div>
      </main>
    </div>
  );
}
