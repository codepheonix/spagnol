import { getTranslations } from "next-intl/server";
import { ForgotForm } from "@/components/portal/AuthForms";

export async function generateMetadata() { const t = await getTranslations("app.auth"); return { title: t("resetTitle") }; }
export default async function Page() {
  const t = await getTranslations("app.auth");
  return (<><h1 className="display text-4xl">{t("resetTitle")}</h1><p className="mt-3 text-ink-2">{t("loginLead")}</p><div className="mt-8">{<ForgotForm />}</div></>);
}
