import { getTranslations } from "next-intl/server";
import { SignupForm } from "@/components/portal/AuthForms";

export async function generateMetadata() { const t = await getTranslations("app.auth"); return { title: t("signupTitle") }; }
export default async function Page() {
  const t = await getTranslations("app.auth");
  return (<><h1 className="display text-4xl">{t("signupTitle")}</h1><p className="mt-3 text-ink-2">{t("signupLead")}</p><div className="mt-8">{<SignupForm />}</div></>);
}
