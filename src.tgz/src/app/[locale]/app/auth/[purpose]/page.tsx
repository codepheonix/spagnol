import { getTranslations, setRequestLocale } from "next-intl/server";
import { redirect } from "next/navigation";
import { consumeToken } from "@/lib/patient-auth";
import { ResetForm } from "@/components/portal/AuthForms";
import { Link } from "@/i18n/navigation";

export const dynamic = "force-dynamic";

/** Landing for e-mailed links: /app/auth/magic?t=…  /app/auth/verify?t=…  /app/auth/reset?t=… */
export default async function AuthLink({ params, searchParams }: { params: Promise<{ locale: string; purpose: string }>; searchParams: Promise<{ t?: string }> }) {
  const { locale, purpose } = await params; const { t: token = "" } = await searchParams;
  setRequestLocale(locale);
  const t = await getTranslations("app.auth");
  const shell = (body: React.ReactNode) => <div className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-6">{body}</div>;
  if (purpose === "reset") return shell(<><h1 className="display text-4xl">{t("resetTitle")}</h1><div className="mt-8"><ResetForm token={token} /></div></>);
  if (purpose !== "magic" && purpose !== "verify") redirect(`/${locale}/app/login`);
  const p = await consumeToken(token, purpose);
  if (!p) return shell(<><h1 className="display text-3xl">{t("tokenInvalid")}</h1><Link href="/app/login" className="btn btn-solid mt-8 w-fit">{t("login")}</Link></>);
  redirect(`/${locale}/app${purpose === "verify" ? "?verified=1" : ""}`);
}
