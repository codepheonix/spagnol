import { getTranslations, setRequestLocale } from "next-intl/server";
import { Clock, MapPin, Phone, Mail, MessageCircle } from "lucide-react";
import { getSetting } from "@/lib/settings";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import Reveal from "@/components/Reveal";
import ContactForm from "@/components/ContactForm";

export const dynamic = "force-dynamic";
export async function generateMetadata() { const t = await getTranslations("contact"); return { title: t("title") }; }

export default async function Contact({ params }: { params: Promise<{ locale: "it" | "en" }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  const t = await getTranslations("contact");
  const clinic = await getSetting("clinicInfo");
  const rows = [
    [Clock, t("hours"), clinic.openingHoursText[locale], null],
    [MapPin, t("address"), clinic.address, `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(clinic.mapQuery)}`],
    [Phone, t("phone"), clinic.phone, `tel:${clinic.phone.replace(/\s/g, "")}`],
    [Mail, t("email"), clinic.email, `mailto:${clinic.email}`],
    [MessageCircle, "WhatsApp", clinic.whatsappDisplay, `https://wa.me/${clinic.whatsappDisplay.replace(/[^\d]/g, "")}`],
  ] as const;
  return (
    <>
      <SiteHeader name={clinic.name.split(" ").slice(-1)[0]} solid />
      <main id="main" className="pt-[68px] sm:pt-[76px] lg:pt-[88px]">
        <section className="gut py-[10vh]">
          <div className="mx-auto max-w-6xl">
            <Reveal className="max-w-3xl"><p className="eyebrow mb-4">{t("eyebrow")}</p><h1 className="display text-[clamp(40px,6vw,88px)]">{t("title")}</h1><p className="lede mt-6">{t("lead")}</p></Reveal>
            <div className="mt-14 grid gap-10 lg:grid-cols-[1fr_1.1fr]">
              <Reveal>
                <ul className="grid gap-1">
                  {rows.map(([I, label, value, href]) => (
                    <li key={label} className="flex items-center gap-4 border-t border-line py-4"><span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-accent-soft text-accent"><I size={18} /></span><div><p className="text-xs font-semibold uppercase tracking-[0.18em] text-muted">{label}</p>{href ? <a href={href} target={href.startsWith("http") ? "_blank" : undefined} rel="noreferrer" className="font-medium">{value}</a> : <p className="font-medium">{value}</p>}</div></li>
                  ))}
                </ul>
                <div className="card mt-8 overflow-hidden">
                  <iframe title="map" className="h-[280px] w-full border-0 grayscale-[.3]" loading="lazy" referrerPolicy="no-referrer-when-downgrade" src={`https://www.google.com/maps?q=${encodeURIComponent(clinic.mapQuery)}&output=embed`} />
                </div>
              </Reveal>
              <Reveal delay={100} className="card p-7 sm:p-9">
                <h2 className="display text-3xl">{t("form.title")}</h2>
                <ContactForm labels={{ name: t("form.name"), email: t("form.email"), message: t("form.message"), send: t("form.send"), sent: t("form.sent"), error: t("form.error") }} />
              </Reveal>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter clinic={clinic} />
    </>
  );
}
