import type { MetadataRoute } from "next";
import { appUrl } from "@/lib/url";
export default function robots(): MetadataRoute.Robots {
  return { rules: [{ userAgent: "*", allow: "/", disallow: ["/it/admin", "/en/admin", "/api/"] }], sitemap: `${appUrl()}/sitemap.xml` };
}
