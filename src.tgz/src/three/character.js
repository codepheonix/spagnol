// Four-layer cursor scene (WebGL part): L2 pastel back props + L3 the practice's 3D character on the treatment
// table. L1 (background blobs) and L4 (foreground bokeh + copy) are DOM layers moved by CharacterHero.tsx.
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { MeshoptDecoder } from 'three/examples/jsm/libs/meshopt_decoder.module.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

/**
 * @param {HTMLCanvasElement} canvas
 * @param {{ reducedMotion?: boolean, onReady?: () => void, onError?: (e: unknown) => void }} [opts]
 */
export function createCharacterScene(canvas, { reducedMotion = false, onReady, onError } = {}) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
  renderer.outputColorSpace = THREE.SRGBColorSpace; renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.0;
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  const scene = new THREE.Scene();
  const pmrem = new THREE.PMREMGenerator(renderer);
  scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  const camera = new THREE.PerspectiveCamera(30, 1, 0.1, 50); camera.position.set(0, 0.55, 3.6);
  const sun = new THREE.DirectionalLight(0xfff6ea, 2.3); sun.position.set(2.5, 4, 3); sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048); sun.shadow.radius = 6;
  Object.assign(sun.shadow.camera, { left: -2, right: 2, top: 2, bottom: -2, near: 1, far: 12 }); scene.add(sun);
  scene.add(new THREE.HemisphereLight(0xffffff, 0xd8cdbf, 0.9));

  // L2 back props: warm pastel shapes (wood, cream, sage, pale blue)
  const back = new THREE.Group(); scene.add(back);
  const mats = [0xe9d9c6, 0xcfe3dc, 0xd7e3f0, 0xf3e4d3].map((c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.8, metalness: 0 }));
  const geos = [new THREE.SphereGeometry(0.16, 32, 24), new THREE.TorusGeometry(0.2, 0.055, 20, 48), new THREE.CapsuleGeometry(0.06, 0.2, 8, 16), new THREE.IcosahedronGeometry(0.15, 1)];
  const props = [];
  for (let i = 0; i < 9; i++) {
    const m = new THREE.Mesh(geos[i % geos.length], mats[i % mats.length]);
    const a = (i / 9) * Math.PI * 2, r = 1.9 + (i % 3) * 0.5;
    m.position.set(Math.cos(a) * r + 0.7, 0.5 + Math.sin(a * 1.7) * 1.0, -2.4 - (i % 3) * 0.8);
    m.rotation.set(i * 0.7, i * 1.3, 0); m.userData.ph = i * 0.9;
    back.add(m); props.push(m);
  }

  // L3 hero: character + table
  const hero = new THREE.Group(); scene.add(hero);
  const catcher = new THREE.Mesh(new THREE.PlaneGeometry(6, 6), new THREE.ShadowMaterial({ opacity: 0.2 }));
  catcher.rotation.x = -Math.PI / 2; catcher.receiveShadow = true; hero.add(catcher);
  const loader = new GLTFLoader(); loader.setMeshoptDecoder(MeshoptDecoder);
  let model = null, bounce = 0, bounceV = 0;
  loader.loadAsync('/models/character.glb').then((g) => {
    model = g.scene; const box = new THREE.Box3().setFromObject(model); const size = box.getSize(new THREE.Vector3()), ctr = box.getCenter(new THREE.Vector3());
    const s = 1.25 / size.y; model.scale.setScalar(s); model.position.set(-ctr.x * s, -box.min.y * s, -ctr.z * s);
    model.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; o.material.envMapIntensity = 0.6; } });
    hero.add(model); onReady?.();
  }).catch((e) => onError?.(e));
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
  const onDown = (e) => { if (!model) return; const r = canvas.getBoundingClientRect(); ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -(((e.clientY - r.top) / r.height) * 2 - 1)); ray.setFromCamera(ndc, camera); if (ray.intersectObject(model, true).length) bounceV = 2.2; };
  canvas.addEventListener('pointerdown', onDown);

  const ptr = { x: 0, y: 0, tx: 0, ty: 0 };
  function resize() {
    const w = canvas.clientWidth || 1, h = canvas.clientHeight || 1; renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 1.75)); renderer.setSize(w, h, false);
    camera.aspect = w / h; camera.updateProjectionMatrix();
    const portrait = w < h; camera.setViewOffset(w, h, portrait ? 0 : -w * 0.22, portrait ? h * 0.12 : 0, w, h);
  }
  const ro = new ResizeObserver(resize); ro.observe(canvas); resize();
  const clock = new THREE.Clock(); let running = true, paused = false;
  function frame() {
    if (!running) return; requestAnimationFrame(frame); if (paused || document.hidden) return;
    const dt = Math.min(clock.getDelta(), 0.05), t = clock.elapsedTime;
    ptr.x += (ptr.tx - ptr.x) * (1 - Math.exp(-5 * dt)); ptr.y += (ptr.ty - ptr.y) * (1 - Math.exp(-5 * dt));
    back.position.set(ptr.x * 0.35, -ptr.y * 0.18, 0);
    if (!reducedMotion) for (const m of props) { m.rotation.x += dt * 0.15; m.rotation.y += dt * 0.1; m.position.y += Math.sin(t * 0.7 + m.userData.ph) * 0.0008; }
    bounceV -= bounce * 60 * dt; bounceV *= Math.exp(-5 * dt); bounce += bounceV * dt;
    hero.rotation.y = -0.35 + ptr.x * 0.35; hero.rotation.x = ptr.y * 0.12;
    hero.position.set(ptr.x * 0.08, (reducedMotion ? 0 : Math.sin(t * 1.6) * 0.015) + bounce * 0.12, 0);
    hero.scale.setScalar(1 + bounce * 0.06);
    renderer.render(scene, camera);
  }
  requestAnimationFrame(frame);
  return {
    setPointer(x, y) { ptr.tx = x; ptr.ty = y; },
    setPaused(v) { paused = v; if (!v) clock.getDelta(); },
    destroy() { running = false; ro.disconnect(); canvas.removeEventListener('pointerdown', onDown); scene.traverse((o) => o.geometry?.dispose()); pmrem.dispose(); renderer.dispose(); },
  };
}
