"use client";
import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { Menu, X } from "lucide-react";
import { Link, usePathname } from "@/i18n/navigation";
import ThemeToggle from "./ThemeToggle";
import LocaleSwitch from "./LocaleSwitch";
import MobileMenu from "./MobileMenu";
import Logo from "./Logo";

export default function SiteHeader({ name, solid = false, overlay = false }: { name: string; solid?: boolean; overlay?: boolean }) {
  const t = useTranslations("nav");
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const f = () => setScrolled(scrollY > 40);
    f(); addEventListener("scroll", f, { passive: true }); return () => removeEventListener("scroll", f);
  }, []);
  const links = [["/", t("home")], ["/about", t("about")], ["/contact", t("contact")]] as const;
  const active = (h: string) => (h === "/" ? pathname === "/" : pathname.startsWith(h));
  void overlay;
  const bar = scrolled || solid ? "border-b border-line bg-bg/75 backdrop-blur-md" : "";
  return (
    <header className={`fixed inset-x-0 top-0 z-30 transition-all duration-500 ${bar}`}>
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-full focus:bg-accent focus:px-4 focus:py-2 focus:text-white">{t("skip")}</a>
      <div className="gut flex h-[68px] items-center justify-between sm:h-[76px] lg:h-[88px]">
        <Logo h={40} alt={name} className="[&_img]:lg:!h-[56px]" />
        <nav aria-label="Primary" className="hidden items-center gap-8 lg:flex">
          {links.map(([href, label]) => <Link key={href} href={href} className={`text-[13px] font-semibold uppercase tracking-[0.18em] no-underline transition hover:text-accent ${active(href) ? "text-accent" : "text-ink-2"}`}>{label}</Link>)}
        </nav>
        <div className="flex items-center gap-2">
          <LocaleSwitch className="hidden lg:inline-flex" />
          <ThemeToggle className="hidden lg:inline-flex" />
          <Link href="/app/login" className="btn btn-solid btn-sm hidden lg:inline-flex">{t("login")}</Link>
          <button type="button" className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-line bg-surface/70 lg:hidden" aria-label={t("menu")} aria-expanded={open} onClick={() => setOpen((v) => !v)}>
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>
      <MobileMenu open={open} onClose={() => setOpen(false)} links={links.map(([h, l]) => [h, l])} extra={[["/app/signup", t("signup")]]} cta={{ href: "/app/login", label: t("login") }} />
    </header>
  );
}
