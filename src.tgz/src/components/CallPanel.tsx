"use client";
import { useEffect, useRef, useState } from "react";
import { Mic, MicOff, PhoneOff, Phone } from "lucide-react";
import { createCallEngine, type CallState, type Engine } from "@/lib/calls/client";

export type CallLabels = { ringing: string; connecting: string; active: string; ended: string; missed: string; declined: string; hangup: string; mute: string; unmute: string; micDenied: string; demo: string };
/** Voice-call UI for an existing call id. Starts immediately; `name` is the other party. */
export default function CallPanel({ callId, role, name, provider, labels, onEnded }: { callId: string; role: "patient" | "admin"; name: string; provider: string; labels: CallLabels; onEnded?: () => void }) {
  const [state, setState] = useState<CallState>("connecting");
  const [detail, setDetail] = useState<string>("");
  const [muted, setMuted] = useState(false);
  const [level, setLevel] = useState(0);
  const [secs, setSecs] = useState(0);
  const eng = useRef<Engine | null>(null);
  useEffect(() => {
    const e = createCallEngine({ callId, role, onState: (s, d) => { setState(s); if (d) setDetail(d); if (s === "ended") onEnded?.(); } });
    eng.current = e; e.start();
    const meter = setInterval(() => setLevel(e.level()), 100);
    return () => { clearInterval(meter); e.destroy(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [callId]);
  useEffect(() => { if (state !== "active") return; const id = setInterval(() => setSecs((s) => s + 1), 1000); return () => clearInterval(id); }, [state]);
  const mm = String(Math.floor(secs / 60)).padStart(2, "0"), ss = String(secs % 60).padStart(2, "0");
  const status = state === "active" ? `${labels.active} · ${mm}:${ss}` : state === "ringing" ? labels.ringing : state === "connecting" ? labels.connecting
    : state === "ended" ? (detail === "missed" ? labels.missed : detail === "declined" ? labels.declined : labels.ended) : (detail.includes("Permission") || detail.includes("NotAllowed") ? labels.micDenied : detail || "error");
  return (
    <div className="card mx-auto max-w-md p-8 text-center">
      <div className="relative mx-auto grid h-28 w-28 place-items-center">
        <span aria-hidden="true" className={`absolute inset-0 rounded-full bg-accent/15 transition-transform ${state === "ringing" ? "animate-ping" : ""}`} style={{ transform: `scale(${1 + level * 0.6})` }} />
        <span className="relative grid h-24 w-24 place-items-center rounded-full bg-accent text-3xl font-semibold text-white dark:text-bg">{name[0]}</span>
      </div>
      <p className="display mt-5 text-2xl">{name}</p>
      <p className="mt-1 text-sm text-muted" aria-live="polite">{status}</p>
      {provider === "demo" && <p className="mt-3 rounded-xl bg-warn/10 p-2 text-xs text-warn">{labels.demo}</p>}
      <div className="mt-8 flex justify-center gap-3">
        {state !== "ended" && state !== "error" && (<>
          <button type="button" className="btn btn-ghost !h-14 !w-14 !px-0" aria-label={muted ? labels.unmute : labels.mute} onClick={() => { const m = !muted; setMuted(m); eng.current?.mute(m); }}>{muted ? <MicOff size={20} /> : <Mic size={20} />}</button>
          <button type="button" className="btn !h-14 !w-14 !px-0 bg-danger text-white" aria-label={labels.hangup} onClick={() => eng.current?.hangup()}><PhoneOff size={20} /></button>
        </>)}
        {(state === "ended" || state === "error") && <span className="grid h-14 w-14 place-items-center rounded-full bg-bg-2 text-muted"><Phone size={20} /></span>}
      </div>
    </div>
  );
}
