"use client";
import { useEffect, useRef } from "react";
declare global { interface Window { turnstile?: { render: (el: HTMLElement, o: Record<string, unknown>) => string; remove: (id: string) => void } } }
/** Cloudflare Turnstile widget (invisible when the site key is not configured). Adds a hidden `cf-turnstile-response` field to the form. */
export default function Turnstile() {
  const ref = useRef<HTMLDivElement>(null);
  const key = process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY;
  useEffect(() => {
    if (!key || !ref.current) return;
    let id: string | undefined;
    const render = () => { if (window.turnstile && ref.current && !id) id = window.turnstile.render(ref.current, { sitekey: key, theme: "auto", size: "flexible" }); };
    if (window.turnstile) render();
    else { const s = document.createElement("script"); s.src = "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit"; s.async = true; s.onload = render; document.head.appendChild(s); }
    return () => { if (id) window.turnstile?.remove(id); };
  }, [key]);
  if (!key) return null;
  return <div ref={ref} className="my-1" />;
}
