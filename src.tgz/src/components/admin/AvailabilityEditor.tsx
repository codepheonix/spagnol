"use client";
import { useState, useTransition } from "react";
import { useLocale, useTranslations } from "next-intl";
import { Trash2 } from "lucide-react";
import { useRouter } from "@/i18n/navigation";
import { addExceptionAction, deleteExceptionAction, saveHoursAction } from "@/app/[locale]/admin/actions";

type H = { weekday: number; startTime: string; endTime: string };
type E = { id: string; date: string; kind: string; startTime: string | null; endTime: string | null; note: string | null };

export default function AvailabilityEditor({ hours: initial, exceptions }: { hours: H[]; exceptions: E[] }) {
  const t = useTranslations("admin.avail");
  const tc = useTranslations("common");
  const ta = useTranslations("admin.common");
  const locale = useLocale(); const router = useRouter();
  const [p, start] = useTransition();
  const [hours, setHours] = useState<H[]>(initial);
  const [saved, setSaved] = useState(false);
  const [ex, setEx] = useState<{ date: string; kind: "closed" | "block" | "break" | "open"; startTime: string; endTime: string; note: string }>({ date: "", kind: "closed", startTime: "09:00", endTime: "13:00", note: "" });
  const weekdays = tc.raw("weekdays") as string[];
  const upd = (i: number, k: keyof H, v: string | number) => { const h = [...hours]; h[i] = { ...h[i], [k]: v }; setHours(h); setSaved(false); };
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <section className="card p-6">
        <h2 className="font-semibold">{t("hours")}</h2><p className="mb-4 text-sm text-muted">{t("hoursHint")}</p>
        <div className="grid gap-2">
          {[1, 2, 3, 4, 5, 6, 7].map((wd) => (
            <div key={wd} className="grid grid-cols-[48px_1fr] items-start gap-3 border-t border-line py-2">
              <span className="pt-2 text-sm font-semibold">{weekdays[wd - 1]}</span>
              <div className="grid gap-2">
                {hours.map((h, i) => h.weekday === wd && (
                  <div key={i} className="flex items-center gap-2">
                    <input type="time" className="input !h-10 w-32" value={h.startTime} onChange={(e) => upd(i, "startTime", e.target.value)} /><span>–</span>
                    <input type="time" className="input !h-10 w-32" value={h.endTime} onChange={(e) => upd(i, "endTime", e.target.value)} />
                    <button type="button" aria-label={t("remove")} className="text-muted hover:text-danger" onClick={() => { setHours(hours.filter((_, j) => j !== i)); setSaved(false); }}><Trash2 size={16} /></button>
                  </div>
                ))}
                <button type="button" className="text-left text-xs font-semibold text-accent" onClick={() => { setHours([...hours, { weekday: wd, startTime: "09:00", endTime: "13:00" }]); setSaved(false); }}>+ {t("add")}</button>
              </div>
            </div>
          ))}
        </div>
        <button type="button" className="btn btn-solid btn-sm mt-4" disabled={p} onClick={() => start(async () => { await saveHoursAction(hours, locale); setSaved(true); router.refresh(); })}>{ta("save")}{saved ? ` · ${t("saved")}` : ""}</button>
      </section>
      <section className="card p-6">
        <h2 className="font-semibold">{t("exceptions")}</h2><p className="mb-4 text-sm text-muted">{t("exceptionsHint")}</p>
        <form className="grid gap-3 rounded-xl border border-line p-4" onSubmit={(e) => { e.preventDefault(); start(async () => {
          await addExceptionAction({ date: ex.date, kind: ex.kind, startTime: ex.kind === "closed" ? null : ex.startTime, endTime: ex.kind === "closed" ? null : ex.endTime, note: ex.note }, locale); setEx({ ...ex, note: "" }); router.refresh(); }); }}>
          <div className="grid gap-3 sm:grid-cols-2">
            <div><label className="label">{t("date")}</label><input type="date" required className="input" value={ex.date} onChange={(e) => setEx({ ...ex, date: e.target.value })} /></div>
            <div><label className="label">{t("kind")}</label><select className="input" value={ex.kind} onChange={(e) => setEx({ ...ex, kind: e.target.value as typeof ex.kind })}>{(["closed", "block", "break", "open"] as const).map((k) => <option key={k} value={k}>{t(`kinds.${k}`)}</option>)}</select></div>
            {ex.kind !== "closed" && <><div><label className="label">{t("from")}</label><input type="time" className="input" value={ex.startTime} onChange={(e) => setEx({ ...ex, startTime: e.target.value })} /></div>
            <div><label className="label">{t("to")}</label><input type="time" className="input" value={ex.endTime} onChange={(e) => setEx({ ...ex, endTime: e.target.value })} /></div></>}
            <div className="sm:col-span-2"><label className="label">{t("note")}</label><input className="input" value={ex.note} onChange={(e) => setEx({ ...ex, note: e.target.value })} /></div>
          </div>
          <button className="btn btn-ghost btn-sm justify-self-start" disabled={p} type="submit">{t("addException")}</button>
        </form>
        <ul className="mt-4 divide-y divide-line text-sm">
          {exceptions.map((e) => (
            <li key={e.id} className="flex items-center justify-between gap-3 py-2">
              <span><strong>{e.date}</strong> · {t(`kinds.${e.kind as "closed"}`)} {e.startTime ? `${e.startTime}–${e.endTime}` : ""} {e.note && <span className="text-muted">· {e.note}</span>}</span>
              <button type="button" className="text-muted hover:text-danger" aria-label={t("remove")} disabled={p} onClick={() => start(async () => { await deleteExceptionAction(e.id, locale); router.refresh(); })}><Trash2 size={16} /></button>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
