"use client";
import { useEffect, useState, useTransition } from "react";
import { useLocale } from "next-intl";
import { Phone, PhoneIncoming, PhoneOff } from "lucide-react";
import { useRouter } from "@/i18n/navigation";
import { fmtDate } from "@/lib/fmt";
import CallPanel, { type CallLabels } from "../CallPanel";
import { declineCallAction, startAdminCallAction } from "@/app/[locale]/admin/actions";

type Live = { id: string; status: string; startedBy: string; patient: string; patientId: string; createdAt: string };
export default function AdminCalls({ provider, live, history, patients, answer, callPatient, labels, panel }: { provider: string; live: Live[]; history: { id: string; status: string; patient: string; createdAt: string; seconds: number }[]; patients: { id: string; name: string }[]; answer: string | null; callPatient: string | null; labels: { title: string; incoming: string; none: string; history: string; answer: string; decline: string; start: string; pick: string; demo: string; calling: string; status: Record<string, string> }; panel: CallLabels }) {
  const locale = useLocale(); const router = useRouter();
  const [active, setActive] = useState<{ id: string; name: string } | null>(() => { const l = live.find((x) => x.id === answer); return l ? { id: l.id, name: l.patient } : null; });
  const [pick, setPick] = useState(callPatient ?? "");
  const [pending, go] = useTransition();
  useEffect(() => { if (active) return; const id = setInterval(() => router.refresh(), 5000); return () => clearInterval(id); }, [active, router]);
  const start = (patientId: string) => go(async () => { const r = await startAdminCallAction(patientId); setActive({ id: r.id, name: patients.find((p) => p.id === patientId)?.name ?? "" }); });
  const ringing = live.filter((c) => c.status === "ringing" && c.startedBy === "patient");
  return (
    <div className="grid gap-8">
      <h1 className="display text-4xl">{labels.title}</h1>
      {provider === "demo" && <p className="rounded-xl bg-warn/10 p-3 text-sm text-warn">{labels.demo}</p>}
      {active ? <CallPanel callId={active.id} role="admin" name={active.name} provider={provider} labels={panel} onEnded={() => setTimeout(() => { setActive(null); router.refresh(); }, 1500)} /> : (
        <div className="grid gap-6 lg:grid-cols-2">
          <section className="card p-5">
            <h2 className="mb-3 flex items-center gap-2 font-semibold"><PhoneIncoming size={16} /> {labels.incoming}</h2>
            {ringing.length === 0 ? <p className="text-sm text-muted">{labels.none}</p> : (
              <ul className="grid gap-2">{ringing.map((c) => (
                <li key={c.id} className="flex items-center justify-between rounded-xl bg-accent-soft p-3">
                  <span className="font-medium">{c.patient}</span>
                  <span className="flex gap-2"><button className="btn btn-solid btn-sm" onClick={() => setActive({ id: c.id, name: c.patient })}><Phone size={14} /> {labels.answer}</button><button className="btn btn-ghost btn-sm text-danger" disabled={pending} onClick={() => go(async () => { await declineCallAction(c.id, locale); router.refresh(); })}><PhoneOff size={14} /> {labels.decline}</button></span>
                </li>))}</ul>)}
          </section>
          <section className="card p-5">
            <h2 className="mb-3 flex items-center gap-2 font-semibold"><Phone size={16} /> {labels.start}</h2>
            <div className="flex gap-2">
              <select className="input flex-1" value={pick} onChange={(e) => setPick(e.target.value)}><option value="">{labels.pick}</option>{patients.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
              <button className="btn btn-solid" disabled={!pick || pending} onClick={() => start(pick)}><Phone size={16} /></button>
            </div>
          </section>
        </div>)}
      <section>
        <h2 className="eyebrow mb-3">{labels.history}</h2>
        {history.length === 0 ? <p className="text-sm text-muted">{labels.none}</p> : (
          <ul className="card divide-y divide-line">{history.map((h) => <li key={h.id} className="flex items-center justify-between px-4 py-3 text-sm"><span className="font-medium">{h.patient}</span><span className="text-muted">{fmtDate(h.createdAt, locale, { dateStyle: "medium", timeStyle: "short" })} · {labels.status[h.status] ?? h.status}{h.seconds ? ` · ${Math.floor(h.seconds / 60)}:${String(h.seconds % 60).padStart(2, "0")}` : ""}</span></li>)}</ul>)}
      </section>
    </div>
  );
}
