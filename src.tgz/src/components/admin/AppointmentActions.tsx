"use client";
import { useState, useTransition } from "react";
import { useLocale, useTranslations } from "next-intl";
import { useRouter } from "@/i18n/navigation";
import { DateTime } from "luxon";
import { appointmentStatusAction, rescheduleAction, saveAdminNotes } from "@/app/[locale]/admin/actions";

export default function AppointmentActions({ id, status, notes, serviceId, startISO }: { id: string; status: string; notes: string; serviceId: string; startISO: string }) {
  const t = useTranslations("admin.appt");
  const locale = useLocale();
  const router = useRouter();
  const [p, start] = useTransition();
  const [n, setN] = useState(notes);
  const [saved, setSaved] = useState(false);
  const [moving, setMoving] = useState(false);
  const [date, setDate] = useState(DateTime.fromISO(startISO).setZone("Europe/Rome").toISODate()!);
  const [slots, setSlots] = useState<{ start: string; label: string }[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const active = ["pending", "confirmed", "rescheduled"].includes(status);
  const act = (s: "confirmed" | "completed" | "no_show" | "cancelled") => {
    if (s === "cancelled" && !confirm(t("confirmCancel"))) return;
    start(async () => { await appointmentStatusAction(id, s, locale); router.refresh(); });
  };
  const loadSlots = async (d: string) => {
    setDate(d); setSlots(null);
    const r = await fetch(`/api/admin/slots?service=${serviceId}&date=${d}&exclude=${id}`, { cache: "no-store" });
    setSlots((await r.json()).slots ?? []);
  };
  return (
    <div className="mt-6 grid gap-4">
      {active && (
        <div className="flex flex-wrap gap-2">
          {status === "pending" && <button type="button" className="btn btn-solid btn-sm" disabled={p} onClick={() => act("confirmed")}>{t("approve")}</button>}
          <button type="button" className="btn btn-ghost btn-sm" disabled={p} onClick={() => act("completed")}>{t("complete")}</button>
          <button type="button" className="btn btn-ghost btn-sm" disabled={p} onClick={() => act("no_show")}>{t("noShow")}</button>
          <button type="button" className="btn btn-ghost btn-sm" disabled={p} onClick={() => { setMoving(!moving); if (!moving) loadSlots(date); }}>{t("reschedule")}</button>
          <button type="button" className="btn btn-ghost btn-sm text-danger" disabled={p} onClick={() => act("cancelled")}>{t("cancel")}</button>
        </div>
      )}
      {moving && (
        <div className="rounded-xl border border-line p-4">
          <label className="label">{t("pickSlot")}</label>
          <input type="date" className="input mb-3 max-w-xs" value={date} onChange={(e) => loadSlots(e.target.value)} />
          {err && <p className="mb-2 text-sm text-danger">{err}</p>}
          <div className="flex flex-wrap gap-2">
            {slots === null ? <span className="text-muted text-sm">…</span> : slots.length === 0 ? <span className="text-muted text-sm">—</span> : slots.map((s) => (
              <button key={s.start} type="button" className="btn btn-ghost btn-sm" disabled={p} onClick={() => start(async () => { const r = await rescheduleAction(id, s.start, locale); if (!r.ok) setErr(t("slotTaken")); else { setMoving(false); router.refresh(); } })}>{s.label}</button>
            ))}
          </div>
        </div>
      )}
      <div>
        <label className="label" htmlFor="notes">{t("notes")}</label>
        <textarea id="notes" className="input" value={n} onChange={(e) => { setN(e.target.value); setSaved(false); }} />
        <button type="button" className="btn btn-ghost btn-sm mt-2" disabled={p || n === notes} onClick={() => start(async () => { await saveAdminNotes(id, n, locale); setSaved(true); router.refresh(); })}>{t("save")}{saved ? " ✓" : ""}</button>
      </div>
    </div>
  );
}
