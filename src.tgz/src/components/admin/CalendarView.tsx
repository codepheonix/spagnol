"use client";
import { DateTime } from "luxon";
import { useLocale } from "next-intl";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Link, useRouter } from "@/i18n/navigation";

type Ev = { id: string; start: string; end: string; status: string; title: string; sub: string };
type Ex = { date: string; kind: string; startTime: string | null; endTime: string | null; note: string | null };
const color: Record<string, string> = { pending: "bg-warn/15 border-warn text-warn", confirmed: "bg-accent-soft border-accent text-accent", rescheduled: "bg-accent-soft border-accent text-accent", completed: "bg-bg-2 border-line text-ink-2", cancelled: "bg-danger/10 border-danger/40 text-danger line-through", no_show: "bg-danger/10 border-danger/40 text-danger" };

export default function CalendarView({ view, anchorISO, timezone, labels, events, exceptions, hours }: { view: "day" | "week" | "month"; anchorISO: string; timezone: string; labels: Record<string, string>; events: Ev[]; exceptions: Ex[]; hours: { weekday: number; startTime: string; endTime: string }[] }) {
  const locale = useLocale();
  const router = useRouter();
  const anchor = DateTime.fromISO(anchorISO, { zone: timezone });
  const go = (v: string, d: DateTime) => router.push(`/admin/calendar?view=${v}&date=${d.toISODate()}`);
  const shift = (n: number) => go(view, anchor.plus(view === "day" ? { days: n } : view === "week" ? { weeks: n } : { months: n }));
  const evs = events.map((e) => ({ ...e, s: DateTime.fromISO(e.start, { zone: timezone }), e: DateTime.fromISO(e.end, { zone: timezone }) }));
  const dayHours = (d: DateTime) => hours.filter((h) => h.weekday === d.weekday);
  const [hStart, hEnd] = [Math.min(7, ...hours.map((h) => +h.startTime.slice(0, 2))), Math.max(20, ...hours.map((h) => +h.endTime.slice(0, 2) + 1))];
  const days = view === "day" ? [anchor] : view === "week" ? Array.from({ length: 7 }, (_, i) => anchor.startOf("week").plus({ days: i })) : Array.from({ length: 42 }, (_, i) => anchor.startOf("month").startOf("week").plus({ days: i }));

  const title = view === "day" ? anchor.setLocale(locale).toFormat("cccc d LLLL yyyy") : view === "week" ? `${anchor.startOf("week").setLocale(locale).toFormat("d LLL")} – ${anchor.endOf("week").setLocale(locale).toFormat("d LLL yyyy")}` : anchor.setLocale(locale).toFormat("LLLL yyyy");

  return (
    <div className="grid gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="display text-2xl capitalize sm:text-3xl">{title}</h1>
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex rounded-full border border-line bg-surface p-1 text-sm">
            {(["day", "week", "month"] as const).map((v) => <button key={v} type="button" onClick={() => go(v, anchor)} className={`rounded-full px-3 py-1 font-semibold ${view === v ? "bg-accent text-white dark:text-bg" : "text-ink-2"}`}>{labels[v]}</button>)}
          </div>
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => go(view, DateTime.now().setZone(timezone))}>{labels.today}</button>
          <button type="button" className="btn btn-ghost btn-sm !px-2" aria-label={labels.prev} onClick={() => shift(-1)}><ChevronLeft size={16} /></button>
          <button type="button" className="btn btn-ghost btn-sm !px-2" aria-label={labels.next} onClick={() => shift(1)}><ChevronRight size={16} /></button>
        </div>
      </div>

      {view !== "month" ? (
        <div className="card overflow-x-auto">
          <div className={`grid ${view === "week" ? "min-w-[640px]" : "min-w-0"}`} style={{ gridTemplateColumns: `56px repeat(${days.length}, 1fr)` }}>
            <div />
            {days.map((d) => <div key={d.toISODate()} className={`border-b border-l border-line px-2 py-2 text-center text-xs font-semibold uppercase tracking-widest ${d.hasSame(DateTime.now().setZone(timezone), "day") ? "text-accent" : "text-muted"}`}>{d.setLocale(locale).toFormat(view === "day" ? "cccc d" : "ccc d")}</div>)}
            <div className="relative" style={{ height: (hEnd - hStart) * 56 }}>
              {Array.from({ length: hEnd - hStart }, (_, i) => <div key={i} className="absolute right-2 text-[11px] text-muted" style={{ top: i * 56 - 7 }}>{String(hStart + i).padStart(2, "0")}:00</div>)}
            </div>
            {days.map((d) => {
              const iso = d.toISODate()!;
              const closedAll = exceptions.some((x) => x.date === iso && x.kind === "closed" && !x.startTime);
              const windows = dayHours(d);
              return (
                <div key={iso} className="relative border-l border-line bg-bg-2/70" style={{ height: (hEnd - hStart) * 56, backgroundImage: "linear-gradient(to bottom, var(--line) 1px, transparent 1px)", backgroundSize: "100% 56px" }}>
                  {!closedAll && windows.map((w, i) => {
                    const top = (+w.startTime.slice(0, 2) + +w.startTime.slice(3) / 60 - hStart) * 56, h = (+w.endTime.slice(0, 2) + +w.endTime.slice(3) / 60 - +w.startTime.slice(0, 2) - +w.startTime.slice(3) / 60) * 56;
                    return <div key={i} className="absolute inset-x-0 bg-surface" style={{ top, height: h }} />;
                  })}
                  {exceptions.filter((x) => x.date === iso && x.startTime && x.endTime).map((x, i) => {
                    const top = (+x.startTime!.slice(0, 2) + +x.startTime!.slice(3) / 60 - hStart) * 56, h = (+x.endTime!.slice(0, 2) + +x.endTime!.slice(3) / 60 - +x.startTime!.slice(0, 2) - +x.startTime!.slice(3) / 60) * 56;
                    return <div key={i} className={`absolute inset-x-1 rounded-md border border-dashed px-1 text-[10px] ${x.kind === "open" ? "border-accent bg-surface" : "border-muted bg-bg-2 text-muted"}`} style={{ top, height: h }}>{x.note ?? (x.kind === "open" ? "+" : labels.blocked)}</div>;
                  })}
                  {closedAll && <div className="absolute inset-1 rounded-md bg-bg-2 p-1 text-[11px] text-muted">{exceptions.find((x) => x.date === iso && x.kind === "closed")?.note ?? labels.blocked}</div>}
                  {evs.filter((e) => e.s.hasSame(d, "day")).map((e) => {
                    const top = (e.s.hour + e.s.minute / 60 - hStart) * 56, h = Math.max(22, e.e.diff(e.s, "minutes").minutes / 60 * 56 - 2);
                    return (
                      <Link key={e.id} href={`/admin/appointments/${e.id}`} className={`absolute inset-x-1 overflow-hidden rounded-md border-l-4 px-2 py-1 text-[12px] leading-tight no-underline ${color[e.status]}`} style={{ top, height: h }} title={`${e.s.toFormat("HH:mm")} ${e.title} · ${e.sub}`}>
                        <strong>{e.s.toFormat("HH:mm")} {e.title}</strong>{h > 36 && <br />}{h > 36 && <span className="opacity-80">{e.sub}</span>}
                      </Link>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <div className="card grid grid-cols-7 overflow-hidden">
          {days.map((d, i) => {
            const iso = d.toISODate()!;
            const dayEvs = evs.filter((e) => e.s.hasSame(d, "day") && e.status !== "cancelled");
            const closed = exceptions.some((x) => x.date === iso && x.kind === "closed" && !x.startTime) || (dayHours(d).length === 0 && !exceptions.some((x) => x.date === iso && x.kind === "open"));
            return (
              <button type="button" key={iso} onClick={() => go("day", d)} className={`min-h-[96px] border-b border-r border-line p-1.5 text-left align-top ${d.month !== anchor.month ? "opacity-40" : ""} ${closed ? "bg-bg-2" : ""} ${i % 7 === 6 ? "border-r-0" : ""}`}>
                <span className={`text-xs font-semibold ${d.hasSame(DateTime.now().setZone(timezone), "day") ? "rounded-full bg-accent px-1.5 text-white" : "text-muted"}`}>{d.day}</span>
                <div className="mt-1 grid gap-0.5">
                  {dayEvs.slice(0, 3).map((e) => <span key={e.id} className={`truncate rounded px-1 text-[11px] ${color[e.status]}`}>{e.s.toFormat("HH:mm")} {e.title}</span>)}
                  {dayEvs.length > 3 && <span className="text-[11px] text-muted">+{dayEvs.length - 3}</span>}
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
