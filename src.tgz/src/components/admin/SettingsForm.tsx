"use client";
import { useState, useTransition } from "react";
import { useLocale, useTranslations } from "next-intl";
import { useRouter } from "@/i18n/navigation";
import type { BookingPolicy, NotificationSettings } from "@/lib/settings";
import { changePasswordAction, runJobsAction, saveNotificationSettingsAction, savePolicyAction, totpDisableAction, totpEnableAction, totpSetupAction } from "@/app/[locale]/admin/actions";

type Job = { id: string; channel: string; template: string; recipient: string; status: string; attempts: number; lastError: string | null; createdAt: string };

export default function SettingsForm({ policy, notif, totpEnabled, providers, jobs }: { policy: BookingPolicy; notif: NotificationSettings; totpEnabled: boolean; providers: Record<string, boolean>; jobs: Job[] }) {
  const t = useTranslations("admin.settings");
  const ta = useTranslations("admin.common");
  const locale = useLocale(); const router = useRouter();
  const [p, start] = useTransition();
  const [pol, setPol] = useState(policy);
  const [n, setN] = useState(notif);
  const [msg, setMsg] = useState<string | null>(null);
  const [pw, setPw] = useState({ current: "", next: "", confirm: "" });
  const [totp, setTotp] = useState<{ secret: string; uri: string; qr?: string } | null>(null);
  const [code, setCode] = useState("");
  const F = ({ label, children }: { label: string; children: React.ReactNode }) => <div><label className="label">{label}</label>{children}</div>;
  const Num = ({ k }: { k: keyof BookingPolicy }) => <F label={t(`fields.${k}`)}><input type="number" className="input" value={Number(pol[k])} onChange={(e) => setPol({ ...pol, [k]: +e.target.value })} /></F>;
  const Chk = ({ k }: { k: keyof NotificationSettings }) => <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={Boolean(n[k])} onChange={(e) => setN({ ...n, [k]: e.target.checked })} />{t(`nfields.${k}`)}</label>;
  return (
    <div className="grid gap-6">
      {msg && <p className="text-sm font-semibold text-accent">{msg}</p>}
      <section className="card grid gap-3 p-5">
        <h2 className="font-semibold">{t("policy")}</h2>
        <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-3">
          <F label={t("fields.timezone")}><input className="input" value={pol.timezone} onChange={(e) => setPol({ ...pol, timezone: e.target.value })} /></F>
          <Num k="slotStepMin" /><Num k="minNoticeHours" /><Num k="horizonDays" /><Num k="cancelCutoffHours" /><Num k="rescheduleCutoffHours" />
          <F label={t("fields.reminderHoursBefore")}><input className="input" value={pol.reminderHoursBefore.join(", ")} onChange={(e) => setPol({ ...pol, reminderHoursBefore: e.target.value.split(",").map((s) => +s.trim()).filter((x) => x > 0) })} /></F>
          <label className="flex items-center gap-2 pt-7 text-sm"><input type="checkbox" checked={pol.requireApproval} onChange={(e) => setPol({ ...pol, requireApproval: e.target.checked })} />{t("fields.requireApproval")}</label>
        </div>
        <button type="button" className="btn btn-solid btn-sm justify-self-start" disabled={p} onClick={() => start(async () => { await savePolicyAction(pol, locale); setMsg(t("saved")); router.refresh(); })}>{ta("save")}</button>
      </section>
      <section className="card grid gap-3 p-5">
        <h2 className="font-semibold">{t("notif")}</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          <F label={t("nfields.adminWhatsapp")}><input className="input" value={n.adminWhatsapp} onChange={(e) => setN({ ...n, adminWhatsapp: e.target.value })} placeholder="+39…" /></F>
          <F label={t("nfields.adminEmail")}><input type="email" className="input" value={n.adminEmail} onChange={(e) => setN({ ...n, adminEmail: e.target.value })} /></F>
        </div>
        <div className="grid gap-2 sm:grid-cols-2"><Chk k="notifyOnCancel" /><Chk k="notifyOnReschedule" /><Chk k="notifyOnPending" /><Chk k="patientSmsEnabled" /><Chk k="dashboardSound" /></div>
        <div className="flex flex-wrap gap-2 text-xs">{Object.entries(providers).map(([k, v]) => <span key={k} className={`chip ${v ? "bg-accent-soft text-accent" : "bg-warn/10 text-warn"}`}>{k}: {v ? t("configured") : t("mock")}</span>)}</div>
        <button type="button" className="btn btn-solid btn-sm justify-self-start" disabled={p} onClick={() => start(async () => { await saveNotificationSettingsAction(n, locale); setMsg(t("saved")); router.refresh(); })}>{ta("save")}</button>
      </section>
      <section className="card grid gap-3 p-5">
        <h2 className="font-semibold">{t("account")}</h2>
        <div className="grid gap-3 sm:grid-cols-3">
          <F label={t("password.current")}><input type="password" className="input" value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} autoComplete="current-password" /></F>
          <F label={t("password.next")}><input type="password" className="input" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} autoComplete="new-password" /></F>
          <F label={t("password.confirm")}><input type="password" className="input" value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} autoComplete="new-password" /></F>
        </div>
        <button type="button" className="btn btn-ghost btn-sm justify-self-start" disabled={p || pw.next.length < 10 || pw.next !== pw.confirm} onClick={() => start(async () => { const r = await changePasswordAction(pw.current, pw.next); setMsg(r.ok ? t("password.changed") : t("password.wrong")); setPw({ current: "", next: "", confirm: "" }); })}>{t("password.change")}</button>
        <div className="mt-2 border-t border-line pt-4">
          <h3 className="font-semibold">{t("totp.title")} <span className={`chip ml-2 ${totpEnabled ? "bg-accent-soft text-accent" : "bg-bg-2 text-muted"}`}>{totpEnabled ? t("totp.enabled") : t("totp.disabled")}</span></h3>
          {totpEnabled ? <button type="button" className="btn btn-ghost btn-sm mt-3" disabled={p} onClick={() => start(async () => { await totpDisableAction(locale); router.refresh(); })}>{t("totp.disable")}</button> : totp ? (
            <div className="mt-3 grid gap-3 sm:grid-cols-[auto_1fr]">
              {totp.qr && <img src={totp.qr} alt="QR" width={160} height={160} className="rounded-xl border border-line bg-white p-2" />}
              <div><p className="text-sm text-muted">{t("totp.scan")}</p><p className="mt-1 break-all font-mono text-xs">{totp.secret}</p>
                <div className="mt-3 flex gap-2"><input className="input max-w-[140px]" inputMode="numeric" value={code} onChange={(e) => setCode(e.target.value)} placeholder={t("totp.code")} />
                  <button type="button" className="btn btn-solid btn-sm" disabled={p} onClick={() => start(async () => { const ok = await totpEnableAction(totp.secret, code, locale); if (ok) { setTotp(null); router.refresh(); } else setMsg(t("totp.bad")); })}>{t("totp.confirm")}</button></div></div>
            </div>
          ) : <button type="button" className="btn btn-ghost btn-sm mt-3" disabled={p} onClick={() => start(async () => { const r = await totpSetupAction(); const QR = (await import("qrcode")).default; setTotp({ ...r, qr: await QR.toDataURL(r.uri) }); })}>{t("totp.setup")}</button>}
        </div>
      </section>
      <section className="card p-5">
        <div className="mb-3 flex items-center justify-between"><h2 className="font-semibold">{t("jobs")} <span className="text-sm text-muted">· {t("jobsHint")}</span></h2><button type="button" className="btn btn-ghost btn-sm" disabled={p} onClick={() => start(async () => { const r = await runJobsAction(locale); setMsg(`sent ${r.sent}, failed ${r.failed}`); router.refresh(); })}>{t("runNow")}</button></div>
        <div className="overflow-x-auto"><table className="w-full text-xs"><tbody className="divide-y divide-line">
          {jobs.map((j) => <tr key={j.id}><td className="py-1 pr-2 text-muted whitespace-nowrap">{j.createdAt.slice(0, 16).replace("T", " ")}</td><td className="py-1 pr-2">{j.channel}</td><td className="py-1 pr-2">{j.template}</td><td className="py-1 pr-2">{j.recipient}</td><td className="py-1 pr-2"><span className={`chip ${j.status === "failed" ? "bg-danger/10 text-danger" : j.status === "queued" ? "bg-warn/10 text-warn" : "bg-bg-2"}`}>{j.status} ({j.attempts})</span></td><td className="py-1 text-danger">{j.lastError?.slice(0, 80)}</td></tr>)}
        </tbody></table></div>
      </section>
    </div>
  );
}
