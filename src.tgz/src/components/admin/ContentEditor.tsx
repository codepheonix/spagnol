"use client";
import { useState, useTransition } from "react";
import { useLocale, useTranslations } from "next-intl";
import { useRouter } from "@/i18n/navigation";
import type { Service } from "@/db/schema";
import type { ClinicInfo } from "@/lib/settings";
import { saveClinicAction, saveServiceAction } from "@/app/[locale]/admin/actions";

type S = Omit<Service, "id"> & { id?: string };
const blank: S = { slug: "", titleIt: "", titleEn: "", descriptionIt: "", descriptionEn: "", durationMin: 60, bufferMin: 0, priceCents: null, active: true, sort: 99 };

export default function ContentEditor({ services, clinic }: { services: Service[]; clinic: ClinicInfo }) {
  const t = useTranslations("admin.content");
  const locale = useLocale(); const router = useRouter();
  const [p, start] = useTransition();
  const [list, setList] = useState<S[]>(services);
  const [c, setC] = useState(clinic);
  const [msg, setMsg] = useState<string | null>(null);
  const F = ({ label, children }: { label: string; children: React.ReactNode }) => <div><label className="label">{label}</label>{children}</div>;
  const upd = (i: number, k: keyof S, v: unknown) => { const l = [...list]; l[i] = { ...l[i], [k]: v }; setList(l); };
  const save = (s: S) => start(async () => { await saveServiceAction({ ...s, priceCents: s.priceCents ?? null }, locale); setMsg(t("saved")); router.refresh(); });
  return (
    <div className="grid gap-6">
      {msg && <p className="text-sm font-semibold text-accent">{msg}</p>}
      <section className="grid gap-4">
        <div className="flex items-center justify-between"><h2 className="font-semibold">{t("services")}</h2><button type="button" className="btn btn-ghost btn-sm" onClick={() => setList([...list, { ...blank }])}>+ {t("service.add")}</button></div>
        {list.map((s, i) => (
          <details key={s.id ?? `new-${i}`} className="card p-5" open={!s.id}>
            <summary className="cursor-pointer font-semibold">{s.titleIt || "—"} <span className="text-muted">· {s.durationMin} min{s.active ? "" : " · off"}</span></summary>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <F label="Slug"><input className="input" value={s.slug} onChange={(e) => upd(i, "slug", e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "-"))} /></F>
              <F label={t("service.sort")}><input type="number" className="input" value={s.sort} onChange={(e) => upd(i, "sort", +e.target.value)} /></F>
              <F label={t("service.titleIt")}><input className="input" value={s.titleIt} onChange={(e) => upd(i, "titleIt", e.target.value)} /></F>
              <F label={t("service.titleEn")}><input className="input" value={s.titleEn} onChange={(e) => upd(i, "titleEn", e.target.value)} /></F>
              <F label={t("service.descIt")}><textarea className="input" value={s.descriptionIt} onChange={(e) => upd(i, "descriptionIt", e.target.value)} /></F>
              <F label={t("service.descEn")}><textarea className="input" value={s.descriptionEn} onChange={(e) => upd(i, "descriptionEn", e.target.value)} /></F>
              <F label={t("service.duration")}><input type="number" min={5} step={5} className="input" value={s.durationMin} onChange={(e) => upd(i, "durationMin", +e.target.value)} /></F>
              <F label={t("service.buffer")}><input type="number" min={0} step={5} className="input" value={s.bufferMin} onChange={(e) => upd(i, "bufferMin", +e.target.value)} /></F>
              <F label={t("service.price")}><input type="number" min={0} className="input" value={s.priceCents == null ? "" : s.priceCents / 100} onChange={(e) => upd(i, "priceCents", e.target.value === "" ? null : Math.round(+e.target.value * 100))} /></F>
              <label className="flex items-center gap-2 pt-7 text-sm"><input type="checkbox" checked={s.active} onChange={(e) => upd(i, "active", e.target.checked)} />{t("service.active")}</label>
            </div>
            <button type="button" className="btn btn-solid btn-sm mt-4" disabled={p || !s.slug || !s.titleIt || !s.titleEn} onClick={() => save(s)}>{t("service.save")}</button>
          </details>
        ))}
      </section>
      <section className="card grid gap-3 p-5">
        <h2 className="font-semibold">{t("clinic")}</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          <F label={t("clinicFields.name")}><input className="input" value={c.name} onChange={(e) => setC({ ...c, name: e.target.value })} /></F>
          <F label={t("clinicFields.practice")}><input className="input" value={c.practice} onChange={(e) => setC({ ...c, practice: e.target.value })} /></F>
          <F label={t("clinicFields.address")}><input className="input" value={c.address} onChange={(e) => setC({ ...c, address: e.target.value })} /></F>
          <F label={t("clinicFields.mapQuery")}><input className="input" value={c.mapQuery} onChange={(e) => setC({ ...c, mapQuery: e.target.value })} /></F>
          <F label={t("clinicFields.phone")}><input className="input" value={c.phone} onChange={(e) => setC({ ...c, phone: e.target.value })} /></F>
          <F label={t("clinicFields.email")}><input className="input" value={c.email} onChange={(e) => setC({ ...c, email: e.target.value })} /></F>
          <F label={t("clinicFields.whatsapp")}><input className="input" value={c.whatsappDisplay} onChange={(e) => setC({ ...c, whatsappDisplay: e.target.value })} /></F>
          <F label={t("clinicFields.taglineIt")}><input className="input" value={c.tagline.it} onChange={(e) => setC({ ...c, tagline: { ...c.tagline, it: e.target.value } })} /></F>
          <F label={t("clinicFields.taglineEn")}><input className="input" value={c.tagline.en} onChange={(e) => setC({ ...c, tagline: { ...c.tagline, en: e.target.value } })} /></F>
          <F label={t("clinicFields.hoursIt")}><input className="input" value={c.openingHoursText.it} onChange={(e) => setC({ ...c, openingHoursText: { ...c.openingHoursText, it: e.target.value } })} /></F>
          <F label={t("clinicFields.hoursEn")}><input className="input" value={c.openingHoursText.en} onChange={(e) => setC({ ...c, openingHoursText: { ...c.openingHoursText, en: e.target.value } })} /></F>
          <F label={t("clinicFields.bioIt")}><textarea className="input" value={c.bio.it} onChange={(e) => setC({ ...c, bio: { ...c.bio, it: e.target.value } })} /></F>
          <F label={t("clinicFields.bioEn")}><textarea className="input" value={c.bio.en} onChange={(e) => setC({ ...c, bio: { ...c.bio, en: e.target.value } })} /></F>
        </div>
        <details><summary className="cursor-pointer text-sm font-semibold">Qualifiche · FAQ · Testimonianze (JSON)</summary>
          <textarea className="input mt-2 font-mono text-xs" rows={12} defaultValue={JSON.stringify({ qualifications: c.qualifications, faq: c.faq, testimonials: c.testimonials }, null, 2)}
            onBlur={(e) => { try { const j = JSON.parse(e.target.value); setC({ ...c, ...j }); setMsg(null); } catch { setMsg("JSON non valido"); } }} /></details>
        <button type="button" className="btn btn-solid btn-sm justify-self-start" disabled={p} onClick={() => start(async () => { await saveClinicAction(c, locale); setMsg(t("saved")); router.refresh(); })}>{t("service.save")}</button>
      </section>
    </div>
  );
}
