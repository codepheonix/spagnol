"use client";
import { useState, useTransition } from "react";
import { useLocale, useTranslations } from "next-intl";
import { DateTime } from "luxon";
import { useRouter } from "@/i18n/navigation";
import { manualBookingAction } from "@/app/[locale]/admin/actions";

export default function ManualBooking({ services }: { services: { id: string; title: string; durationMin: number; active: boolean }[] }) {
  const t = useTranslations("admin.appt");
  const locale = useLocale(); const router = useRouter();
  const [p, start] = useTransition();
  const [serviceId, setServiceId] = useState(services[0]?.id ?? "");
  const [date, setDate] = useState(DateTime.now().setZone("Europe/Rome").toISODate()!);
  const [slots, setSlots] = useState<{ start: string; label: string }[] | null>(null);
  const [slot, setSlot] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", email: "", phone: "", notes: "" });
  const [err, setErr] = useState<string | null>(null);
  const load = async (sid = serviceId, d = date) => {
    setSlots(null); setSlot(null);
    const r = await fetch(`/api/admin/slots?service=${sid}&date=${d}`, { cache: "no-store" });
    setSlots((await r.json()).slots ?? []);
  };
  return (
    <form className="card grid gap-4 p-6" onSubmit={(e) => { e.preventDefault(); if (!slot) return; start(async () => {
      const r = await manualBookingAction({ serviceId, start: slot, ...form }, locale);
      if (!r.ok) setErr(t("slotTaken")); else router.push(`/admin/appointments/${r.id}`);
    }); }}>
      <div className="grid gap-4 sm:grid-cols-2">
        <div><label className="label">{t("service")}</label><select className="input" value={serviceId} onChange={(e) => { setServiceId(e.target.value); load(e.target.value); }}>{services.map((s) => <option key={s.id} value={s.id}>{s.title} · {s.durationMin} min{s.active ? "" : " (off)"}</option>)}</select></div>
        <div><label className="label">{t("when")}</label><input type="date" className="input" value={date} onChange={(e) => { setDate(e.target.value); load(serviceId, e.target.value); }} /></div>
      </div>
      <div>
        <label className="label">{t("pickSlot")}</label>
        {slots === null ? <button type="button" className="btn btn-ghost btn-sm" onClick={() => load()}>…</button> : slots.length === 0 ? <p className="text-sm text-muted">—</p> : (
          <div className="flex flex-wrap gap-2">{slots.map((s) => <button key={s.start} type="button" onClick={() => setSlot(s.start)} className={`btn btn-ghost btn-sm ${slot === s.start ? "!border-accent !text-accent" : ""}`}>{s.label}</button>)}</div>
        )}
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div><label className="label">{t("patient")}</label><input className="input" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
        <div><label className="label">Telefono</label><input className="input" required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
        <div><label className="label">Email (opz.)</label><input type="email" className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
        <div><label className="label">{t("notes")}</label><input className="input" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
      </div>
      {err && <p className="text-sm text-danger">{err}</p>}
      <button type="submit" className="btn btn-solid" disabled={p || !slot}>{t("create")}</button>
    </form>
  );
}
