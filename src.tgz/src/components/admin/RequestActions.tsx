"use client";
import { useState, useTransition } from "react";
import { useLocale } from "next-intl";
import { Check, MessageCircle, X } from "lucide-react";
import { Link } from "@/i18n/navigation";
import { appointmentStatusAction, decideRescheduleAction } from "@/app/[locale]/admin/actions";

export default function RequestActions({ kind, id, patientId, labels }: { kind: "appointment" | "reschedule"; id: string; patientId: string; labels: Record<"approve" | "decline" | "chat", string> }) {
  const locale = useLocale();
  const [pending, go] = useTransition();
  const [err, setErr] = useState("");
  const decide = (yes: boolean) => go(async () => {
    setErr("");
    const r = kind === "appointment" ? await appointmentStatusAction(id, yes ? "confirmed" : "cancelled", locale) : await decideRescheduleAction(id, yes, locale);
    if ("ok" in r && !r.ok) setErr(String((r as { error?: string }).error ?? "error"));
  });
  return (
    <div className="flex flex-wrap gap-2">
      <button className="btn btn-solid btn-sm" disabled={pending} onClick={() => decide(true)}><Check size={14} /> {labels.approve}</button>
      <button className="btn btn-ghost btn-sm text-danger" disabled={pending} onClick={() => decide(false)}><X size={14} /> {labels.decline}</button>
      <Link href={`/admin/messages/${patientId}`} className="btn btn-ghost btn-sm"><MessageCircle size={14} /> {labels.chat}</Link>
      {err && <p className="w-full text-xs text-danger">{err}</p>}
    </div>
  );
}
