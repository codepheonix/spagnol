"use client";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { useLocale } from "next-intl";
import { Bell, CalendarDays, CalendarRange, Contact, FileText, LayoutDashboard, LogOut, Menu, Plus, Settings, ExternalLink, Clock, X, Inbox, MessageCircle, Phone } from "lucide-react";
import { Link, usePathname } from "@/i18n/navigation";
import ThemeToggle from "../ThemeToggle";
import LocaleSwitch from "../LocaleSwitch";
import { logoutAction } from "@/app/[locale]/admin/actions";
import Logo from "@/components/Logo";
import MobileSheet from "@/components/MobileSheet";

const icons = [LayoutDashboard, Inbox, CalendarDays, CalendarRange, MessageCircle, Phone, Clock, Contact, FileText, Settings];

export default function AdminShell({ children, nav, unread, counts, user, labels }: { children: ReactNode; nav: [string, string][]; unread: number; counts: { requests: number; chat: number }; user: string; labels: { logout: string; site: string; newBooking: string; incoming: string; answer: string } }) {
  const locale = useLocale();
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [count, setCount] = useState(unread);
  const [chat, setChat] = useState(counts.chat);
  const [ringing, setRinging] = useState<{ id: string; patient: string }[]>([]);
  const last = useRef(unread);
  const audio = useRef<AudioContext | null>(null);

  // Poll for new alerts every 30s; play a soft chime when the count grows (only while the tab is open).
  useEffect(() => {
    const tick = async () => {
      try {
        const r = await fetch("/api/admin/notifications", { cache: "no-store" });
        if (!r.ok) return;
        const j = await r.json();
        setCount(j.unread); setChat(j.chat ?? 0); setRinging(j.ringing ?? []);
        if ((j.unread > last.current || (j.ringing ?? []).length) && j.sound) chime();
        last.current = j.unread;
      } catch {}
    };
    tick(); const id = setInterval(tick, 8_000);
    return () => clearInterval(id);
  }, []);
  useEffect(() => { setCount(unread); last.current = unread; }, [unread]);
  const chime = () => {
    try {
      audio.current ??= new AudioContext();
      const ctx = audio.current; const o = ctx.createOscillator(); const g = ctx.createGain();
      o.type = "sine"; o.frequency.setValueAtTime(880, ctx.currentTime); o.frequency.exponentialRampToValueAtTime(1320, ctx.currentTime + 0.15);
      g.gain.setValueAtTime(0.0001, ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.6);
      o.connect(g).connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.65);
    } catch {}
  };

  const base = "/admin";
  const isActive = (p: string) => (p === "" ? pathname === base : pathname.startsWith(base + p));
  const Nav = () => (
    <nav className="grid gap-1">
      {nav.map(([p, label], i) => { const I = icons[i]; return (
        <Link key={p} href={base + p} onClick={() => setOpen(false)} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium no-underline transition ${isActive(p) ? "bg-accent text-white dark:text-bg" : "text-ink-2 hover:bg-bg-2"}`}>
          <I size={17} /> {label}
          {p === "" && count > 0 && <span className="ml-auto rounded-full bg-danger px-2 text-[11px] font-bold text-white">{count}</span>}
          {p === "/requests" && counts.requests > 0 && <span className="ml-auto rounded-full bg-warn px-2 text-[11px] font-bold text-white">{counts.requests}</span>}
          {p === "/messages" && chat > 0 && <span className="ml-auto rounded-full bg-accent-2 px-2 text-[11px] font-bold text-white">{chat}</span>}
          {p === "/calls" && ringing.length > 0 && <span className="ml-auto rounded-full bg-danger px-2 text-[11px] font-bold text-white animate-pulse">{ringing.length}</span>}
        </Link>); })}
    </nav>
  );
  return (
    <div className="min-h-screen bg-bg-2 md:grid md:grid-cols-[250px_1fr]">
      <aside className="hidden md:flex md:flex-col md:gap-6 md:border-r md:border-line md:bg-bg md:p-5 md:sticky md:top-0 md:h-screen">
        <span className="flex items-center gap-3"><Logo href={base} h={40} alt="Sara" /><span className="chip bg-accent-soft text-accent">Admin</span></span>
        <Link href="/admin/appointments/new" className="btn btn-solid btn-sm"><Plus size={14} />{labels.newBooking}</Link>
        <Nav />
        <div className="mt-auto grid gap-2 text-sm">
          <Link href="/" className="flex items-center gap-2 text-ink-2 no-underline"><ExternalLink size={14} />{labels.site}</Link>
          <div className="flex items-center gap-2"><LocaleSwitch /><ThemeToggle /></div>
          <form action={() => logoutAction(locale)}><button className="flex items-center gap-2 text-ink-2" type="submit"><LogOut size={14} />{labels.logout} · {user}</button></form>
        </div>
      </aside>
      <div className="min-w-0">
        <header className="sticky top-0 z-[56] flex h-14 items-center justify-between border-b border-line bg-bg/80 px-4 backdrop-blur md:hidden">
          <button type="button" aria-label="menu" onClick={() => setOpen(!open)} className="rounded-full border border-line p-2">{open ? <X size={18} /> : <Menu size={18} />}</button>
          <span className="flex items-center gap-2"><Logo href={base} h={32} alt="Sara" /><span className="chip bg-accent-soft text-accent">Admin</span></span>
          <Link href={base} aria-label="alerts" className="relative rounded-full border border-line p-2"><Bell size={18} />{count > 0 && <span className="absolute -right-1 -top-1 rounded-full bg-danger px-1.5 text-[10px] font-bold text-white">{count}</span>}</Link>
        </header>
        <MobileSheet open={open} onClose={() => setOpen(false)}>
            <Link href="/admin/appointments/new" onClick={() => setOpen(false)} className="btn btn-solid btn-sm mb-3 w-full"><Plus size={14} />{labels.newBooking}</Link>
            <Nav />
            <div className="mt-4 flex items-center gap-2"><LocaleSwitch /><ThemeToggle /><form action={() => logoutAction(locale)} className="ml-auto"><button className="btn btn-ghost btn-sm" type="submit"><LogOut size={14} />{labels.logout}</button></form></div>
        </MobileSheet>
        {ringing.length > 0 && !pathname.startsWith("/admin/calls") && (
          <div className="sticky top-14 z-20 flex items-center justify-between gap-3 bg-accent px-4 py-3 text-white md:top-0 dark:text-bg">
            <span className="flex items-center gap-2 text-sm font-semibold"><Phone size={16} className="animate-pulse" /> {labels.incoming}: {ringing.map((r) => r.patient).join(", ")}</span>
            <Link href={`/admin/calls?answer=${ringing[0].id}`} className="btn btn-sm bg-white text-accent">{labels.answer}</Link>
          </div>
        )}
        <main className="mx-auto max-w-6xl p-4 md:p-8">{children}</main>
      </div>
    </div>
  );
}
