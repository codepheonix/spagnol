"use client";
import { useLocale } from "next-intl";
import { useTransition } from "react";
import { markNotificationsRead } from "@/app/[locale]/admin/actions";
export default function MarkReadButton({ label }: { label: string }) {
  const locale = useLocale(); const [p, start] = useTransition();
  return <button type="button" className="text-xs font-semibold text-accent" disabled={p} onClick={() => start(async () => { await markNotificationsRead(locale); })}>{label}</button>;
}
