"use client";
import { useLocale } from "next-intl";
import { Link, usePathname } from "@/i18n/navigation";
import { fmtDate } from "@/lib/fmt";

export default function InboxList({ rows, empty }: { rows: { patientId: string; name: string; lastAt: string; lastBody: string; unread: number }[]; empty: string }) {
  const locale = useLocale(); const pathname = usePathname();
  if (!rows.length) return <p className="card p-6 text-sm text-muted">{empty}</p>;
  return (
    <ul className="card divide-y divide-line overflow-hidden">
      {rows.map((r) => { const active = pathname.endsWith(`/messages/${r.patientId}`); return (
        <li key={r.patientId}><Link href={`/admin/messages/${r.patientId}`} className={`block px-4 py-3 no-underline transition hover:bg-bg-2 ${active ? "bg-accent-soft/60" : ""}`}>
          <div className="flex items-center justify-between gap-2"><p className={`truncate ${r.unread ? "font-bold" : "font-medium"}`}>{r.name}</p><span className="shrink-0 text-[11px] text-muted">{fmtDate(r.lastAt, locale, { day: "numeric", month: "short" })}</span></div>
          <div className="mt-0.5 flex items-center justify-between gap-2"><p className="truncate text-sm text-muted">{r.lastBody}</p>{r.unread > 0 && <span className="rounded-full bg-accent-2 px-2 text-[11px] font-bold text-white">{r.unread}</span>}</div>
        </Link></li>); })}
    </ul>
  );
}
