import { useTranslations } from "next-intl";
const cls: Record<string, string> = { pending: "bg-warn/10 text-warn", confirmed: "bg-accent-soft text-accent", rescheduled: "bg-accent-soft text-accent", completed: "bg-bg-2 text-ink-2", cancelled: "bg-danger/10 text-danger", no_show: "bg-danger/10 text-danger" };
export default function StatusChip({ status }: { status: string }) {
  const t = useTranslations("admin.status");
  return <span className={`chip ${cls[status] ?? ""}`}>{t(status as "pending")}</span>;
}
