"use client";
import { motion, useReducedMotion } from "motion/react";
import type { ReactNode } from "react";

/** Scroll entrance (Motion). Keeps the old API: as, className, delay. */
export default function Reveal({ children, className = "", as = "div", delay = 0, y = 24 }: { children: ReactNode; className?: string; as?: "div" | "section" | "article" | "li" | "p" | "h2"; delay?: number; y?: number }) {
  const reduce = useReducedMotion();
  const M = (motion as unknown as Record<string, typeof motion.div>)[as] ?? motion.div;
  return (
    <M className={className} initial={reduce ? false : { opacity: 0, y }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "0px 0px -10% 0px" }}
      transition={{ duration: 0.7, delay: delay / 1000, ease: [0.22, 1, 0.36, 1] }}>
      {children}
    </M>
  );
}
