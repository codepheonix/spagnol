"use client";
import { useState, useTransition } from "react";
import { useLocale, useTranslations } from "next-intl";
import { CheckCircle2 } from "lucide-react";
import { useRouter } from "@/i18n/navigation";
import SlotPicker from "./SlotPicker";
import { requestAppointmentAction, requestRescheduleAction } from "@/app/[locale]/app/actions";

type Service = { id: string; slug: string; titleIt: string; titleEn: string; descriptionIt: string; descriptionEn: string; durationMin: number };
/** New request (mode "new") or reschedule proposal (mode "reschedule" with appointmentId + fixed service). */
export default function RequestFlow({ services, mode, appointmentId, fixedServiceId }: { services: Service[]; mode: "new" | "reschedule"; appointmentId?: string; fixedServiceId?: string }) {
  const t = useTranslations("app.request");
  const locale = useLocale() as "it" | "en";
  const router = useRouter();
  const [serviceId, setServiceId] = useState(fixedServiceId ?? services[0]?.id ?? "");
  const [start, setStart] = useState<string | null>(null);
  const [notes, setNotes] = useState("");
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);
  const [pending, go] = useTransition();
  const svc = services.find((s) => s.id === serviceId);
  const submit = () => go(async () => {
    setError("");
    const r = mode === "new" ? await requestAppointmentAction({ serviceId, startISO: start!, notes }) : await requestRescheduleAction({ appointmentId: appointmentId!, startISO: start!, note: notes });
    if (r.ok) { setDone(true); setTimeout(() => router.push("/app/appointments"), 1600); } else setError(r.error === "slot_taken" ? t("slotTaken") : t("error"));
  });
  if (done) return <div className="card p-10 text-center"><CheckCircle2 className="mx-auto text-accent-2" size={40} /><p className="display mt-4 text-2xl">{mode === "new" ? t("done") : t("proposed")}</p></div>;
  return (
    <div className="grid gap-6">
      {mode === "new" && (
        <section className="card p-5 sm:p-6">
          <p className="label">{t("service")}</p>
          <div className="grid gap-2 sm:grid-cols-2">
            {services.map((s) => (
              <button key={s.id} type="button" onClick={() => { setServiceId(s.id); setStart(null); }} aria-pressed={s.id === serviceId} className={`rounded-2xl border p-4 text-left transition ${s.id === serviceId ? "border-accent bg-accent-soft/50" : "border-line hover:border-accent"}`}>
                <p className="font-semibold">{locale === "it" ? s.titleIt : s.titleEn}</p>
                <p className="mt-1 text-xs text-muted">{t("minutes", { n: s.durationMin })}</p>
                <p className="mt-1 line-clamp-2 text-sm text-ink-2">{locale === "it" ? s.descriptionIt : s.descriptionEn}</p>
              </button>))}
          </div>
        </section>
      )}
      <section className="card p-5 sm:p-6">
        {svc && <SlotPicker serviceKey={svc.slug} exclude={appointmentId} value={start} onChange={setStart} />}
      </section>
      <section className="card p-5 sm:p-6">
        <label className="label" htmlFor="notes">{t("notes")}</label>
        <textarea id="notes" className="input" rows={3} placeholder={t("notesHint")} value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={500} />
        {error && <p role="alert" className="mt-3 text-sm text-danger">{error}</p>}
        <button type="button" className="btn btn-solid mt-4" disabled={!start || pending} onClick={submit}>{pending ? t("sending") : mode === "new" ? t("submit") : t("propose")}</button>
      </section>
    </div>
  );
}
