"use client";
import { useState, useTransition } from "react";
import { Phone } from "lucide-react";
import CallPanel, { type CallLabels } from "../CallPanel";
import { startCallAction } from "@/app/[locale]/app/actions";

export default function PatientCall({ name, provider, initialCallId, labels }: { name: string; provider: string; initialCallId: string | null; labels: CallLabels & { start: string } }) {
  const [callId, setCallId] = useState<string | null>(initialCallId);
  const [pending, go] = useTransition();
  if (callId) return <CallPanel callId={callId} role="patient" name={name} provider={provider} labels={labels} />;
  return (
    <div className="card p-8 text-center">
      <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-accent-soft text-accent"><Phone size={26} /></span>
      <button type="button" className="btn btn-solid mt-6" disabled={pending} onClick={() => go(async () => { const r = await startCallAction(); setCallId(r.id); })}>{labels.start}</button>
      {provider === "demo" && <p className="mt-4 text-xs text-muted">{labels.demo}</p>}
    </div>
  );
}
