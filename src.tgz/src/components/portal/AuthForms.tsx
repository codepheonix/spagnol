"use client";
import { useActionState, useState } from "react";
import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import Turnstile from "../Turnstile";
import { loginAction, signupAction, magicAction, forgotAction, resetAction, type AuthState } from "@/app/[locale]/app/actions";

const err = (t: ReturnType<typeof useTranslations>, e?: string) => !e ? null : <p role="alert" className="rounded-xl bg-danger/10 p-3 text-sm font-medium text-danger">{t(e === "rate_limited" ? "rate" : e === "exists" ? "exists" : e === "token" ? "tokenInvalid" : e === "captcha" ? "captcha" : "invalid")}</p>;

export function LoginForm() {
  const t = useTranslations("app.auth");
  const [state, action, pending] = useActionState<AuthState, FormData>(loginAction, null);
  const [magic, mAction, mPending] = useActionState<AuthState, FormData>(magicAction, null);
  const [mode, setMode] = useState<"password" | "magic">("password");
  return mode === "password" ? (
    <form action={action} className="grid gap-4">
      <div><label className="label" htmlFor="email">{t("email")}</label><input id="email" name="email" type="email" className="input" required autoComplete="username" /></div>
      <div><label className="label" htmlFor="password">{t("password")}</label><input id="password" name="password" type="password" className="input" required autoComplete="current-password" /></div>
      {state?.error === "totp" && <div><label className="label" htmlFor="totp">{t("totp")}</label><input id="totp" name="totp" inputMode="numeric" pattern="[0-9]{6}" className="input" autoComplete="one-time-code" autoFocus /></div>}
      <Turnstile />
      {state?.error && state.error !== "totp" && err(t, state.error)}
      {state?.error === "totp" && <p className="rounded-xl bg-accent-soft p-3 text-sm font-medium text-accent">{t("totpRequired")}</p>}
      <button className="btn btn-solid mt-1" disabled={pending}>{t("login")}</button>
      <div className="flex flex-wrap justify-between gap-2 text-sm">
        <button type="button" className="font-semibold text-accent" onClick={() => setMode("magic")}>{t("magic")}</button>
        <Link href="/app/forgot" className="text-muted">{t("forgot")}</Link>
      </div>
      <p className="mt-3 text-sm text-muted">{t("noAccount")} <Link href="/app/signup" className="font-semibold text-accent">{t("signup")}</Link></p>
    </form>
  ) : (
    <form action={mAction} className="grid gap-4">
      <div><label className="label" htmlFor="m-email">{t("email")}</label><input id="m-email" name="email" type="email" className="input" required autoComplete="username" /></div>
      {magic?.sent ? <p className="rounded-xl bg-accent-soft p-3 text-sm font-medium text-accent">{t("magicSent")}</p> : <button className="btn btn-solid mt-1" disabled={mPending}>{t("magic")}</button>}
      {err(t, magic?.error)}
      <button type="button" className="text-sm font-semibold text-accent" onClick={() => setMode("password")}>{t("login")} →</button>
    </form>
  );
}

export function SignupForm() {
  const t = useTranslations("app.auth");
  const [state, action, pending] = useActionState<AuthState, FormData>(signupAction, null);
  return (
    <form action={action} className="grid gap-4">
      <div><label className="label" htmlFor="name">{t("name")}</label><input id="name" name="name" className="input" required minLength={2} autoComplete="name" /></div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div><label className="label" htmlFor="email">{t("email")}</label><input id="email" name="email" type="email" className="input" required autoComplete="email" /></div>
        <div><label className="label" htmlFor="phone">{t("phone")}</label><input id="phone" name="phone" type="tel" className="input" required autoComplete="tel" /></div>
      </div>
      <div><label className="label" htmlFor="password">{t("password")}</label><input id="password" name="password" type="password" className="input" required minLength={8} autoComplete="new-password" /><p className="mt-1 text-xs text-muted">{t("passwordHint")}</p></div>
      <label className="flex items-center gap-3 text-sm"><input type="checkbox" name="smsOptIn" className="h-4 w-4 accent-[var(--accent)]" /> {t("smsOptIn")}</label>
      <label className="flex items-center gap-3 text-sm"><input type="checkbox" required className="h-4 w-4 accent-[var(--accent)]" /> <span>{t("consent")} (<Link href="/privacy" className="text-accent">privacy</Link>)</span></label>
      <Turnstile />
      {err(t, state?.error)}
      <button className="btn btn-solid mt-1" disabled={pending}>{t("signup")}</button>
      <p className="text-sm text-muted">{t("haveAccount")} <Link href="/app/login" className="font-semibold text-accent">{t("login")}</Link></p>
    </form>
  );
}

export function ForgotForm() {
  const t = useTranslations("app.auth");
  const [state, action, pending] = useActionState<AuthState, FormData>(forgotAction, null);
  return (
    <form action={action} className="grid gap-4">
      <div><label className="label" htmlFor="email">{t("email")}</label><input id="email" name="email" type="email" className="input" required /></div>
      {state?.sent ? <p className="rounded-xl bg-accent-soft p-3 text-sm font-medium text-accent">{t("magicSent")}</p> : <button className="btn btn-solid" disabled={pending}>{t("reset")}</button>}
    </form>
  );
}

export function ResetForm({ token }: { token: string }) {
  const t = useTranslations("app.auth");
  const [state, action, pending] = useActionState<AuthState, FormData>(resetAction, null);
  return (
    <form action={action} className="grid gap-4">
      <input type="hidden" name="token" value={token} />
      <div><label className="label" htmlFor="password">{t("password")}</label><input id="password" name="password" type="password" className="input" required minLength={8} autoComplete="new-password" /><p className="mt-1 text-xs text-muted">{t("passwordHint")}</p></div>
      {err(t, state?.error)}
      <button className="btn btn-solid" disabled={pending}>{t("reset")}</button>
    </form>
  );
}
