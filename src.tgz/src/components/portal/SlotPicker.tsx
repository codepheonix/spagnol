"use client";
import { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useLocale, useTranslations } from "next-intl";

type Day = "past" | "closed" | "available" | "full";
/** Month calendar + time slots for one service. Only real free times are shown (server-computed). */
export default function SlotPicker({ serviceKey, exclude, value, onChange }: { serviceKey: string; exclude?: string; value: string | null; onChange: (iso: string | null) => void }) {
  const t = useTranslations("app.request"); const c = useTranslations("common");
  const locale = useLocale();
  const [month, setMonth] = useState(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`; });
  const [days, setDays] = useState<Record<string, Day>>({});
  const [date, setDate] = useState<string | null>(null);
  const [slots, setSlots] = useState<{ start: string; label: string }[] | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { setDays({}); fetch(`/api/availability?service=${serviceKey}&month=${month}`).then((r) => r.json()).then((j) => setDays(j.days ?? {})).catch(() => {}); }, [serviceKey, month]);
  useEffect(() => {
    if (!date) return; setSlots(null); setBusy(true); onChange(null);
    fetch(`/api/availability?service=${serviceKey}&date=${date}${exclude ? `&exclude=${exclude}` : ""}`).then((r) => r.json()).then((j) => setSlots(j.slots ?? [])).catch(() => setSlots([])).finally(() => setBusy(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date, serviceKey]);
  const [y, m] = month.split("-").map(Number);
  const first = new Date(y, m - 1, 1), offset = (first.getDay() + 6) % 7, dim = new Date(y, m, 0).getDate();
  const weekdays: string[] = c.raw("weekdays");
  const title = first.toLocaleDateString(locale, { month: "long", year: "numeric" });
  const shift = (d: number) => { const n = new Date(y, m - 1 + d, 1); setMonth(`${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, "0")}`); };
  return (
    <div className="grid gap-6 md:grid-cols-[1.1fr_1fr]">
      <div>
        <div className="flex items-center justify-between"><button type="button" className="btn btn-ghost btn-sm !px-2" onClick={() => shift(-1)} aria-label="prev"><ChevronLeft size={16} /></button><p className="font-semibold capitalize">{title}</p><button type="button" className="btn btn-ghost btn-sm !px-2" onClick={() => shift(1)} aria-label="next"><ChevronRight size={16} /></button></div>
        <div className="mt-3 grid grid-cols-7 gap-1 text-center text-[11px] font-semibold uppercase tracking-wider text-muted">{weekdays.map((w) => <span key={w}>{w}</span>)}</div>
        <div className="mt-1 grid grid-cols-7 gap-1">
          {Array.from({ length: offset }).map((_, i) => <span key={`o${i}`} />)}
          {Array.from({ length: dim }).map((_, i) => { const iso = `${month}-${String(i + 1).padStart(2, "0")}`; const st = days[iso]; const ok = st === "available"; return (
            <button key={iso} type="button" disabled={!ok} onClick={() => setDate(iso)} aria-pressed={date === iso}
              className={`aspect-square rounded-xl text-sm font-medium transition ${date === iso ? "bg-accent text-white dark:text-bg" : ok ? "bg-surface border border-line hover:border-accent" : "text-muted/40 line-through"} ${st === "full" ? "bg-bg-2 no-underline text-muted" : ""}`}>{i + 1}</button>); })}
        </div>
        <div className="mt-3 flex gap-4 text-xs text-muted"><span className="flex items-center gap-1"><i className="h-3 w-3 rounded border border-line bg-surface" />{t("legend.free")}</span><span className="flex items-center gap-1"><i className="h-3 w-3 rounded bg-bg-2" />{t("legend.busy")}</span></div>
      </div>
      <div>
        <p className="label">{t("time")}</p>
        {!date ? <p className="text-sm text-muted">{t("date")} →</p> : busy ? <p className="text-sm text-muted">{t("loading")}</p> : slots && slots.length === 0 ? <p className="text-sm text-muted">{t("noSlots")}</p> : (
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">{slots?.map((s) => <button key={s.start} type="button" onClick={() => onChange(s.start)} aria-pressed={value === s.start} className={`h-10 rounded-xl text-sm font-medium transition ${value === s.start ? "bg-accent text-white dark:text-bg" : "border border-line bg-surface hover:border-accent"}`}>{s.label}</button>)}</div>
        )}
      </div>
    </div>
  );
}
