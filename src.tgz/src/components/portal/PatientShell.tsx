"use client";
import { useEffect, useState, type ReactNode } from "react";
import { CalendarDays, LayoutDashboard, LogOut, MessageCircle, Phone, UserRound, ArrowUpRight, Menu, X, FolderOpen } from "lucide-react";
import { Link, usePathname } from "@/i18n/navigation";
import ThemeToggle from "../ThemeToggle";
import LocaleSwitch from "../LocaleSwitch";
import { logoutPatientAction } from "@/app/[locale]/app/actions";
import Logo from "@/components/Logo";
import MobileSheet from "@/components/MobileSheet";

const icons = [LayoutDashboard, CalendarDays, MessageCircle, FolderOpen, Phone, UserRound];

export default function PatientShell({ children, nav, name, practice, unread, labels }: { children: ReactNode; nav: [string, string][]; name: string; practice: string; unread: number; labels: { logout: string; site: string } }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [count, setCount] = useState(unread);
  const [incoming, setIncoming] = useState<string | null>(null);
  useEffect(() => { setCount(unread); }, [unread]);
  // light polling for unread + incoming calls
  useEffect(() => {
    const tick = async () => { try { const r = await fetch("/api/chat?since=" + new Date(Date.now() - 5000).toISOString(), { cache: "no-store" }); if (!r.ok) return; const j = await r.json(); if (j.messages?.some((m: { sender: string }) => m.sender === "admin")) setCount((c) => c + 1); setIncoming(j.call && j.call.status === "ringing" && j.call.startedBy === "admin" ? j.call.id : null); } catch {} };
    const id = setInterval(tick, 5000); return () => clearInterval(id);
  }, []);
  const base = "/app";
  const isActive = (p: string) => (p === "" ? pathname === base : pathname.startsWith(base + p));
  const Nav = () => (
    <nav className="grid gap-1">
      {nav.map(([p, label], i) => { const I = icons[i]; return (
        <Link key={p} href={base + p} onClick={() => setOpen(false)} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium no-underline transition ${isActive(p) ? "bg-accent text-white dark:text-bg" : "text-ink-2 hover:bg-bg-2"}`}>
          <I size={17} /> {label}
          {p === "/messages" && count > 0 && <span className="ml-auto rounded-full bg-danger px-2 text-[11px] font-bold text-white">{count}</span>}
        </Link>); })}
    </nav>
  );
  return (
    <div className="min-h-screen bg-bg-2 md:grid md:grid-cols-[250px_1fr]">
      <aside className="hidden md:sticky md:top-0 md:flex md:h-screen md:flex-col md:gap-6 md:border-r md:border-line md:bg-bg md:p-5">
        <Logo h={40} alt={practice} />
        <Nav />
        <div className="mt-auto grid gap-3">
          <Link href="/" className="flex items-center gap-2 text-sm text-muted no-underline"><ArrowUpRight size={14} /> {labels.site}</Link>
          <div className="flex items-center gap-2"><LocaleSwitch /><ThemeToggle /></div>
          <p className="truncate text-sm font-medium">{name}</p>
          <form action={logoutPatientAction}><button className="flex items-center gap-2 text-sm text-muted"><LogOut size={14} /> {labels.logout}</button></form>
        </div>
      </aside>
      <div className="flex min-h-screen flex-col">
        <header className="sticky top-0 z-[56] flex h-14 items-center justify-between border-b border-line bg-bg/80 px-4 backdrop-blur md:hidden">
          <Logo href="/app" h={34} alt={practice} />
          <button type="button" aria-label="menu" className="grid h-9 w-9 place-items-center rounded-full border border-line" onClick={() => setOpen((v) => !v)}>{open ? <X size={16} /> : <Menu size={16} />}</button>
        </header>
        <MobileSheet open={open} onClose={() => setOpen(false)}><Nav /><div className="mt-4 flex items-center gap-2"><LocaleSwitch /><ThemeToggle /><form action={logoutPatientAction} className="ml-auto"><button className="btn btn-ghost btn-sm">{labels.logout}</button></form></div></MobileSheet>
        {incoming && (
          <div className="sticky top-14 z-20 flex items-center justify-between gap-3 bg-accent px-4 py-3 text-white md:top-0 dark:text-bg">
            <span className="flex items-center gap-2 text-sm font-semibold"><Phone size={16} className="animate-pulse" /> Sara…</span>
            <Link href={`/app/call?answer=${incoming}`} className="btn btn-sm bg-white text-accent">📞</Link>
          </div>
        )}
        <main className="flex-1 p-4 sm:p-8">{children}</main>
      </div>
    </div>
  );
}
