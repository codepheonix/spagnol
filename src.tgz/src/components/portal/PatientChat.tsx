"use client";
import { useCallback, useState } from "react";
import { Phone } from "lucide-react";
import { Link } from "@/i18n/navigation";
import ChatThread from "../ChatThread";

export default function PatientChat({ initial, labels }: { initial: { id: string; sender: string; body: string; createdAt: string; replyToId?: string | null; attachments?: { url: string; name: string; size: number; type: string }[] }[]; labels: Record<"placeholder" | "send" | "empty" | "you" | "other" | "incoming" | "answer" | "reply" | "attach" | "uploading" | "tooBig", string> }) {
  const [incoming, setIncoming] = useState<string | null>(null);
  const onCall = useCallback((id: string) => setIncoming(id), []);
  return (
    <>
      {incoming && <div className="mb-3 flex items-center justify-between rounded-2xl bg-accent p-3 text-white dark:text-bg"><span className="flex items-center gap-2 text-sm font-semibold"><Phone size={16} className="animate-pulse" /> {labels.incoming}</span><Link href={`/app/call?answer=${incoming}`} className="btn btn-sm bg-white text-accent">{labels.answer}</Link></div>}
      <ChatThread me="patient" initial={initial} labels={labels} onIncomingCall={onCall} />
    </>
  );
}
