"use client";
import { useActionState } from "react";
import { useTranslations } from "next-intl";
import { profileAction, passwordAction, type AuthState } from "@/app/[locale]/app/actions";

export default function ProfileForms({ patient }: { patient: { name: string; email: string; phone: string; locale: string; smsOptIn: boolean; emailOptIn: boolean; birthDate: string } }) {
  const t = useTranslations("app.profile");
  const [ps, pAction, pPending] = useActionState<AuthState, FormData>(profileAction, null);
  const [ws, wAction, wPending] = useActionState<AuthState, FormData>(passwordAction, null);
  return (
    <>
      <form action={pAction} className="card mt-8 grid gap-4 p-6">
        <h2 className="font-semibold">{t("personal")}</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><label className="label" htmlFor="name">{t("name")}</label><input id="name" name="name" className="input" defaultValue={patient.name} required /></div>
          <div><label className="label" htmlFor="email">{t("email")}</label><input id="email" className="input" value={patient.email} disabled /></div>
          <div><label className="label" htmlFor="phone">{t("phone")}</label><input id="phone" name="phone" className="input" defaultValue={patient.phone} required /></div>
          <div><label className="label" htmlFor="birthDate">{t("birth")}</label><input id="birthDate" name="birthDate" type="date" className="input" defaultValue={patient.birthDate} /></div>
          <div><label className="label" htmlFor="locale">{t("lang")}</label><select id="locale" name="locale" className="input" defaultValue={patient.locale}><option value="it">Italiano</option><option value="en">English</option></select></div>
        </div>
        <label className="flex items-center gap-3 text-sm"><input type="checkbox" name="smsOptIn" defaultChecked={patient.smsOptIn} className="h-4 w-4 accent-[var(--accent)]" /> {t("sms")}</label>
        <label className="flex items-center gap-3 text-sm"><input type="checkbox" name="emailOptIn" defaultChecked={patient.emailOptIn} className="h-4 w-4 accent-[var(--accent)]" /> {t("emailOpt")}</label>
        {ps?.sent && <p className="text-sm font-medium text-accent-2">{t("saved")}</p>}
        <button className="btn btn-solid w-fit" disabled={pPending}>{t("save")}</button>
      </form>
      <form action={wAction} className="card mt-6 grid gap-4 p-6">
        <h2 className="font-semibold">{t("password")}</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><label className="label" htmlFor="current">{t("current")}</label><input id="current" name="current" type="password" className="input" required autoComplete="current-password" /></div>
          <div><label className="label" htmlFor="new">{t("new")}</label><input id="new" name="new" type="password" className="input" required minLength={8} autoComplete="new-password" /></div>
        </div>
        {ws?.sent && <p className="text-sm font-medium text-accent-2">{t("changed")}</p>}
        {ws?.error && <p className="text-sm text-danger">{t(ws.error === "wrong" ? "wrong" : "wrong")}</p>}
        <button className="btn btn-ghost w-fit" disabled={wPending}>{t("save")}</button>
      </form>
    </>
  );
}
