"use client";
import { useState, useTransition } from "react";
import { CalendarDays, Repeat, X } from "lucide-react";
import { Link } from "@/i18n/navigation";
import { cancelAppointmentAction, withdrawRescheduleAction } from "@/app/[locale]/app/actions";

export default function ApptActions({ id, reference, editable, rescheduleId, labels }: { id: string; reference: string; editable: boolean; rescheduleId: string | null; labels: Record<"reschedule" | "cancel" | "cancelConfirm" | "cutoff" | "withdraw" | "ics", string> }) {
  const [pending, start] = useTransition();
  const [msg, setMsg] = useState("");
  if (!editable) return <p className="max-w-[28ch] text-sm text-muted">{labels.cutoff}</p>;
  return (
    <div className="flex flex-wrap gap-2">
      <a href={`/api/ics/${reference}`} className="btn btn-ghost btn-sm"><CalendarDays size={14} /> {labels.ics}</a>
      {rescheduleId ? (
        <button className="btn btn-ghost btn-sm" disabled={pending} onClick={() => start(async () => { await withdrawRescheduleAction(rescheduleId); })}><X size={14} /> {labels.withdraw}</button>
      ) : <Link href={`/app/appointments/${id}/reschedule`} className="btn btn-ghost btn-sm"><Repeat size={14} /> {labels.reschedule}</Link>}
      <button className="btn btn-ghost btn-sm text-danger" disabled={pending} onClick={() => { if (confirm(labels.cancelConfirm)) start(async () => { const r = await cancelAppointmentAction(id); if (!r.ok) setMsg(labels.cutoff); }); }}>{labels.cancel}</button>
      {msg && <p className="w-full text-sm text-danger">{msg}</p>}
    </div>
  );
}
