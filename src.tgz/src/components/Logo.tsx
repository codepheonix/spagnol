import { Link } from "@/i18n/navigation";

/** Sara's wordmark (brown on light, off-white on dark). `mark` shows only the dancing figure. */
export default function Logo({ href = "/", h = 36, mark = false, className = "", alt = "Sara", onClick }: { href?: string; h?: number; mark?: boolean; className?: string; alt?: string; onClick?: () => void }) {
  const base = mark ? "mark" : "logo";
  const w = Math.round(h * (mark ? 268 / 461 : 1555 / 757));
  return (
    <Link href={href} onClick={onClick} className={`inline-flex shrink-0 items-center no-underline ${className}`} aria-label={alt}>
      <img src={`/brand/${base}-brown.png`} alt={alt} width={w} height={h} style={{ height: h, width: "auto" }} className="block dark:hidden" />
      <img src={`/brand/${base}-white.png`} alt="" aria-hidden="true" width={w} height={h} style={{ height: h, width: "auto" }} className="hidden dark:block" />
    </Link>
  );
}
