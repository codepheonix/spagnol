"use client";
import { useEffect, useState } from "react";
import { Moon, Sun } from "lucide-react";

export default function ThemeToggle({ className = "" }: { className?: string }) {
  const [dark, setDark] = useState(false);
  useEffect(() => { setDark(document.documentElement.classList.contains("dark")); }, []);
  const toggle = () => {
    const next = !dark; setDark(next);
    document.documentElement.classList.toggle("dark", next);
    try { localStorage.setItem("theme", next ? "dark" : "light"); } catch {}
    document.cookie = `theme=${next ? "dark" : "light"}; path=/; max-age=31536000; SameSite=Lax`;
  };
  return (
    <button type="button" onClick={toggle} aria-label={dark ? "Light theme" : "Dark theme"} aria-pressed={dark}
      className={`inline-flex h-10 w-10 items-center justify-center rounded-full border border-line bg-surface/70 text-ink-2 backdrop-blur hover:text-accent ${className}`}>
      {dark ? <Sun size={17} /> : <Moon size={17} />}
    </button>
  );
}
