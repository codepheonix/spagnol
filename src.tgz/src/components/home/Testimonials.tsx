"use client";
import { useEffect, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { ChevronLeft, ChevronRight, Pause, Play, Quote } from "lucide-react";

export default function Testimonials({ items }: { items: { name: string; text: string }[] }) {
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const reduce = useReducedMotion();
  useEffect(() => {
    if (paused || reduce) return;
    const id = setInterval(() => setI((v) => (v + 1) % items.length), 6000);
    return () => clearInterval(id);
  }, [paused, reduce, items.length]);
  const t = items[i];
  return (
    <div className="card relative p-8 sm:p-12" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)} onFocus={() => setPaused(true)} onBlur={() => setPaused(false)}>
      <Quote className="absolute right-8 top-8 text-accent opacity-30" size={40} aria-hidden />
      <div className="min-h-[140px]" aria-live="polite">
        <AnimatePresence mode="wait">
          <motion.figure key={i} initial={reduce ? false : { opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={reduce ? undefined : { opacity: 0, y: -8 }} transition={{ duration: 0.4 }}>
            <blockquote className="display text-[clamp(22px,2.6vw,34px)] leading-snug">“{t.text}”</blockquote>
            <figcaption className="mt-5 flex items-center gap-3 text-sm font-semibold text-muted">
              <span className="grid h-9 w-9 place-items-center rounded-full bg-accent-soft text-accent">{t.name[0]}</span>{t.name}
            </figcaption>
          </motion.figure>
        </AnimatePresence>
      </div>
      <div className="mt-6 flex items-center justify-between">
        <div className="flex gap-2" role="tablist" aria-label="testimonials">
          {items.map((_, k) => <button key={k} type="button" role="tab" aria-selected={k === i} aria-label={`${k + 1}/${items.length}`} onClick={() => setI(k)} className={`h-2 rounded-full transition-all ${k === i ? "w-8 bg-accent" : "w-2 bg-line"}`} />)}
        </div>
        <div className="flex gap-2">
          <button type="button" className="btn btn-ghost btn-sm !px-2" aria-label={paused ? "play" : "pause"} onClick={() => setPaused((p) => !p)}>{paused ? <Play size={14} /> : <Pause size={14} />}</button>
          <button type="button" className="btn btn-ghost btn-sm !px-2" aria-label="previous" onClick={() => setI((v) => (v - 1 + items.length) % items.length)}><ChevronLeft size={16} /></button>
          <button type="button" className="btn btn-ghost btn-sm !px-2" aria-label="next" onClick={() => setI((v) => (v + 1) % items.length)}><ChevronRight size={16} /></button>
        </div>
      </div>
    </div>
  );
}
