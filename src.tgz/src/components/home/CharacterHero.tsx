"use client";
import { useEffect, useRef, useState } from "react";
import { useReducedMotion } from "motion/react";
import { ArrowRight } from "lucide-react";
import { Link } from "@/i18n/navigation";

type Api = { setPointer: (x: number, y: number) => void; setPaused: (v: boolean) => void; destroy: () => void };

/**
 * Four-layer cursor hero: L1 background blobs (DOM), L2 back props + L3 character (WebGL), L4 foreground bokeh,
 * pills and the headline (DOM). Every layer moves at its own depth with the pointer (or device tilt on phones).
 */
export default function CharacterHero({ eyebrow, title, titleAccent, text, cta, secondary, hint }: { eyebrow: string; title: string; titleAccent: string; text: string; cta: { label: string; href: string }; secondary?: { label: string; href: string }; hint: string }) {
  const stage = useRef<HTMLDivElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);
  const reduce = useReducedMotion();

  useEffect(() => {
    const cv = canvas.current!, st = stage.current!;
    if (!(cv.getContext("webgl2") || cv.getContext("webgl"))) { setFailed(true); return; }
    let api: Api | null = null, alive = true;
    const ptr = { x: 0, y: 0, tx: 0, ty: 0 }; let raf = 0, last = performance.now();
    const layers = [...st.querySelectorAll<HTMLElement>("[data-depth]")].map((el) => ({ el, d: parseFloat(el.dataset.depth!) }));
    import("@/three/character.js").then((m) => { if (!alive) return; api = m.createCharacterScene(cv, { reducedMotion: !!reduce, onReady: () => setReady(true), onError: () => setFailed(true) }) as Api; }).catch(() => setFailed(true));
    const move = (e: PointerEvent) => { ptr.tx = (e.clientX / innerWidth) * 2 - 1; ptr.ty = (e.clientY / innerHeight) * 2 - 1; };
    const leave = () => { ptr.tx = 0; ptr.ty = 0; };
    const tilt = (e: DeviceOrientationEvent) => { if (e.gamma == null || e.beta == null) return; ptr.tx = Math.max(-1, Math.min(1, e.gamma / 30)); ptr.ty = Math.max(-1, Math.min(1, (e.beta - 45) / 30)); };
    const tick = (now: number) => {
      raf = requestAnimationFrame(tick); const dt = Math.min((now - last) / 1000, 0.05); last = now;
      if (reduce) return;
      ptr.x += (ptr.tx - ptr.x) * (1 - Math.exp(-5 * dt)); ptr.y += (ptr.ty - ptr.y) * (1 - Math.exp(-5 * dt));
      for (const { el, d } of layers) el.style.transform = `translate3d(${(-ptr.x * d * innerWidth).toFixed(1)}px, ${(-ptr.y * d * innerHeight).toFixed(1)}px, 0)`;
      api?.setPointer(ptr.x, ptr.y);
    };
    raf = requestAnimationFrame(tick);
    const io = new IntersectionObserver(([en]) => api?.setPaused(!en.isIntersecting)); io.observe(st);
    addEventListener("pointermove", move, { passive: true }); addEventListener("pointerleave", leave);
    if ("ontouchstart" in window) addEventListener("deviceorientation", tilt);
    return () => { alive = false; cancelAnimationFrame(raf); io.disconnect(); removeEventListener("pointermove", move); removeEventListener("pointerleave", leave); removeEventListener("deviceorientation", tilt); api?.destroy(); };
  }, [reduce]);

  return (
    <section ref={stage} className="relative h-[100svh] min-h-[640px] overflow-hidden bg-bg" aria-label={`${title} ${titleAccent}`}>
      {/* L1 background */}
      <div data-depth="0.015" className="absolute -inset-[6%] will-change-transform">
        <div className="absolute inset-0 bg-[radial-gradient(60%_70%_at_70%_30%,var(--bg-2),transparent_70%)]" />
        <div className="absolute left-[48%] top-[-10%] h-[46vw] w-[46vw] rounded-full bg-[#eadfd0] opacity-90 blur-[70px] dark:bg-[#3a2f26]" />
        <div className="absolute left-[62%] top-[55%] h-[32vw] w-[32vw] rounded-full bg-[#d9e6e0] opacity-70 blur-[70px] dark:bg-[#223630]" />
        <div className="absolute left-[-6%] top-[60%] h-[26vw] w-[26vw] rounded-full bg-[#e3e9f1] opacity-90 blur-[70px] dark:bg-[#26303c]" />
      </div>
      {/* L2 + L3 */}
      <canvas ref={canvas} aria-hidden="true" className="absolute inset-0 h-full w-full transition-opacity duration-700" style={{ opacity: ready && !failed ? 1 : 0 }} />
      {failed && <div aria-hidden="true" className="absolute right-[8%] top-[22%] hidden h-[50vh] w-[36vw] rounded-[48px] bg-accent-soft md:block" />}
      {/* L4 foreground */}
      <div data-depth="-0.06" className="pointer-events-none absolute -inset-[6%] will-change-transform">
        <div className="absolute left-[4%] top-[62%] hidden h-[220px] w-[220px] rounded-full bg-[#e6dccd] opacity-60 blur-[14px] md:block dark:bg-[#3a2f26]" />
        <div className="absolute left-[84%] top-[8%] h-[140px] w-[140px] rounded-full bg-[#d9e6e0] opacity-60 blur-[14px] dark:bg-[#223630]" />
        <div className="absolute left-[70%] top-[78%] h-[90px] w-[90px] rounded-full bg-[#e3e9f1] opacity-60 blur-[14px] dark:bg-[#26303c]" />
        <span className="pill absolute left-[58%] top-[14%] rotate-[25deg] bg-gradient-to-b from-[#c9a57a] to-[#eadfd0]" />
        <span className="pill absolute left-[90%] top-[58%] -rotate-[30deg] bg-gradient-to-b from-[#9fb9d1] to-[#e3e9f1] [animation-delay:-2s]" />
        <span className="pill absolute left-[38%] top-[82%] rotate-[60deg] bg-gradient-to-b from-[#8fbfae] to-[#d9e6e0] [animation-delay:-4s]" />
      </div>
      <div className="gut absolute bottom-[10%] max-w-[min(600px,86vw)] landscape:top-1/2 landscape:bottom-auto landscape:-translate-y-1/2">
        <div data-depth="0.02" className="will-change-transform">
          <p className="eyebrow mb-4">{eyebrow}</p>
          <h1 className="display text-[clamp(42px,6.4vw,88px)] text-ink">{title} <em className="not-italic text-accent">{titleAccent}</em></h1>
          <p className="lede mt-5">{text}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href={cta.href} className="btn btn-solid">{cta.label} <ArrowRight size={16} /></Link>
            {secondary && <a href={secondary.href} className="btn btn-ghost">{secondary.label}</a>}
          </div>
        </div>
      </div>
      <p className="absolute bottom-6 left-1/2 -translate-x-1/2 text-[11px] font-semibold uppercase tracking-[0.22em] text-muted">{hint}</p>
    </section>
  );
}
