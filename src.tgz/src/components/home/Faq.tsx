"use client";
import { useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { Plus } from "lucide-react";

export default function Faq({ items }: { items: { q: string; a: string }[] }) {
  const [open, setOpen] = useState<number | null>(0);
  const reduce = useReducedMotion();
  return (
    <div className="grid gap-2">
      {items.map((f, i) => {
        const on = open === i;
        return (
          <div key={i} className="card px-6 py-2">
            <button type="button" className="flex w-full cursor-pointer items-center justify-between py-3 text-left text-lg font-semibold" aria-expanded={on} aria-controls={`faq-${i}`} onClick={() => setOpen(on ? null : i)}>
              {f.q}<motion.span animate={{ rotate: on ? 45 : 0 }} transition={{ duration: 0.25 }} className="ml-4 text-accent"><Plus size={18} /></motion.span>
            </button>
            <AnimatePresence initial={false}>
              {on && (
                <motion.div id={`faq-${i}`} initial={reduce ? false : { height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={reduce ? undefined : { height: 0, opacity: 0 }} transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }} className="overflow-hidden">
                  <p className="pb-4 text-ink-2">{f.a}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
}
