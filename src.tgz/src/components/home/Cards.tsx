"use client";
import { motion, useReducedMotion } from "motion/react";
import type { ReactNode } from "react";

/** Staggered grid of cards with hover lift. */
export function CardGrid({ children, className = "" }: { children: ReactNode; className?: string }) {
  const reduce = useReducedMotion();
  return (
    <motion.ul className={className} initial="hidden" whileInView="show" viewport={{ once: true, margin: "0px 0px -10% 0px" }} variants={{ hidden: {}, show: { transition: { staggerChildren: reduce ? 0 : 0.08 } } }}>
      {children}
    </motion.ul>
  );
}
export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  const reduce = useReducedMotion();
  return (
    <motion.li className={`card ${className}`} variants={{ hidden: reduce ? {} : { opacity: 0, y: 18, scale: 0.98 }, show: { opacity: 1, y: 0, scale: 1 } }} transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }} whileHover={reduce ? undefined : { y: -4 }}>
      {children}
    </motion.li>
  );
}
