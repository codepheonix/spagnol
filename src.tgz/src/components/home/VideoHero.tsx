"use client";
import { useEffect, useRef, useState } from "react";
import { motion, useReducedMotion } from "motion/react";
import { ArrowRight, Pause, Play } from "lucide-react";
import { Link } from "@/i18n/navigation";

type Variant = "mobile" | "tablet" | "1080" | "1440";
/** Portrait phones get a 9:16 re-framed cut, portrait tablets a 3:4 cut, large monitors the 1440p master. */
function pick(): Variant {
  const w = innerWidth, h = innerHeight, portrait = h > w;
  if (portrait && w < 700) return "mobile";
  if (portrait) return "tablet";
  // the 1440p file is ~12 MB; only worth it on big, sharp screens
  if (w * devicePixelRatio >= 2200 && w >= 1400) return "1440";
  return "1080";
}
const SRC: Record<Variant, { video: string; poster: string }> = {
  mobile: { video: "/video/hero-mobile.mp4", poster: "/video/hero-poster-mobile.webp" },
  tablet: { video: "/video/hero-tablet.mp4", poster: "/video/hero-poster-tablet.webp" },
  "1080": { video: "/video/hero-1080.mp4", poster: "/video/hero-poster.webp" },
  "1440": { video: "/video/hero-1440.mp4", poster: "/video/hero-poster.webp" },
};

/** Full-bleed homepage video (muted, looping, paused off-screen) with the headline over a soft gradient. */
export default function VideoHero({ eyebrow, title, titleAccent, text, cta, secondary, pauseLabel, playLabel }: { eyebrow: string; title: string; titleAccent: string; text: string; cta: { label: string; href: string }; secondary?: { label: string; href: string }; pauseLabel: string; playLabel: string }) {
  const video = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(true);
  const [variant, setVariant] = useState<Variant | null>(null);
  const reduce = useReducedMotion();
  // choose the file for this screen; re-choose when the device rotates or the window crosses a breakpoint
  useEffect(() => {
    const choose = () => setVariant((v) => { const n = pick(); return n === v ? v : n; });
    choose(); addEventListener("resize", choose); addEventListener("orientationchange", choose);
    return () => { removeEventListener("resize", choose); removeEventListener("orientationchange", choose); };
  }, []);
  useEffect(() => {
    const v = video.current; if (!v || !variant) return;
    const t = v.currentTime; v.src = SRC[variant].video; v.currentTime = t;
    if (reduce) { v.pause(); setPlaying(false); return; }
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) v.play().catch(() => setPlaying(false)); else v.pause(); }, { threshold: 0.2 });
    io.observe(v); return () => io.disconnect();
  }, [variant, reduce]);
  const toggle = () => { const v = video.current!; if (v.paused) { v.play(); setPlaying(true); } else { v.pause(); setPlaying(false); } };
  const fade = (d: number) => ({ initial: { opacity: 0, y: 18 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.8, delay: d, ease: [0.22, 1, 0.36, 1] as const } });
  const portrait = variant === "mobile" || variant === "tablet";
  return (
    <section className="relative h-[100svh] min-h-[560px] overflow-hidden bg-bg [@media(max-height:500px)]:min-h-0" aria-label={`${title} ${titleAccent}`}>
      <video ref={video} className={`absolute inset-0 h-full w-full object-cover ${portrait ? "object-[center_30%]" : "object-[62%_center] 2xl:object-[80%_center]"}`} poster={SRC[variant ?? "1080"].poster} muted loop playsInline autoPlay preload="metadata" aria-hidden="true" />
      {/* legibility: gradient from the left on landscape screens, from the bottom on portrait */}
      <div aria-hidden="true" className="absolute inset-0 bg-[linear-gradient(90deg,color-mix(in_srgb,var(--bg)_92%,transparent)_0%,color-mix(in_srgb,var(--bg)_72%,transparent)_26%,transparent_46%)] [@media(max-height:500px)]:bg-[linear-gradient(90deg,color-mix(in_srgb,var(--bg)_94%,transparent)_0%,color-mix(in_srgb,var(--bg)_80%,transparent)_45%,transparent_70%)] portrait:bg-[linear-gradient(0deg,var(--bg)_22%,color-mix(in_srgb,var(--bg)_70%,transparent)_46%,transparent_70%)]" />
      <div className="gut absolute inset-x-0 bottom-[max(7%,env(safe-area-inset-bottom))] landscape:top-1/2 landscape:bottom-auto landscape:-translate-y-1/2">
        <div className="max-w-[620px] 2xl:max-w-[700px]">
          <motion.p className="eyebrow mb-3 sm:mb-4 [@media(max-height:500px)]:mb-1" {...fade(0.1)}>{eyebrow}</motion.p>
          <motion.h1 className="display text-[clamp(38px,6.4vw,88px)] [@media(max-height:500px)]:text-[clamp(26px,5vw,40px)] text-ink" {...fade(0.2)}>{title} <em className="not-italic text-accent">{titleAccent}</em></motion.h1>
          <motion.p className="lede mt-4 max-w-[46ch] sm:mt-5 [@media(max-height:500px)]:mt-2 [@media(max-height:500px)]:text-[15px]" {...fade(0.35)}>{text}</motion.p>
          <motion.div className="mt-6 flex flex-wrap gap-3 sm:mt-8 [@media(max-height:500px)]:mt-3" {...fade(0.5)}>
            <Link href={cta.href} className="btn btn-solid">{cta.label} <ArrowRight size={16} /></Link>
            {secondary && <a href={secondary.href} className="btn btn-ghost">{secondary.label}</a>}
          </motion.div>
        </div>
      </div>
      <button type="button" onClick={toggle} aria-label={playing ? pauseLabel : playLabel} className="absolute right-4 top-[max(84px,calc(env(safe-area-inset-top)+84px))] grid h-10 w-10 place-items-center rounded-full border border-line bg-surface/80 text-ink backdrop-blur transition hover:bg-surface sm:right-6 sm:top-auto sm:bottom-6 sm:h-11 sm:w-11">{playing ? <Pause size={16} /> : <Play size={16} />}</button>
    </section>
  );
}
