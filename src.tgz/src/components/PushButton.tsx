"use client";
import { useEffect, useState } from "react";
import { Bell, BellOff } from "lucide-react";

/** "Enable notifications" toggle: registers the service worker and a Web Push subscription. Hidden when VAPID keys are missing. */
export default function PushButton({ labels }: { labels: { on: string; off: string; unsupported: string } }) {
  const [state, setState] = useState<"hidden" | "off" | "on" | "unsupported">("hidden");
  const [key, setKey] = useState<string | null>(null);
  useEffect(() => {
    (async () => {
      if (!("serviceWorker" in navigator) || !("PushManager" in window)) { setState("unsupported"); return; }
      const j = await fetch("/api/push").then((r) => r.json()).catch(() => null);
      if (!j?.enabled) return; setKey(j.publicKey);
      const reg = await navigator.serviceWorker.register("/sw.js"); const sub = await reg.pushManager.getSubscription();
      setState(sub ? "on" : "off");
    })();
  }, []);
  const toggle = async () => {
    const reg = await navigator.serviceWorker.ready;
    if (state === "on") { const sub = await reg.pushManager.getSubscription(); if (sub) { await fetch("/api/push", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ endpoint: sub.endpoint }) }); await sub.unsubscribe(); } setState("off"); return; }
    if ((await Notification.requestPermission()) !== "granted") return;
    const raw = atob(key!.replace(/-/g, "+").replace(/_/g, "/")); const appKey = Uint8Array.from(raw, (c) => c.charCodeAt(0));
    const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: appKey });
    await fetch("/api/push", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(sub.toJSON()) });
    setState("on");
  };
  if (state === "hidden") return null;
  if (state === "unsupported") return <p className="text-xs text-muted">{labels.unsupported}</p>;
  return <button type="button" onClick={toggle} className="btn btn-ghost btn-sm">{state === "on" ? <BellOff size={14} /> : <Bell size={14} />} {state === "on" ? labels.on : labels.off}</button>;
}
