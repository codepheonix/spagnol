import type { ReactNode } from "react";
import SiteHeader from "./SiteHeader";
import SiteFooter from "./SiteFooter";
import { getSetting } from "@/lib/settings";

export default async function SubpageShell({ children, title, eyebrow }: { children: ReactNode; title: string; eyebrow?: string }) {
  const clinic = await getSetting("clinicInfo");
  return (
    <>
      <SiteHeader name={clinic.name.split(" ").slice(-1)[0]} />
      <main id="main" className="gut min-h-screen pb-24 pt-[120px]">
        <div className="mx-auto max-w-3xl">
          {eyebrow && <p className="eyebrow mb-3">{eyebrow}</p>}
          <h1 className="display mb-10 text-[clamp(36px,5vw,64px)]">{title}</h1>
        </div>
        {children}
      </main>
      <SiteFooter clinic={clinic} />
    </>
  );
}
