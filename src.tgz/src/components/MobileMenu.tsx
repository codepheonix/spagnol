"use client";
import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { X } from "lucide-react";
import { Link } from "@/i18n/navigation";
import ThemeToggle from "./ThemeToggle";
import LocaleSwitch from "./LocaleSwitch";
import Logo from "./Logo";

/**
 * Full-screen menu for phones and iPads. The sheet is fully opaque (so the page never shows through in light mode)
 * and slides in; the 3D effect lives on the items, which swing in with a staggered flip.
 */
export default function MobileMenu({ open, onClose, links, extra, cta }: { open: boolean; onClose: () => void; links: [string, string][]; extra: [string, string][]; cta: { href: string; label: string } }) {
  const reduce = useReducedMotion();
  // rendered in a portal on <body>: the header's backdrop-filter would otherwise turn this fixed sheet into a
  // child positioned inside the 68 px header bar (the "menu doesn't open" bug on About/Contact and after scrolling)
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  // lock page scroll while the sheet is open; close on Escape
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow; document.body.style.overflow = "hidden";
    const key = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    addEventListener("keydown", key);
    return () => { document.body.style.overflow = prev; removeEventListener("keydown", key); };
  }, [open, onClose]);
  if (!mounted) return null;
  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div key="menu" role="dialog" aria-modal="true" className="menu3d fixed inset-0 z-[60] lg:hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}>
          <motion.div className="absolute inset-0 bg-bg" style={{ backgroundColor: "var(--bg)" }} initial={reduce ? {} : { y: "-6%" }} animate={{ y: 0 }} exit={reduce ? {} : { y: "-4%" }} transition={{ type: "spring", stiffness: 260, damping: 30 }} />
          <div className="relative flex h-full flex-col overflow-y-auto px-6 pb-[max(24px,env(safe-area-inset-bottom))] pt-[max(14px,env(safe-area-inset-top))]">
            <div className="flex h-[40px] items-center justify-between sm:h-[48px]">
              <Logo h={36} onClick={onClose} />
              <button type="button" onClick={onClose} aria-label="close" className="grid h-10 w-10 place-items-center rounded-full border border-line bg-surface"><X size={18} /></button>
            </div>
            <nav className="mt-8 grid gap-1 sm:mt-12 sm:gap-2" aria-label="Mobile">
              {links.map(([href, label], i) => (
                <motion.div key={href} className="menu3d-item" initial={reduce ? {} : { opacity: 0, rotateX: -70, y: 24 }} animate={{ opacity: 1, rotateX: 0, y: 0 }} exit={reduce ? {} : { opacity: 0, rotateX: 40, y: -10 }} transition={{ delay: 0.06 + i * 0.07, type: "spring", stiffness: 260, damping: 22 }}>
                  <Link href={href} onClick={onClose} className="display block rounded-2xl px-4 py-2.5 text-[clamp(32px,7.5vw,56px)] leading-[1.1] no-underline transition hover:bg-bg-2 active:scale-[.98] sm:py-3">{label}</Link>
                </motion.div>
              ))}
              <div className="my-3 h-px bg-line sm:my-4" />
              {extra.map(([href, label], i) => (
                <motion.div key={href} className="menu3d-item" initial={reduce ? {} : { opacity: 0, rotateX: -60, y: 16 }} animate={{ opacity: 1, rotateX: 0, y: 0 }} exit={{ opacity: 0 }} transition={{ delay: 0.28 + i * 0.06, type: "spring", stiffness: 260, damping: 22 }}>
                  <Link href={href} onClick={onClose} className="block rounded-2xl px-4 py-2 text-lg font-medium text-ink-2 no-underline hover:bg-bg-2">{label}</Link>
                </motion.div>
              ))}
            </nav>
            <motion.div className="mt-auto flex items-center gap-3 pt-8" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
              <Link href={cta.href} onClick={onClose} className="btn btn-solid flex-1">{cta.label}</Link>
              <LocaleSwitch /><ThemeToggle />
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}
