"use client";
import { useLocale } from "next-intl";
import { Link, usePathname } from "@/i18n/navigation";

export default function LocaleSwitch({ className = "" }: { className?: string }) {
  const locale = useLocale();
  const pathname = usePathname();
  const other = locale === "it" ? "en" : "it";
  return (
    <Link href={pathname} locale={other} hrefLang={other} className={`inline-flex h-10 items-center rounded-full border border-line bg-surface/70 px-3 text-xs font-semibold uppercase tracking-widest text-ink-2 backdrop-blur hover:text-accent ${className}`}>
      {other}
    </Link>
  );
}
