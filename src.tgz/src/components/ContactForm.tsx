"use client";
import { useState } from "react";
import { useLocale } from "next-intl";

export default function ContactForm({ labels }: { labels: Record<"name" | "email" | "message" | "send" | "sent" | "error", string> }) {
  const locale = useLocale();
  const [state, setState] = useState<"idle" | "sending" | "sent" | "error">("idle");
  return (
    <form className="mt-6 grid gap-4" onSubmit={async (e) => {
      e.preventDefault(); setState("sending");
      const f = new FormData(e.currentTarget);
      const r = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: f.get("name"), email: f.get("email"), message: f.get("message"), website: f.get("website"), locale }) });
      setState(r.ok ? "sent" : "error");
    }}>
      <input type="text" name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden="true" />
      <div><label className="label" htmlFor="c-name">{labels.name}</label><input id="c-name" name="name" className="input" required minLength={2} /></div>
      <div><label className="label" htmlFor="c-email">{labels.email}</label><input id="c-email" name="email" type="email" className="input" required /></div>
      <div><label className="label" htmlFor="c-msg">{labels.message}</label><textarea id="c-msg" name="message" className="input" required minLength={5} rows={5} /></div>
      {state === "sent" ? <p className="rounded-xl bg-accent-soft p-3 text-sm font-medium text-accent">{labels.sent}</p> : (
        <button className="btn btn-solid" disabled={state === "sending"}>{labels.send}</button>)}
      {state === "error" && <p className="text-sm text-danger">{labels.error}</p>}
    </form>
  );
}
