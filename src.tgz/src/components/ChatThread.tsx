"use client";
import { useEffect, useRef, useState } from "react";
import { CornerUpLeft, FileText, Paperclip, Send, X } from "lucide-react";
import { useLocale } from "next-intl";
import { fmtDate } from "@/lib/fmt";

type Att = { url: string; name: string; size: number; type: string };
type Msg = { id: string; sender: string; body: string; createdAt: string; replyToId?: string | null; attachments?: Att[] };
export type ChatLabels = { placeholder: string; send: string; empty: string; you: string; other: string; reply: string; attach: string; uploading: string; tooBig: string };

/** Polling chat thread with attachments (images/PDF → Vercel Blob) and reply-to quoting. `me` is this client's sender. */
export default function ChatThread({ me, patientId, initial, labels, onIncomingCall, compact = false }: { me: "patient" | "admin"; patientId?: string; initial: Msg[]; labels: ChatLabels; onIncomingCall?: (callId: string) => void; compact?: boolean }) {
  const locale = useLocale();
  const [msgs, setMsgs] = useState<Msg[]>(initial);
  const [text, setText] = useState("");
  const [files, setFiles] = useState<Att[]>([]);
  const [uploading, setUploading] = useState(false);
  const [replyTo, setReplyTo] = useState<Msg | null>(null);
  const [sending, setSending] = useState(false);
  const [err, setErr] = useState("");
  const since = useRef(initial.at(-1)?.createdAt ?? new Date(0).toISOString());
  const box = useRef<HTMLDivElement>(null);
  const input = useRef<HTMLTextAreaElement>(null);
  const q = patientId ? `&patient=${patientId}` : "";
  useEffect(() => {
    let alive = true;
    const tick = async () => {
      try {
        const r = await fetch(`/api/chat?since=${encodeURIComponent(since.current)}${q}`, { cache: "no-store" });
        if (!r.ok || !alive) return;
        const j = await r.json();
        if (j.messages.length) { setMsgs((m) => { const ids = new Set(m.map((x) => x.id)); return [...m, ...j.messages.filter((x: Msg) => !ids.has(x.id))]; }); since.current = j.messages.at(-1).createdAt; }
        if (j.call && j.call.status === "ringing" && j.call.startedBy !== me) onIncomingCall?.(j.call.id);
      } catch {}
    };
    const id = setInterval(tick, 3000); tick();
    return () => { alive = false; clearInterval(id); };
  }, [q, me, onIncomingCall]);
  useEffect(() => { box.current?.scrollTo({ top: box.current.scrollHeight, behavior: "smooth" }); }, [msgs.length]);

  const pick = async (list: FileList | null) => {
    if (!list?.length) return; setErr(""); setUploading(true);
    for (const f of Array.from(list).slice(0, 6 - files.length)) {
      if (f.size > 10 * 1024 * 1024) { setErr(labels.tooBig); continue; }
      const fd = new FormData(); fd.append("file", f); if (patientId) fd.append("patient", patientId);
      const r = await fetch("/api/uploads", { method: "POST", body: fd });
      if (r.ok) { const a = (await r.json()) as Att; setFiles((x) => [...x, a]); } else setErr(labels.tooBig);
    }
    setUploading(false);
  };
  const send = async () => {
    const body = text.trim(); if ((!body && !files.length) || sending || uploading) return;
    setSending(true);
    const r = await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ body, patient: patientId, attachments: files, replyToId: replyTo?.id ?? null }) });
    if (r.ok) { const j = await r.json(); setMsgs((m) => [...m, j.message]); since.current = j.message.createdAt; setText(""); setFiles([]); setReplyTo(null); }
    setSending(false);
  };
  const day = (iso: string) => fmtDate(iso, locale, { weekday: "short", day: "numeric", month: "short" });
  const time = (iso: string) => fmtDate(iso, locale, { hour: "2-digit", minute: "2-digit" });
  const byId = new Map(msgs.map((m) => [m.id, m]));
  const who = (m: Msg) => (m.sender === me ? labels.you : labels.other);
  const Quote = ({ m, mine }: { m: Msg; mine: boolean }) => (
    <div className={`mb-2 rounded-xl border-l-2 px-3 py-1.5 text-xs ${mine ? "border-white/60 bg-white/15 text-white/85 dark:border-bg/60 dark:bg-bg/15 dark:text-bg/85" : "border-accent bg-bg-2 text-ink-2"}`}>
      <p className="font-semibold">{who(m)}</p><p className="line-clamp-2">{m.body || (m.attachments?.[0] ? `📎 ${m.attachments[0].name}` : "")}</p>
    </div>
  );
  const AttList = ({ list, mine }: { list: Att[]; mine: boolean }) => (
    <div className="mt-2 grid gap-2">
      {list.map((a) => a.type.startsWith("image/") ? (
        <a key={a.url} href={a.url} target="_blank" rel="noreferrer" className="block overflow-hidden rounded-xl"><img src={a.url} alt={a.name} className="max-h-64 w-full object-cover" loading="lazy" /></a>
      ) : (
        <a key={a.url} href={a.url} target="_blank" rel="noreferrer" className={`flex items-center gap-2 rounded-xl px-3 py-2 text-xs font-medium no-underline ${mine ? "bg-white/15 text-white dark:bg-bg/15 dark:text-bg" : "bg-bg-2 text-ink"}`}><FileText size={14} /> <span className="truncate">{a.name}</span> <span className="ml-auto opacity-70">{Math.round(a.size / 1024)} KB</span></a>
      ))}
    </div>
  );
  return (
    <div className={`flex flex-col ${compact ? "h-[60vh]" : "h-[calc(100vh-200px)] min-h-[420px]"}`}>
      <div ref={box} className="flex-1 space-y-3 overflow-y-auto rounded-2xl border border-line bg-bg p-4">
        {msgs.length === 0 && <p className="py-12 text-center text-sm text-muted">{labels.empty}</p>}
        {msgs.map((m, i) => { const mine = m.sender === me; const newDay = i === 0 || day(m.createdAt) !== day(msgs[i - 1].createdAt); const quoted = m.replyToId ? byId.get(m.replyToId) : null; return (
          <div key={m.id}>
            {newDay && <p className="my-3 text-center text-[11px] font-semibold uppercase tracking-[0.18em] text-muted">{day(m.createdAt)}</p>}
            <div className={`group flex items-end gap-2 ${mine ? "justify-end" : "justify-start"}`}>
              {mine && <button type="button" aria-label={labels.reply} title={labels.reply} onClick={() => { setReplyTo(m); input.current?.focus(); }} className="rounded-full p-1.5 text-muted opacity-0 transition group-hover:opacity-100 hover:bg-bg-2"><CornerUpLeft size={14} /></button>}
              <div className={`max-w-[78%] rounded-2xl px-4 py-2.5 text-[15px] leading-relaxed ${mine ? "rounded-br-md bg-accent text-white dark:text-bg" : "rounded-bl-md border border-line bg-surface"}`}>
                {quoted && <Quote m={quoted} mine={mine} />}
                {m.body && <p className="whitespace-pre-wrap break-words">{m.body}</p>}
                {m.attachments && m.attachments.length > 0 && <AttList list={m.attachments} mine={mine} />}
                <p className={`mt-1 text-[11px] ${mine ? "text-white/70 dark:text-bg/70" : "text-muted"}`}>{who(m)} · {time(m.createdAt)}</p>
              </div>
              {!mine && <button type="button" aria-label={labels.reply} title={labels.reply} onClick={() => { setReplyTo(m); input.current?.focus(); }} className="rounded-full p-1.5 text-muted opacity-0 transition group-hover:opacity-100 hover:bg-bg-2"><CornerUpLeft size={14} /></button>}
            </div>
          </div>); })}
      </div>
      {replyTo && (
        <div className="mt-3 flex items-center gap-2 rounded-xl border border-line bg-surface px-3 py-2 text-xs"><CornerUpLeft size={14} className="text-accent" /><span className="font-semibold">{who(replyTo)}:</span><span className="line-clamp-1 flex-1 text-ink-2">{replyTo.body || replyTo.attachments?.[0]?.name}</span><button type="button" aria-label="close" onClick={() => setReplyTo(null)}><X size={14} /></button></div>
      )}
      {files.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-2">{files.map((f) => <span key={f.url} className="chip bg-bg-2 text-ink"><FileText size={12} /> <span className="max-w-[160px] truncate">{f.name}</span><button type="button" aria-label="remove" onClick={() => setFiles((x) => x.filter((y) => y.url !== f.url))}><X size={12} /></button></span>)}</div>
      )}
      {(err || uploading) && <p className={`mt-2 text-xs ${err ? "text-danger" : "text-muted"}`}>{err || labels.uploading}</p>}
      <form className="mt-3 flex gap-2" onSubmit={(e) => { e.preventDefault(); send(); }}>
        <label className="btn btn-ghost !h-12 !w-12 cursor-pointer !px-0" title={labels.attach}><Paperclip size={16} /><input type="file" className="hidden" multiple accept="image/*,application/pdf" onChange={(e) => { pick(e.target.files); e.target.value = ""; }} /></label>
        <textarea ref={input} className="input !min-h-[48px] flex-1 !py-3" rows={1} placeholder={labels.placeholder} value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }} onPaste={(e) => { if (e.clipboardData.files.length) { e.preventDefault(); pick(e.clipboardData.files); } }} />
        <button className="btn btn-solid !px-4" disabled={sending || uploading || (!text.trim() && !files.length)} aria-label={labels.send}><Send size={16} /></button>
      </form>
    </div>
  );
}
