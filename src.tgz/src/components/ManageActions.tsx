"use client";
import { useState } from "react";
import { useTranslations } from "next-intl";
import { useRouter } from "@/i18n/navigation";
import { CalendarClock, XCircle } from "lucide-react";

export default function ManageActions({ reference, token, canCancel, canMove, active }: { reference: string; token: string; canCancel: boolean; canMove: boolean; active: boolean }) {
  const t = useTranslations("manage");
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const cancel = async () => {
    if (!confirm(t("cancelConfirm"))) return;
    setBusy(true);
    const r = await fetch(`/api/manage/${reference}?t=${encodeURIComponent(token)}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "cancel" }) });
    setBusy(false);
    if (r.ok) { setDone(true); router.refresh(); }
  };
  if (done) return <p className="mt-6 font-semibold text-danger">{t("cancelled")}</p>;
  if (!active) return null;
  if (!canCancel && !canMove) return <p className="mt-6 text-sm text-muted">{t("cutoff")}</p>;
  return (
    <div className="mt-6 flex flex-wrap gap-3">
      {canMove && <button type="button" className="btn btn-solid" onClick={() => router.push(`/booking/manage/${reference}?t=${encodeURIComponent(token)}&action=reschedule`)}><CalendarClock size={16} />{t("reschedule")}</button>}
      {canCancel && <button type="button" className="btn btn-ghost" disabled={busy} onClick={cancel}><XCircle size={16} />{t("cancel")}</button>}
      <a className="btn btn-ghost" href={`/api/ics/${reference}?t=${encodeURIComponent(token)}`}>.ics</a>
    </div>
  );
}
