"use client";
import { useEffect, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";

/**
 * Dashboard mobile menu: a fixed sheet under the 56 px header, rendered on <body> so it is visible at any scroll
 * position and never trapped by the header's backdrop-filter. Locks page scroll while open; closes on Escape or on the backdrop.
 */
export default function MobileSheet({ open, onClose, children }: { open: boolean; onClose: () => void; children: ReactNode }) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow; document.body.style.overflow = "hidden";
    const key = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    addEventListener("keydown", key);
    return () => { document.body.style.overflow = prev; removeEventListener("keydown", key); };
  }, [open, onClose]);
  if (!mounted || !open) return null;
  return createPortal(
    <div className="fixed inset-0 top-14 z-[55] md:hidden" role="dialog" aria-modal="true">
      <button type="button" aria-label="close" onClick={onClose} className="absolute inset-0 bg-ink/30" />
      <div className="relative max-h-full overflow-y-auto border-b border-line bg-bg p-4 shadow-[0_24px_48px_-24px_rgba(0,0,0,.35)]" style={{ backgroundColor: "var(--bg)" }}>{children}</div>
    </div>,
    document.body,
  );
}
