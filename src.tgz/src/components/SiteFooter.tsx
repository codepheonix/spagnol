import { getTranslations } from "next-intl/server";
import { Link } from "@/i18n/navigation";
import Logo from "./Logo";
import type { ClinicInfo } from "@/lib/settings";

export default async function SiteFooter({ clinic }: { clinic: ClinicInfo }) {
  const t = await getTranslations("footer");
  const n = await getTranslations("nav");
  const a = await getTranslations("app.auth");
  return (
    <footer className="gut border-t border-line bg-bg py-14 text-sm text-muted">
      <div className="mx-auto grid max-w-6xl gap-10 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
        <div>
          <Logo h={44} alt={clinic.practice} />
          <p className="mt-3 max-w-[32ch]">{clinic.address}</p>
          <p className="mt-1">{clinic.phone} · {clinic.email}</p>
        </div>
        <div>
          <p className="eyebrow mb-3">{t("nav")}</p>
          <nav className="grid gap-2"><Link href="/">{n("home")}</Link><Link href="/about">{n("about")}</Link><Link href="/contact">{n("contact")}</Link></nav>
        </div>
        <div>
          <p className="eyebrow mb-3">{t("account")}</p>
          <nav className="grid gap-2"><Link href="/app/login">{a("login")}</Link><Link href="/app/signup">{a("signup")}</Link></nav>
        </div>
        <div>
          <p className="eyebrow mb-3">{t("legal")}</p>
          <nav className="grid gap-2"><Link href="/privacy">{t("privacy")}</Link><Link href="/cookies">{t("cookies")}</Link><Link href="/terms">{t("terms")}</Link></nav>
        </div>
      </div>
      <div className="mx-auto mt-10 flex max-w-6xl flex-col gap-2 border-t border-line pt-6 text-xs md:flex-row md:justify-between">
        <p>© {new Date().getFullYear()} {clinic.name}. {t("rights")}</p>
        <p>{t("credit")}</p>
      </div>
    </footer>
  );
}
