import { z } from "zod";
import { eq } from "drizzle-orm";
import { getDb, schema } from "@/db";

export const BookingPolicy = z.object({
  timezone: z.string().default("Europe/Rome"),
  slotStepMin: z.number().int().min(0).max(120).default(0), // start-time grid in minutes; 0 = service duration
  minNoticeHours: z.number().min(0).default(12),
  horizonDays: z.number().int().min(1).max(365).default(60),
  cancelCutoffHours: z.number().min(0).default(24),
  rescheduleCutoffHours: z.number().min(0).default(24),
  requireApproval: z.boolean().default(false),
  reminderHoursBefore: z.array(z.number()).default([24]),
  providerId: z.string().default("main"),
});
export type BookingPolicy = z.infer<typeof BookingPolicy>;

export const ClinicInfo = z.object({
  name: z.string().default("Dott.ssa Sara Bianchi"),
  practice: z.string().default("Studio di Fisioterapia Sara Bianchi"),
  tagline: z.object({ it: z.string(), en: z.string() }).default({
    it: "Rimettiti in movimento.",
    en: "Get moving again.",
  }),
  bio: z.object({ it: z.string(), en: z.string() }).default({
    it: "Fisioterapista laureata all'Università di Trieste, specializzata in terapia manuale e riabilitazione ortopedica. Da oltre dieci anni accompagno pazienti di ogni età verso il recupero del movimento, con un approccio basato sull'evidenza scientifica e sull'ascolto.",
    en: "Physiotherapist trained at the University of Trieste, specialised in manual therapy and orthopaedic rehabilitation. For over ten years I have guided patients of all ages back to pain-free movement, with an evidence-based, attentive approach.",
  }),
  qualifications: z.array(z.object({ it: z.string(), en: z.string() })).default([
    { it: "Laurea in Fisioterapia — Università degli Studi di Trieste", en: "BSc Physiotherapy — University of Trieste" },
    { it: "Master in Terapia Manuale Ortopedica (OMT)", en: "MSc Orthopaedic Manual Therapy (OMT)" },
    { it: "Certificazione Dry Needling", en: "Dry Needling certification" },
    { it: "Iscritta all'Albo dei Fisioterapisti (TSRM-PSTRP)", en: "Registered with the Italian Physiotherapists' Board" },
  ]),
  address: z.string().default("Via Giulia 12, 34126 Trieste (TS)"),
  mapQuery: z.string().default("Via Giulia 12, Trieste"),
  phone: z.string().default("+39 040 123 4567"),
  email: z.string().default("info@sarafisioterapia.it"),
  whatsappDisplay: z.string().default("+39 333 123 4567"),
  openingHoursText: z.object({ it: z.string(), en: z.string() }).default({
    it: "Lun–Ven 9:00–19:00 · Sab su appuntamento",
    en: "Mon–Fri 9:00–19:00 · Sat by appointment",
  }),
  testimonials: z.array(z.object({ name: z.string(), it: z.string(), en: z.string() })).default([
    { name: "Marco T.", it: "Dopo l'intervento al ginocchio pensavo di non tornare a correre. Sei mesi dopo ho finito la mia prima mezza maratona.", en: "After my knee surgery I thought I'd never run again. Six months later I finished my first half marathon." },
    { name: "Giulia R.", it: "Finalmente qualcuno che spiega cosa sta succedendo al mio corpo e perché. Il mal di schiena è sparito in poche settimane.", en: "Finally someone who explains what is happening to my body and why. My back pain was gone in a few weeks." },
    { name: "Elena M.", it: "Professionale, puntuale, attenta. Lo studio è un posto dove ci si sente ascoltati.", en: "Professional, punctual, attentive. The practice is a place where you feel heard." },
  ]),
  faq: z.array(z.object({ q: z.object({ it: z.string(), en: z.string() }), a: z.object({ it: z.string(), en: z.string() }) })).default([
    { q: { it: "Serve la prescrizione medica?", en: "Do I need a doctor's referral?" }, a: { it: "No, puoi prenotare direttamente. Se hai referti o esami recenti, portali alla prima seduta.", en: "No, you can book directly. If you have recent scans or reports, bring them to the first session." } },
    { q: { it: "Come si paga?", en: "How do I pay?" }, a: { it: "Il pagamento avviene direttamente in studio, al termine della seduta. Nessun pagamento online.", en: "You pay directly at the practice, at the end of the session. No online payments." } },
    { q: { it: "Posso cancellare o spostare l'appuntamento?", en: "Can I cancel or reschedule?" }, a: { it: "Sì, dal link ricevuto via email, fino a 24 ore prima dell'appuntamento.", en: "Yes, from the link in your email, up to 24 hours before the appointment." } },
    { q: { it: "Cosa devo portare?", en: "What should I bring?" }, a: { it: "Abbigliamento comodo e, se disponibili, referti medici recenti.", en: "Comfortable clothing and, if available, recent medical reports." } },
  ]),
});
export type ClinicInfo = z.infer<typeof ClinicInfo>;

export const NotificationSettings = z.object({
  adminWhatsapp: z.string().default(""), // E.164, e.g. +393331234567
  adminEmail: z.string().default(""),
  notifyOnCancel: z.boolean().default(true),
  notifyOnReschedule: z.boolean().default(true),
  notifyOnPending: z.boolean().default(true),
  patientSmsEnabled: z.boolean().default(false),
  dashboardSound: z.boolean().default(true),
});
export type NotificationSettings = z.infer<typeof NotificationSettings>;

const KEYS = {
  bookingPolicy: BookingPolicy,
  clinicInfo: ClinicInfo,
  notifications: NotificationSettings,
} as const;
type Keys = keyof typeof KEYS;

export async function getSetting<K extends Keys>(key: K): Promise<z.infer<(typeof KEYS)[K]>> {
  const db = await getDb();
  const row = await db.query.contentSettings.findFirst({ where: eq(schema.contentSettings.key, key) });
  const parsed = KEYS[key].safeParse(row?.value ?? {});
  return (parsed.success ? parsed.data : KEYS[key].parse({})) as z.infer<(typeof KEYS)[K]>;
}

export async function setSetting<K extends Keys>(key: K, value: z.infer<(typeof KEYS)[K]>) {
  const db = await getDb();
  const data = KEYS[key].parse(value);
  await db.insert(schema.contentSettings).values({ key, value: data })
    .onConflictDoUpdate({ target: schema.contentSettings.key, set: { value: data, updatedAt: new Date() } });
  return data;
}
