import "server-only";
/** Cloudflare Turnstile server-side check. No-op (passes) until TURNSTILE_SECRET_KEY is set. */
export function turnstileEnabled() { return !!(process.env.TURNSTILE_SECRET_KEY && process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY); }
export async function verifyTurnstile(token: string | null | undefined, ip?: string): Promise<boolean> {
  if (!turnstileEnabled()) return true;
  if (!token) return false;
  try {
    const r = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ secret: process.env.TURNSTILE_SECRET_KEY, response: token, remoteip: ip }) });
    const j = (await r.json()) as { success?: boolean }; return !!j.success;
  } catch { return false; }
}
