"use client";
// Browser side of an audio call. Same engine for patient and practitioner.
// provider "cloudflare": real WebRTC through the Cloudflare Realtime SFU (signalling via /api/calls/[id]/sfu + status polling).
// provider "demo": no keys configured → same UI/state machine with the local microphone only (level meter), clearly labelled.

export type CallState = "idle" | "connecting" | "ringing" | "active" | "ended" | "error";
export type CallStatus = { id: string; status: string; provider: string; room: Record<string, string>; answeredAt?: string | null; startedBy: string };

export type Engine = {
  start(): Promise<void>;
  hangup(): Promise<void>;
  mute(m: boolean): void;
  level(): number; // 0..1 microphone level for the meter
  destroy(): void;
};

export function createCallEngine(opts: { callId: string; role: "patient" | "admin"; onState: (s: CallState, detail?: string) => void; onStatus?: (st: CallStatus) => void }): Engine {
  const { callId, role } = opts;
  const api = (action: string, body: Record<string, unknown> = {}) =>
    fetch(`/api/calls/${callId}/sfu`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action, role, ...body }) }).then(async (r) => {
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.error ?? r.statusText);
      return j as Record<string, unknown>;
    });

  let pc: RTCPeerConnection | null = null, mic: MediaStream | null = null, audioEl: HTMLAudioElement | null = null;
  let analyser: AnalyserNode | null = null, ctx: AudioContext | null = null, timer: ReturnType<typeof setInterval> | null = null;
  let session = "", pulled = false, alive = true, provider = "demo";
  const other = role === "patient" ? "admin" : "patient";

  async function getMic() {
    mic = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
    ctx = new AudioContext(); analyser = ctx.createAnalyser(); analyser.fftSize = 512;
    ctx.createMediaStreamSource(mic).connect(analyser);
  }

  async function publish() {
    pc = new RTCPeerConnection({ iceServers: [{ urls: "stun:stun.cloudflare.com:3478" }], bundlePolicy: "max-bundle" });
    pc.ontrack = (e) => { audioEl ??= new Audio(); audioEl.srcObject = e.streams[0] ?? new MediaStream([e.track]); audioEl.autoplay = true; audioEl.play().catch(() => {}); };
    const tx = pc.addTransceiver(mic!.getAudioTracks()[0], { direction: "sendonly" });
    const offer = await pc.createOffer(); await pc.setLocalDescription(offer);
    const trackName = `${role}-audio`;
    const r = await api("push", { sdp: offer.sdp, mid: tx.mid, trackName });
    await pc.setRemoteDescription({ type: "answer", sdp: String((r.sessionDescription as { sdp: string }).sdp) });
    session = String(r.sessionId);
  }

  async function pullOther(st: CallStatus) {
    const otherSession = st.room[`${other}Session`], otherTrack = st.room[`${other}Track`];
    if (!otherSession || !otherTrack || pulled || !pc) return;
    pulled = true;
    const r = await api("pull", { otherSession, otherTrack });
    if (r.requiresImmediateRenegotiation && r.sessionDescription) {
      await pc.setRemoteDescription({ type: "offer", sdp: String((r.sessionDescription as { sdp: string }).sdp) });
      const answer = await pc.createAnswer(); await pc.setLocalDescription(answer);
      await api("renegotiate", { sdp: answer.sdp });
    }
  }

  async function poll() {
    try {
      const st = (await api("status")) as unknown as CallStatus;
      opts.onStatus?.(st);
      if (st.status === "ended" || st.status === "missed" || st.status === "declined") { opts.onState("ended", st.status); stop(); return; }
      if (st.status === "active") { opts.onState("active"); if (provider === "cloudflare") await pullOther(st); }
      else opts.onState("ringing");
    } catch (e) { opts.onState("error", (e as Error).message); stop(); }
  }

  function stop() {
    if (timer) clearInterval(timer); timer = null;
    pc?.close(); pc = null;
    mic?.getTracks().forEach((t) => t.stop()); mic = null;
    ctx?.close().catch(() => {}); ctx = null; analyser = null;
    if (audioEl) { audioEl.pause(); audioEl.srcObject = null; audioEl = null; }
  }

  return {
    async start() {
      try {
        opts.onState("connecting");
        const st = (await api("status")) as unknown as CallStatus; provider = st.provider;
        await getMic();
        if (provider === "cloudflare") await publish();
        await api("join", { session });
        opts.onState(st.status === "active" ? "active" : "ringing");
        timer = setInterval(poll, 2000);
      } catch (e) { opts.onState("error", (e as Error).message); stop(); }
    },
    async hangup() { if (!alive) return; try { await api("end"); } catch {} opts.onState("ended"); stop(); },
    mute(m) { mic?.getAudioTracks().forEach((t) => { t.enabled = !m; }); },
    level() {
      if (!analyser) return 0;
      const buf = new Uint8Array(analyser.frequencyBinCount); analyser.getByteTimeDomainData(buf);
      let sum = 0; for (const v of buf) { const d = (v - 128) / 128; sum += d * d; }
      return Math.min(1, Math.sqrt(sum / buf.length) * 4);
    },
    destroy() { alive = false; stop(); },
  };
}
