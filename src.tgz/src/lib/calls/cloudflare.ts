import "server-only";
// Cloudflare Realtime SFU ("Cloudflare Calls"). The app secret stays on the server: the browser talks to
// /api/calls/[id]/sfu, which forwards to https://rtc.live.cloudflare.com. Docs: developers.cloudflare.com/realtime/
const BASE = () => `https://rtc.live.cloudflare.com/v1/apps/${process.env.CF_CALLS_APP_ID}`;

export function cloudflareConfigured() {
  return !!(process.env.CF_CALLS_APP_ID && process.env.CF_CALLS_APP_SECRET);
}

async function cf(path: string, method: "POST" | "PUT", body?: unknown) {
  const res = await fetch(BASE() + path, { method, headers: { Authorization: `Bearer ${process.env.CF_CALLS_APP_SECRET}`, "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`Cloudflare Calls ${res.status}: ${JSON.stringify(data).slice(0, 300)}`);
  return data as Record<string, unknown>;
}

export const sfu = {
  newSession: () => cf("/sessions/new", "POST") as Promise<{ sessionId: string }>,
  /** publish local tracks: offer in, answer out */
  push: (sessionId: string, sdp: string, tracks: { location: "local"; mid: string; trackName: string }[]) =>
    cf(`/sessions/${sessionId}/tracks/new`, "POST", { sessionDescription: { type: "offer", sdp }, tracks }),
  /** subscribe to the other party's tracks: Cloudflare returns an offer when renegotiation is required */
  pull: (sessionId: string, tracks: { location: "remote"; sessionId: string; trackName: string }[]) =>
    cf(`/sessions/${sessionId}/tracks/new`, "POST", { tracks }),
  renegotiate: (sessionId: string, sdp: string) => cf(`/sessions/${sessionId}/renegotiate`, "PUT", { sessionDescription: { type: "answer", sdp } }),
  close: (sessionId: string, sdp: string, tracks: { mid: string }[]) => cf(`/sessions/${sessionId}/tracks/close`, "PUT", { sessionDescription: { type: "offer", sdp }, tracks, force: true }),
};
