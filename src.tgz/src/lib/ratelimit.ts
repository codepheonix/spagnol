// Best-effort in-memory limiter (per serverless instance). Combine with a platform firewall/WAF in production.
const buckets = new Map<string, { n: number; reset: number }>();
export function rateLimit(key: string, limit: number, windowMs: number) {
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || b.reset < now) { buckets.set(key, { n: 1, reset: now + windowMs }); return { ok: true, remaining: limit - 1 }; }
  b.n++;
  return { ok: b.n <= limit, remaining: Math.max(0, limit - b.n) };
}
export function clientIp(req: Request) {
  return (req.headers.get("x-forwarded-for") ?? "").split(",")[0].trim() || req.headers.get("x-real-ip") || "local";
}
