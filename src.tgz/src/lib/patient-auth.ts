import "server-only";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { getLocale } from "next-intl/server";
import { SignJWT, jwtVerify } from "jose";
import bcrypt from "bcryptjs";
import { and, eq, gt, isNotNull, isNull } from "drizzle-orm";
import { createHash, randomBytes } from "node:crypto";
import { getDb, schema } from "@/db";
import { rateLimit } from "./ratelimit";
import { appUrl } from "./url";
import { enqueueAuthEmail } from "./notify/enqueue";

const COOKIE = "sara_patient";
const TTL_S = 60 * 60 * 24 * 30; // 30 days

function secret() {
  const s = process.env.SESSION_SECRET;
  if (!s || s.length < 16) throw new Error("SESSION_SECRET must be set (min 16 chars)");
  return new TextEncoder().encode(s);
}
const hash = (t: string) => createHash("sha256").update(t).digest("hex");

export type PatientSession = { sub: string; email: string; name: string };

export async function getPatientSession(): Promise<PatientSession | null> {
  const jar = await cookies();
  const token = jar.get(COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret(), { algorithms: ["HS256"] });
    if (payload.role !== "patient") return null;
    return { sub: String(payload.sub), email: String(payload.email), name: String(payload.name) };
  } catch { return null; }
}

/** For portal pages: layouts and pages render in parallel, so each page guards itself. */
export async function requirePatientPage(): Promise<PatientSession> {
  const s = await getPatientSession();
  if (!s) redirect(`/${await getLocale()}/app/login`);
  return s;
}

export async function requirePatient(): Promise<PatientSession> {
  const s = await getPatientSession();
  if (!s) throw new Error("UNAUTHENTICATED");
  return s;
}

async function setSession(p: { id: string; email: string; name: string }) {
  const token = await new SignJWT({ email: p.email, name: p.name, role: "patient" })
    .setProtectedHeader({ alg: "HS256" }).setSubject(p.id).setIssuedAt().setExpirationTime(`${TTL_S}s`).sign(secret());
  const jar = await cookies();
  jar.set(COOKIE, token, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: TTL_S });
  const db = await getDb();
  await db.update(schema.patients).set({ lastSeenAt: new Date() }).where(eq(schema.patients.id, p.id));
}

export async function patientLogout() {
  const jar = await cookies();
  jar.delete(COOKIE);
}

/** Account lookup: the patient row that owns this e-mail (has a password). */
export async function findAccount(email: string) {
  const db = await getDb();
  return db.query.patients.findFirst({ where: and(eq(schema.patients.email, email.trim().toLowerCase()), isNotNull(schema.patients.passwordHash)) });
}

export type SignupInput = { name: string; email: string; phone: string; password: string; locale: "it" | "en"; smsOptIn?: boolean };
export async function signup(input: SignupInput, ip = "local"): Promise<{ ok: true } | { ok: false; reason: "exists" | "rate_limited" }> {
  if (!rateLimit(`signup:${ip}`, 5, 15 * 60_000).ok) return { ok: false, reason: "rate_limited" };
  const email = input.email.trim().toLowerCase();
  if (await findAccount(email)) return { ok: false, reason: "exists" };
  const db = await getDb();
  const passwordHash = await bcrypt.hash(input.password, 10);
  // Claim an existing guest patient row with the same e-mail (keeps their appointment history) or create one.
  const guest = await db.query.patients.findFirst({ where: and(eq(schema.patients.email, email), isNull(schema.patients.passwordHash)) });
  let patient: schema.Patient;
  if (guest) [patient] = await db.update(schema.patients).set({ passwordHash, name: input.name.trim(), phone: input.phone.trim(), locale: input.locale, smsOptIn: !!input.smsOptIn }).where(eq(schema.patients.id, guest.id)).returning();
  else [patient] = await db.insert(schema.patients).values({ name: input.name.trim(), email, phone: input.phone.trim(), locale: input.locale, smsOptIn: !!input.smsOptIn, passwordHash }).returning();
  await issueToken(patient, "verify");
  await setSession(patient);
  return { ok: true };
}

export async function patientLogin(email: string, password: string, ip = "local"): Promise<{ ok: true } | { ok: false; reason: "invalid" | "rate_limited" }> {
  if (!rateLimit(`plogin:${ip}`, 10, 15 * 60_000).ok) return { ok: false, reason: "rate_limited" };
  const p = await findAccount(email);
  const ok = await bcrypt.compare(password, p?.passwordHash ?? "$2a$10$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalid");
  if (!p || !ok) return { ok: false, reason: "invalid" };
  await setSession(p);
  return { ok: true };
}

/** Magic link / verification / reset tokens: single-use, 30 min, hashed at rest. */
export async function issueToken(patient: schema.Patient, purpose: "magic" | "verify" | "reset") {
  const db = await getDb();
  const raw = randomBytes(24).toString("base64url");
  await db.insert(schema.authTokens).values({ patientId: patient.id, tokenHash: hash(raw), purpose, expiresAt: new Date(Date.now() + 30 * 60_000) });
  const url = `${appUrl()}/${patient.locale}/app/auth/${purpose}?t=${raw}`;
  await enqueueAuthEmail(db, { patient, purpose, url });
  return url;
}

export async function requestMagicLink(email: string, ip = "local") {
  if (!rateLimit(`magic:${ip}`, 5, 15 * 60_000).ok) return { ok: false as const, reason: "rate_limited" as const };
  const p = await findAccount(email);
  if (p) await issueToken(p, "magic"); // silent when unknown: no account enumeration
  return { ok: true as const };
}

export async function consumeToken(raw: string, purpose: "magic" | "verify" | "reset") {
  const db = await getDb();
  const row = await db.query.authTokens.findFirst({ where: and(eq(schema.authTokens.tokenHash, hash(raw)), eq(schema.authTokens.purpose, purpose), isNull(schema.authTokens.usedAt), gt(schema.authTokens.expiresAt, new Date())) });
  if (!row) return null;
  await db.update(schema.authTokens).set({ usedAt: new Date() }).where(eq(schema.authTokens.id, row.id));
  const patient = await db.query.patients.findFirst({ where: eq(schema.patients.id, row.patientId) });
  if (!patient) return null;
  if (purpose === "verify") await db.update(schema.patients).set({ emailVerifiedAt: new Date() }).where(eq(schema.patients.id, patient.id));
  if (purpose !== "reset") await setSession(patient);
  return patient;
}

export async function resetPassword(raw: string, password: string) {
  const p = await consumeToken(raw, "reset");
  if (!p) return false;
  const db = await getDb();
  await db.update(schema.patients).set({ passwordHash: await bcrypt.hash(password, 10) }).where(eq(schema.patients.id, p.id));
  await setSession(p);
  return true;
}

export async function updateProfile(id: string, data: { name?: string; phone?: string; locale?: "it" | "en"; smsOptIn?: boolean; emailOptIn?: boolean; birthDate?: string | null }) {
  const db = await getDb();
  await db.update(schema.patients).set({ ...data, birthDate: data.birthDate === undefined ? undefined : data.birthDate }).where(eq(schema.patients.id, id));
}

export async function changePatientPassword(id: string, current: string, next: string) {
  const db = await getDb();
  const p = await db.query.patients.findFirst({ where: eq(schema.patients.id, id) });
  if (!p?.passwordHash || !(await bcrypt.compare(current, p.passwordHash))) return false;
  await db.update(schema.patients).set({ passwordHash: await bcrypt.hash(next, 10) }).where(eq(schema.patients.id, id));
  return true;
}
