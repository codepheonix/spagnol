import type { Rendered } from "./templates";

export type SendResult = { providerMessageId?: string; mock?: boolean };
export class SendError extends Error { constructor(msg: string, public retryable = true) { super(msg); } }

const isMock = (...keys: string[]) => process.env.NOTIFICATIONS_MODE === "mock" || keys.some((k) => !process.env[k]);

/** WhatsApp Business Platform (Meta Cloud API). Business-initiated messages need an approved template. */
export async function sendWhatsApp(to: string, template: string, msg: Rendered, payload: Record<string, unknown>): Promise<SendResult> {
  if (isMock("WHATSAPP_TOKEN", "WHATSAPP_PHONE_NUMBER_ID")) {
    console.log(`[mock whatsapp] → ${to}: ${msg.text}`);
    return { mock: true };
  }
  const templateName = process.env.WHATSAPP_TEMPLATE_NAME; // e.g. "appointment_alert" with params {{1}} date-time {{2}} patient {{3}} service
  const body = templateName
    ? { messaging_product: "whatsapp", to: to.replace(/[^\d]/g, ""), type: "template", template: { name: templateName, language: { code: process.env.WHATSAPP_TEMPLATE_LANG ?? "it" }, components: [{ type: "body", parameters: [
        { type: "text", text: `${payload.date} ${payload.time}` }, { type: "text", text: String(payload.patientFirst ?? "") }, { type: "text", text: String(payload.serviceTitleIt ?? "") }] }] } }
    : { messaging_product: "whatsapp", to: to.replace(/[^\d]/g, ""), type: "text", text: { body: msg.text } }; // only works inside a 24h customer window
  const res = await fetch(`https://graph.facebook.com/${process.env.WHATSAPP_API_VERSION ?? "v21.0"}/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`, {
    method: "POST", headers: { Authorization: `Bearer ${process.env.WHATSAPP_TOKEN}`, "Content-Type": "application/json" }, body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new SendError(`WhatsApp ${res.status}: ${JSON.stringify(data).slice(0, 300)}`, res.status >= 500 || res.status === 429);
  return { providerMessageId: data?.messages?.[0]?.id };
}

export async function sendEmail(to: string, msg: Rendered): Promise<SendResult> {
  if (isMock("RESEND_API_KEY")) {
    console.log(`[mock email] → ${to}: ${msg.subject}\n${msg.text}`);
    return { mock: true };
  }
  const { Resend } = await import("resend");
  const resend = new Resend(process.env.RESEND_API_KEY);
  const { data, error } = await resend.emails.send({ from: process.env.EMAIL_FROM ?? "Studio <onboarding@resend.dev>", to, subject: msg.subject, text: msg.text, html: msg.html });
  if (error) throw new SendError(error.message, true);
  return { providerMessageId: data?.id };
}

export async function sendSms(to: string, msg: Rendered): Promise<SendResult> {
  if (isMock("TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "TWILIO_FROM")) {
    console.log(`[mock sms] → ${to}: ${msg.text.slice(0, 160)}`);
    return { mock: true };
  }
  const sid = process.env.TWILIO_ACCOUNT_SID!;
  const res = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
    method: "POST",
    headers: { Authorization: "Basic " + Buffer.from(`${sid}:${process.env.TWILIO_AUTH_TOKEN}`).toString("base64"), "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ To: to, From: process.env.TWILIO_FROM!, Body: `${msg.subject}\n${msg.text}`.slice(0, 1500) }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new SendError(`Twilio ${res.status}: ${JSON.stringify(data).slice(0, 300)}`, res.status >= 500 || res.status === 429);
  return { providerMessageId: data?.sid };
}
