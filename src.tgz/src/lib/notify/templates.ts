type P = Record<string, unknown> & { name?: string; text?: string; url?: string; preview?: string; proposedDate?: string; proposedTime?: string; reference?: string; patientName?: string; patientFirst?: string; serviceTitle?: string; serviceTitleIt?: string; date?: string; time?: string; address?: string; practice?: string; phone?: string; manageUrl?: string; dashboardUrl?: string; hoursBefore?: number; durationMin?: number };

export type Rendered = { subject: string; text: string; html?: string };

const it = {
  patient_confirmation: (p: P): Rendered => ({
    subject: `Appuntamento confermato — ${p.date} alle ${p.time}`,
    text: `Ciao ${p.patientName},\n\nil tuo appuntamento è confermato.\n\n${p.serviceTitle}\n${p.date} alle ${p.time} (${p.durationMin} min)\n${p.practice}\n${p.address}\n\nCodice prenotazione: ${p.reference}\n\nPer spostare o cancellare l'appuntamento: ${p.manageUrl ?? "contatta lo studio"}\n\nIl pagamento avviene direttamente in studio.\nA presto!`,
  }),
  patient_pending: (p: P): Rendered => ({
    subject: `Richiesta ricevuta — ${p.date} alle ${p.time}`,
    text: `Ciao ${p.patientName},\n\nabbiamo ricevuto la tua richiesta per ${p.serviceTitle} il ${p.date} alle ${p.time}. Riceverai una conferma a breve.\n\nCodice: ${p.reference}\nGestisci la richiesta: ${p.manageUrl ?? ""}`,
  }),
  patient_cancelled: (p: P): Rendered => ({
    subject: `Appuntamento cancellato — ${p.date} alle ${p.time}`,
    text: `Ciao ${p.patientName},\n\nl'appuntamento del ${p.date} alle ${p.time} (${p.serviceTitle}) è stato cancellato.\nCodice: ${p.reference}\n\nPer prenotare di nuovo visita il nostro sito o chiama lo ${p.phone}.`,
  }),
  patient_rescheduled: (p: P): Rendered => ({
    subject: `Appuntamento spostato — ${p.date} alle ${p.time}`,
    text: `Ciao ${p.patientName},\n\nil tuo appuntamento è stato spostato a:\n${p.date} alle ${p.time}\n${p.serviceTitle}\n${p.address}\n\nCodice: ${p.reference}\nGestisci: ${p.manageUrl ?? ""}`,
  }),
  patient_reminder: (p: P): Rendered => ({
    subject: `Promemoria — domani alle ${p.time}`,
    text: `Ciao ${p.patientName},\n\nti ricordiamo l'appuntamento di ${p.serviceTitle}:\n${p.date} alle ${p.time}\n${p.practice}, ${p.address}\n\nCodice: ${p.reference}\nSpostare o cancellare: ${p.manageUrl ?? ""}`,
  }),
  admin_booked: (p: P): Rendered => ({
    subject: `Nuovo appuntamento — ${p.date} alle ${p.time}`,
    text: `Nuovo appuntamento — ${p.date} alle ${p.time}. Paziente: ${p.patientFirst}. ${p.serviceTitleIt}. Vedi nella dashboard: ${p.dashboardUrl}`,
  }),
  admin_pending: (p: P): Rendered => ({
    subject: `Richiesta da approvare — ${p.date} alle ${p.time}`,
    text: `Richiesta da approvare — ${p.date} alle ${p.time}. Paziente: ${p.patientFirst}. ${p.serviceTitleIt}. Approva nella dashboard: ${p.dashboardUrl}`,
  }),
  admin_cancelled: (p: P): Rendered => ({
    subject: `Appuntamento cancellato — ${p.date} alle ${p.time}`,
    text: `Appuntamento cancellato dal paziente — ${p.date} alle ${p.time}. Paziente: ${p.patientFirst}. Dashboard: ${p.dashboardUrl}`,
  }),
  admin_rescheduled: (p: P): Rendered => ({
    subject: `Appuntamento spostato — ${p.date} alle ${p.time}`,
    text: `Appuntamento spostato dal paziente a ${p.date} alle ${p.time}. Paziente: ${p.patientFirst}. Dashboard: ${p.dashboardUrl}`,
  }),
  auth_magic: (p: P): Rendered => ({ subject: "Il tuo link di accesso", text: `Ciao ${p.patientName},\n\naccedi alla tua area personale con questo link (valido 30 minuti):\n${p.url}\n\nSe non hai richiesto tu l'accesso, ignora questa e-mail.` }),
  auth_verify: (p: P): Rendered => ({ subject: "Conferma il tuo indirizzo e-mail", text: `Ciao ${p.patientName},\n\nbenvenuto! Conferma il tuo indirizzo e-mail con questo link:\n${p.url}` }),
  auth_reset: (p: P): Rendered => ({ subject: "Reimposta la password", text: `Ciao ${p.patientName},\n\nper scegliere una nuova password usa questo link (valido 30 minuti):\n${p.url}` }),
  patient_message: (p: P): Rendered => ({ subject: "Nuovo messaggio dalla tua fisioterapista", text: `Ciao ${p.patientName},\n\nhai un nuovo messaggio:\n"${p.preview}"\n\nRispondi dalla tua area personale: ${p.url}` }),
  patient_reschedule_accepted: (p: P): Rendered => ({ subject: `Spostamento accettato — ${p.date} alle ${p.time}`, text: `Ciao ${p.patientName},\n\nla tua richiesta di spostamento è stata accettata. Nuovo orario: ${p.date} alle ${p.time}.\n${p.url}` }),
  patient_reschedule_declined: (p: P): Rendered => ({ subject: "Spostamento non disponibile", text: `Ciao ${p.patientName},\n\npurtroppo l'orario proposto (${p.proposedDate} alle ${p.proposedTime}) non è disponibile; l'appuntamento resta ${p.date} alle ${p.time}. Scrivici in chat per trovare un'alternativa: ${p.url}` }),
  admin_message: (p: P): Rendered => ({ subject: `Nuovo messaggio da ${p.patientFirst}`, text: `Nuovo messaggio da ${p.patientFirst}: "${p.preview}". Rispondi: ${p.dashboardUrl}` }),
  admin_reschedule_request: (p: P): Rendered => ({ subject: `Richiesta di spostamento — ${p.patientFirst}`, text: `${p.patientFirst} chiede di spostare l'appuntamento del ${p.date} ${p.time} a ${p.proposedDate} ${p.proposedTime}. Decidi: ${p.dashboardUrl}` }),
  contact_form: (p: P): Rendered => ({ subject: `Messaggio dal sito — ${p.name}`, text: String(p.text ?? "") }),
  admin_call_request: (p: P): Rendered => ({ subject: `${p.patientFirst} vuole chiamarti`, text: `${p.patientFirst} ha richiesto una chiamata vocale. Apri la dashboard per rispondere: ${p.dashboardUrl}` }),
};

const en: typeof it = {
  patient_confirmation: (p) => ({
    subject: `Appointment confirmed — ${p.date} at ${p.time}`,
    text: `Hi ${p.patientName},\n\nyour appointment is confirmed.\n\n${p.serviceTitle}\n${p.date} at ${p.time} (${p.durationMin} min)\n${p.practice}\n${p.address}\n\nBooking reference: ${p.reference}\n\nTo reschedule or cancel: ${p.manageUrl ?? "contact the practice"}\n\nPayment is made directly at the practice.\nSee you soon!`,
  }),
  patient_pending: (p) => ({
    subject: `Request received — ${p.date} at ${p.time}`,
    text: `Hi ${p.patientName},\n\nwe received your request for ${p.serviceTitle} on ${p.date} at ${p.time}. You will receive a confirmation shortly.\n\nReference: ${p.reference}\nManage: ${p.manageUrl ?? ""}`,
  }),
  patient_cancelled: (p) => ({
    subject: `Appointment cancelled — ${p.date} at ${p.time}`,
    text: `Hi ${p.patientName},\n\nthe appointment on ${p.date} at ${p.time} (${p.serviceTitle}) has been cancelled.\nReference: ${p.reference}\n\nTo book again visit our website or call ${p.phone}.`,
  }),
  patient_rescheduled: (p) => ({
    subject: `Appointment moved — ${p.date} at ${p.time}`,
    text: `Hi ${p.patientName},\n\nyour appointment has been moved to:\n${p.date} at ${p.time}\n${p.serviceTitle}\n${p.address}\n\nReference: ${p.reference}\nManage: ${p.manageUrl ?? ""}`,
  }),
  patient_reminder: (p) => ({
    subject: `Reminder — tomorrow at ${p.time}`,
    text: `Hi ${p.patientName},\n\na reminder of your ${p.serviceTitle} appointment:\n${p.date} at ${p.time}\n${p.practice}, ${p.address}\n\nReference: ${p.reference}\nReschedule or cancel: ${p.manageUrl ?? ""}`,
  }),
  admin_booked: it.admin_booked, admin_pending: it.admin_pending, admin_cancelled: it.admin_cancelled, admin_rescheduled: it.admin_rescheduled,
  auth_magic: (p) => ({ subject: "Your sign-in link", text: `Hi ${p.patientName},\n\nsign in to your patient area with this link (valid 30 minutes):\n${p.url}\n\nIf you did not request this, ignore this e-mail.` }),
  auth_verify: (p) => ({ subject: "Confirm your e-mail address", text: `Hi ${p.patientName},\n\nwelcome! Confirm your e-mail address with this link:\n${p.url}` }),
  auth_reset: (p) => ({ subject: "Reset your password", text: `Hi ${p.patientName},\n\nchoose a new password with this link (valid 30 minutes):\n${p.url}` }),
  patient_message: (p) => ({ subject: "New message from your physiotherapist", text: `Hi ${p.patientName},\n\nyou have a new message:\n"${p.preview}"\n\nReply from your patient area: ${p.url}` }),
  patient_reschedule_accepted: (p) => ({ subject: `Reschedule accepted — ${p.date} at ${p.time}`, text: `Hi ${p.patientName},\n\nyour reschedule request was accepted. New time: ${p.date} at ${p.time}.\n${p.url}` }),
  patient_reschedule_declined: (p) => ({ subject: "Reschedule not available", text: `Hi ${p.patientName},\n\nunfortunately the proposed time (${p.proposedDate} at ${p.proposedTime}) is not available; your appointment stays on ${p.date} at ${p.time}. Message us to find an alternative: ${p.url}` }),
  admin_message: it.admin_message, admin_reschedule_request: it.admin_reschedule_request, admin_call_request: it.admin_call_request, contact_form: it.contact_form,
};

export function renderTemplate(template: string, locale: string, payload: Record<string, unknown>): Rendered {
  const pack = locale === "en" ? en : it;
  const fn = pack[template as keyof typeof it];
  if (!fn) return { subject: template, text: JSON.stringify(payload) };
  const r = fn(payload as P);
  const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const html = `<div style="font-family:Inter,Arial,sans-serif;font-size:16px;line-height:1.55;color:#1b2a2a;max-width:560px;margin:0 auto;padding:24px">
<h2 style="font-weight:600;color:#0f766e;margin:0 0 16px">${esc(r.subject)}</h2>
<p style="white-space:pre-line;margin:0">${esc(r.text).replace(/(https?:\/\/\S+)/g, '<a href="$1" style="color:#0f766e">$1</a>')}</p></div>`;
  return { ...r, html };
}
