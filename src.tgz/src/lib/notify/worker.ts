import { and, eq, lte, sql } from "drizzle-orm";
import { getDb, schema } from "@/db";
import { renderTemplate } from "./templates";
import { sendEmail, sendSms, sendWhatsApp, SendError } from "./providers";

const MAX_ATTEMPTS = 5;
const backoffMinutes = (attempt: number) => [1, 5, 15, 60, 240][Math.min(attempt, 4)];

/**
 * Processes due notification jobs. Safe to call concurrently: each job is claimed by an atomic
 * UPDATE that bumps attempts, so two workers never send the same job twice.
 */
export async function processNotificationJobs(limit = 25) {
  const db = await getDb();
  const now = new Date();
  const due = await db.select({ id: schema.notificationJobs.id }).from(schema.notificationJobs)
    .where(and(eq(schema.notificationJobs.status, "queued"), lte(schema.notificationJobs.runAt, now))).limit(limit);

  let sent = 0, failed = 0;
  for (const { id } of due) {
    const claimed = await db.update(schema.notificationJobs)
      .set({ attempts: sql`${schema.notificationJobs.attempts} + 1`, runAt: new Date(now.getTime() + 10 * 60_000) }) // lease 10 min
      .where(and(eq(schema.notificationJobs.id, id), eq(schema.notificationJobs.status, "queued"), lte(schema.notificationJobs.runAt, now)))
      .returning();
    const job = claimed[0];
    if (!job) continue; // another worker took it

    try {
      const msg = renderTemplate(job.template, job.locale, job.payload);
      const r = job.channel === "whatsapp" ? await sendWhatsApp(job.recipient, job.template, msg, job.payload)
        : job.channel === "email" ? await sendEmail(job.recipient, msg)
        : job.channel === "sms" ? await sendSms(job.recipient, msg)
        : { mock: true };
      await db.update(schema.notificationJobs).set({ status: r.mock ? "mock" : "sent", sentAt: new Date(), providerMessageId: r.providerMessageId ?? null, lastError: null }).where(eq(schema.notificationJobs.id, id));
      sent++;
    } catch (e) {
      const err = e as SendError;
      const retryable = (err.retryable ?? true) && job.attempts < MAX_ATTEMPTS;
      await db.update(schema.notificationJobs).set({
        status: retryable ? "queued" : "failed",
        runAt: new Date(Date.now() + backoffMinutes(job.attempts) * 60_000),
        lastError: String(err.message).slice(0, 1000),
      }).where(eq(schema.notificationJobs.id, id));
      failed++;
    }
  }
  return { due: due.length, sent, failed };
}
