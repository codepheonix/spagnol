import { and, eq, inArray, like } from "drizzle-orm";
import { schema, type Db } from "@/db";
import { getSetting } from "../settings";
import { formatInZone } from "../availability";
import { appUrl } from "../url";

type Kind = "booked" | "pending" | "approved" | "cancelled" | "rescheduled";

export type NotifyContext = {
  appointment: schema.Appointment;
  patient: schema.Patient;
  service: schema.Service;
  kind: Kind;
  manageToken?: string;
  byAdmin?: boolean;
};

export function manageUrl(reference: string, token: string, locale: string) {
  return `${appUrl()}/${locale}/booking/manage/${reference}?t=${token}`;
}

/** Creates all notification rows for an appointment event, inside the caller's transaction. Idempotent via dedupe_key. */
export type NotifySettings = Awaited<ReturnType<typeof loadNotifySettings>>;
/** Load settings BEFORE opening a transaction (single-connection embedded DBs would otherwise deadlock). */
export async function loadNotifySettings() {
  const [policy, notif, clinic] = await Promise.all([getSetting("bookingPolicy"), getSetting("notifications"), getSetting("clinicInfo")]);
  return { policy, notif, clinic };
}

export async function enqueueAppointmentNotifications(db: Db, ctx: NotifyContext, settings: NotifySettings) {
  const { policy, notif, clinic } = settings;
  const { appointment: a, patient: p, service: s } = ctx;
  const when = formatInZone(a.startsAt, policy.timezone, p.locale);
  const version = `${a.id}:${a.updatedAt.getTime()}`; // changes on every reschedule → fresh jobs, no duplicates for retries
  const base = {
    reference: a.reference, patientName: p.name, patientFirst: p.name.split(" ")[0] + (p.name.includes(" ") ? " " + p.name.split(" ").slice(-1)[0][0] + "." : ""),
    serviceTitle: p.locale === "en" ? s.titleEn : s.titleIt, serviceTitleIt: s.titleIt, serviceTitleEn: s.titleEn,
    date: when.date, time: when.time, iso: when.iso, durationMin: s.durationMin,
    address: clinic.address, practice: clinic.practice, phone: clinic.phone,
    manageUrl: ctx.manageToken ? manageUrl(a.reference, ctx.manageToken, p.locale) : undefined,
    dashboardUrl: `${appUrl()}/it/admin/appointments/${a.id}`,
  };
  const rows: (typeof schema.notificationJobs.$inferInsert)[] = [];

  // ── Patient ────────────────────────────────────────────────────────────────
  const patientTemplate = ctx.kind === "booked" ? "patient_confirmation" : ctx.kind === "pending" ? "patient_pending"
    : ctx.kind === "approved" ? "patient_confirmation" : ctx.kind === "cancelled" ? "patient_cancelled" : "patient_rescheduled";
  if (p.emailOptIn) rows.push({ channel: "email", recipient: p.email, template: patientTemplate, locale: p.locale, payload: base, appointmentId: a.id, dedupeKey: `email:${patientTemplate}:${version}` });
  if (notif.patientSmsEnabled && p.smsOptIn) rows.push({ channel: "sms", recipient: p.phone, template: patientTemplate, locale: p.locale, payload: base, appointmentId: a.id, dedupeKey: `sms:${patientTemplate}:${version}` });

  // Reminders only for active appointments.
  if (["booked", "approved", "rescheduled"].includes(ctx.kind) && a.status !== "pending") {
    for (const h of policy.reminderHoursBefore) {
      const runAt = new Date(a.startsAt.getTime() - h * 3_600_000);
      if (runAt.getTime() <= Date.now()) continue;
      const payload = { ...base, hoursBefore: h };
      if (p.emailOptIn) rows.push({ channel: "email", recipient: p.email, template: "patient_reminder", locale: p.locale, payload, appointmentId: a.id, runAt, dedupeKey: `email:reminder${h}:${version}` });
      if (notif.patientSmsEnabled && p.smsOptIn) rows.push({ channel: "sms", recipient: p.phone, template: "patient_reminder", locale: p.locale, payload, appointmentId: a.id, runAt, dedupeKey: `sms:reminder${h}:${version}` });
    }
  }

  // ── Practitioner (WhatsApp) ────────────────────────────────────────────────
  const adminWants = ctx.kind === "booked" || (ctx.kind === "pending" && notif.notifyOnPending)
    || (ctx.kind === "cancelled" && notif.notifyOnCancel && !ctx.byAdmin) || (ctx.kind === "rescheduled" && notif.notifyOnReschedule && !ctx.byAdmin);
  if (adminWants) {
    const adminTemplate = `admin_${ctx.kind}`;
    const adminWhen = formatInZone(a.startsAt, policy.timezone, "it");
    const adminPayload = { ...base, date: adminWhen.date, time: adminWhen.time };
    if (notif.adminWhatsapp) rows.push({ channel: "whatsapp", recipient: notif.adminWhatsapp, template: adminTemplate, locale: "it", payload: adminPayload, appointmentId: a.id, dedupeKey: `wa:${adminTemplate}:${version}` });
    if (notif.adminEmail) rows.push({ channel: "email", recipient: notif.adminEmail, template: adminTemplate, locale: "it", payload: adminPayload, appointmentId: a.id, dedupeKey: `email:${adminTemplate}:${version}` });
    await db.insert(schema.adminNotifications).values({
      type: ctx.kind === "booked" ? "new_booking" : ctx.kind,
      titleIt: ctx.kind === "booked" ? `Nuovo appuntamento — ${adminWhen.date} alle ${adminWhen.time}` : ctx.kind === "cancelled" ? `Appuntamento cancellato — ${adminWhen.date} ${adminWhen.time}` : ctx.kind === "rescheduled" ? `Appuntamento spostato — ${adminWhen.date} ${adminWhen.time}` : `Da approvare — ${adminWhen.date} ${adminWhen.time}`,
      titleEn: ctx.kind === "booked" ? `New appointment — ${when.date} at ${when.time}` : ctx.kind === "cancelled" ? `Appointment cancelled — ${when.date} ${when.time}` : ctx.kind === "rescheduled" ? `Appointment moved — ${when.date} ${when.time}` : `Pending approval — ${when.date} ${when.time}`,
      appointmentId: a.id,
    });
  }

  if (rows.length) await db.insert(schema.notificationJobs).values(rows).onConflictDoNothing({ target: schema.notificationJobs.dedupeKey });
}

export async function cancelReminderJobs(db: Db, appointmentId: string) {
  await db.update(schema.notificationJobs).set({ status: "cancelled" })
    .where(and(eq(schema.notificationJobs.appointmentId, appointmentId), inArray(schema.notificationJobs.status, ["queued"]), like(schema.notificationJobs.template, "patient_reminder%")));
}

// ── Account & messaging notifications ──────────────────────────────────────────
export async function enqueueAuthEmail(db: Db, ctx: { patient: schema.Patient; purpose: "magic" | "verify" | "reset"; url: string }) {
  const clinic = await getSetting("clinicInfo");
  await db.insert(schema.notificationJobs).values({
    channel: "email", recipient: ctx.patient.email, template: `auth_${ctx.purpose}`, locale: ctx.patient.locale,
    payload: { patientName: ctx.patient.name, url: ctx.url, practice: clinic.practice }, dedupeKey: `email:auth_${ctx.purpose}:${ctx.patient.id}:${Date.now()}`,
  });
}

/** A notice to the practitioner (WhatsApp + e-mail if configured) and a dashboard bell entry. */
export async function notifyAdmin(db: Db, ctx: { template: "admin_message" | "admin_reschedule_request" | "admin_call_request"; patient: schema.Patient; payload: Record<string, unknown>; titleIt: string; titleEn: string; appointmentId?: string; key: string }) {
  const notif = await getSetting("notifications");
  const payload = { ...ctx.payload, patientFirst: ctx.patient.name.split(" ")[0], dashboardUrl: `${appUrl()}/it/admin${ctx.template === "admin_message" ? `/messages/${ctx.patient.id}` : ctx.template === "admin_call_request" ? "/calls" : "/requests"}` };
  const rows: (typeof schema.notificationJobs.$inferInsert)[] = [];
  if (notif.adminWhatsapp) rows.push({ channel: "whatsapp", recipient: notif.adminWhatsapp, template: ctx.template, locale: "it", payload, appointmentId: ctx.appointmentId, dedupeKey: `wa:${ctx.template}:${ctx.key}` });
  if (notif.adminEmail) rows.push({ channel: "email", recipient: notif.adminEmail, template: ctx.template, locale: "it", payload, appointmentId: ctx.appointmentId, dedupeKey: `email:${ctx.template}:${ctx.key}` });
  if (rows.length) await db.insert(schema.notificationJobs).values(rows).onConflictDoNothing({ target: schema.notificationJobs.dedupeKey });
  await db.insert(schema.adminNotifications).values({ type: ctx.template.replace("admin_", ""), titleIt: ctx.titleIt, titleEn: ctx.titleEn, appointmentId: ctx.appointmentId });
}

export async function notifyPatient(db: Db, ctx: { template: "patient_message" | "patient_reschedule_accepted" | "patient_reschedule_declined"; patient: schema.Patient; payload: Record<string, unknown>; appointmentId?: string; key: string }) {
  if (!ctx.patient.emailOptIn) return;
  const clinic = await getSetting("clinicInfo");
  await db.insert(schema.notificationJobs).values({
    channel: "email", recipient: ctx.patient.email, template: ctx.template, locale: ctx.patient.locale, appointmentId: ctx.appointmentId,
    payload: { ...ctx.payload, patientName: ctx.patient.name, practice: clinic.practice, url: `${appUrl()}/${ctx.patient.locale}/app` }, dedupeKey: `email:${ctx.template}:${ctx.key}`,
  }).onConflictDoNothing({ target: schema.notificationJobs.dedupeKey });
}
