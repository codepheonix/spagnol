import "server-only";
import webpush from "web-push";
import { and, eq } from "drizzle-orm";
import { getDb, schema } from "@/db";

/** Web Push (PWA): works once VAPID keys are set — generate with `npx web-push generate-vapid-keys`. */
export function pushConfigured() {
  return !!(process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY);
}
function setup() {
  webpush.setVapidDetails(process.env.VAPID_SUBJECT ?? "mailto:info@example.com", process.env.VAPID_PUBLIC_KEY!, process.env.VAPID_PRIVATE_KEY!);
}

export async function saveSubscription(ownerType: "patient" | "admin", ownerId: string, sub: { endpoint: string; keys: { p256dh: string; auth: string } }) {
  const db = await getDb();
  await db.insert(schema.pushSubscriptions).values({ ownerType, ownerId, endpoint: sub.endpoint, keys: sub.keys }).onConflictDoUpdate({ target: schema.pushSubscriptions.endpoint, set: { ownerType, ownerId, keys: sub.keys } });
}

export async function removeSubscription(endpoint: string) {
  const db = await getDb();
  await db.delete(schema.pushSubscriptions).where(eq(schema.pushSubscriptions.endpoint, endpoint));
}

/** Send a notification to every device of an owner (all admins when ownerId is "*"). Dead subscriptions are pruned. */
export async function sendPush(ownerType: "patient" | "admin", ownerId: string, payload: { title: string; body: string; url?: string; tag?: string }) {
  if (!pushConfigured()) return;
  setup();
  const db = await getDb();
  const subs = await db.query.pushSubscriptions.findMany({ where: ownerId === "*" ? eq(schema.pushSubscriptions.ownerType, ownerType) : and(eq(schema.pushSubscriptions.ownerType, ownerType), eq(schema.pushSubscriptions.ownerId, ownerId)) });
  await Promise.all(subs.map(async (s) => {
    try { await webpush.sendNotification({ endpoint: s.endpoint, keys: s.keys }, JSON.stringify(payload), { TTL: 600 }); }
    catch (e) { const code = (e as { statusCode?: number }).statusCode; if (code === 404 || code === 410) await removeSubscription(s.endpoint); }
  }));
}
