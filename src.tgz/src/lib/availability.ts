import { DateTime, Interval } from "luxon";
import type { BookingPolicy } from "./settings";

/** Inputs are plain data so the engine is pure and unit-testable. All times are computed in the clinic timezone. */
export type HoursRule = { weekday: number; startTime: string; endTime: string; active: boolean };
export type ExceptionRule = { date: string; startTime: string | null; endTime: string | null; kind: "closed" | "open" | "break" | "block" };
export type BusyInterval = { startsAt: Date; blocksUntil: Date };
export type ServiceSpec = { durationMin: number; bufferMin: number };

export type Slot = { start: Date; end: Date; label: string };

function at(dateISO: string, hhmm: string, zone: string) {
  const [h, m] = hhmm.split(":").map(Number);
  return DateTime.fromISO(dateISO, { zone }).set({ hour: h, minute: m, second: 0, millisecond: 0 });
}

/** Open windows for one calendar day: working hours ∪ "open" exceptions, minus closed/break/block exceptions. */
export function openWindows(dateISO: string, hours: HoursRule[], exceptions: ExceptionRule[], zone: string): Interval[] {
  const day = DateTime.fromISO(dateISO, { zone });
  if (!day.isValid) return [];
  const todays = exceptions.filter((e) => e.date === dateISO);
  if (todays.some((e) => e.kind === "closed" && !e.startTime)) return [];

  let windows: Interval[] = hours
    .filter((h) => h.active && h.weekday === day.weekday)
    .map((h) => Interval.fromDateTimes(at(dateISO, h.startTime, zone), at(dateISO, h.endTime, zone)))
    .filter((i) => i.isValid && i.length("minutes") > 0);

  for (const e of todays.filter((e) => e.kind === "open" && e.startTime && e.endTime)) {
    windows.push(Interval.fromDateTimes(at(dateISO, e.startTime!, zone), at(dateISO, e.endTime!, zone)));
  }
  windows = Interval.merge(windows);

  const cuts = todays
    .filter((e) => e.kind !== "open" && e.startTime && e.endTime)
    .map((e) => Interval.fromDateTimes(at(dateISO, e.startTime!, zone), at(dateISO, e.endTime!, zone)));
  for (const c of cuts) windows = windows.flatMap((w) => w.difference(c));
  return windows.filter((w) => w.length("minutes") > 0);
}

/**
 * Eligible start times for a service on a day.
 * A slot is valid when [start, start+duration] lies inside one open window and
 * [start, start+duration+buffer) does not intersect any busy interval, and start respects notice/horizon.
 */
export function computeSlots(opts: {
  dateISO: string;
  service: ServiceSpec;
  hours: HoursRule[];
  exceptions: ExceptionRule[];
  busy: BusyInterval[];
  policy: BookingPolicy;
  now?: Date;
  ignorePolicyLimits?: boolean; // admin manual bookings may bypass notice/horizon
}): Slot[] {
  const { dateISO, service, hours, exceptions, busy, policy } = opts;
  const zone = policy.timezone;
  const now = DateTime.fromJSDate(opts.now ?? new Date(), { zone });
  const earliest = now.plus({ hours: policy.minNoticeHours });
  const latest = now.plus({ days: policy.horizonDays }).endOf("day");
  const windows = openWindows(dateISO, hours, exceptions, zone);
  const busyIv = busy.map((b) => Interval.fromDateTimes(DateTime.fromJSDate(b.startsAt), DateTime.fromJSDate(b.blocksUntil)));
  const step = policy.slotStepMin > 0 ? policy.slotStepMin : service.durationMin;
  const slots: Slot[] = [];

  for (const w of windows) {
    // Align the grid to the window start so a 12:00–16:00 day with 60-min sessions yields 12, 13, 14, 15.
    for (let t = w.start!; t.plus({ minutes: service.durationMin }) <= w.end!; t = t.plus({ minutes: step })) {
      const end = t.plus({ minutes: service.durationMin });
      const block = Interval.fromDateTimes(t, end.plus({ minutes: service.bufferMin }));
      if (!opts.ignorePolicyLimits && (t < earliest || t > latest)) continue;
      if (opts.ignorePolicyLimits && t < now) continue;
      if (busyIv.some((b) => b.overlaps(block))) continue;
      slots.push({ start: t.toJSDate(), end: end.toJSDate(), label: t.toFormat("HH:mm") });
    }
  }
  slots.sort((a, b) => a.start.getTime() - b.start.getTime());
  return slots;
}

/** Day summary for the calendar: 'available' | 'full' | 'closed' | 'past'. */
export function daySummary(opts: Omit<Parameters<typeof computeSlots>[0], "dateISO"> & { dateISO: string }) {
  const zone = opts.policy.timezone;
  const day = DateTime.fromISO(opts.dateISO, { zone });
  const now = DateTime.fromJSDate(opts.now ?? new Date(), { zone });
  if (day.endOf("day") < now) return "past" as const;
  if (!opts.ignorePolicyLimits && day.startOf("day") > now.plus({ days: opts.policy.horizonDays })) return "closed" as const;
  const windows = openWindows(opts.dateISO, opts.hours, opts.exceptions, zone);
  if (windows.length === 0) return "closed" as const;
  return computeSlots(opts).length > 0 ? ("available" as const) : ("full" as const);
}

export function formatInZone(d: Date, zone: string, locale: string) {
  const dt = DateTime.fromJSDate(d, { zone }).setLocale(locale);
  return { date: dt.toFormat("cccc d LLLL yyyy"), time: dt.toFormat("HH:mm"), iso: dt.toISO()!, dateISO: dt.toISODate()! };
}
