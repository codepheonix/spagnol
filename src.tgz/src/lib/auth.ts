import "server-only";
import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { generateSecret, generateURI, verify } from "otplib";
import { getDb, schema } from "@/db";
import { rateLimit } from "./ratelimit";

const COOKIE = "sara_admin";
const TTL_S = 60 * 60 * 12; // 12h sessions

function secret() {
  const s = process.env.SESSION_SECRET;
  if (!s || s.length < 16) throw new Error("SESSION_SECRET must be set (min 16 chars)");
  return new TextEncoder().encode(s);
}

export type Session = { sub: string; email: string; name: string; role: string };

export async function getSession(): Promise<Session | null> {
  const jar = await cookies();
  const token = jar.get(COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret(), { algorithms: ["HS256"] });
    return { sub: String(payload.sub), email: String(payload.email), name: String(payload.name), role: String(payload.role) };
  } catch { return null; }
}

export async function requireSession(): Promise<Session> {
  const s = await getSession();
  if (!s) throw new Error("UNAUTHENTICATED");
  return s;
}

export async function login(email: string, password: string, totp?: string, ip = "local"):
  Promise<{ ok: true } | { ok: false; reason: "invalid" | "totp_required" | "rate_limited" }> {
  if (!rateLimit(`login:${ip}`, 8, 15 * 60_000).ok) return { ok: false, reason: "rate_limited" };
  const db = await getDb();
  const admin = await db.query.admins.findFirst({ where: eq(schema.admins.email, email.trim().toLowerCase()) });
  const hash = admin?.passwordHash ?? "$2a$10$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalid"; // constant-time-ish
  const ok = await bcrypt.compare(password, hash);
  if (!admin || !ok) return { ok: false, reason: "invalid" };
  if (admin.totpSecret) {
    if (!totp) return { ok: false, reason: "totp_required" };
    if (!(await verify({ secret: admin.totpSecret, token: totp.replace(/\s/g, ""), epochTolerance: 1 })).valid) return { ok: false, reason: "invalid" };
  }
  const token = await new SignJWT({ email: admin.email, name: admin.name, role: admin.role })
    .setProtectedHeader({ alg: "HS256" }).setSubject(admin.id).setIssuedAt().setExpirationTime(`${TTL_S}s`).sign(secret());
  const jar = await cookies();
  jar.set(COOKIE, token, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: TTL_S });
  return { ok: true };
}

export async function logout() {
  const jar = await cookies();
  jar.delete(COOKIE);
}

export async function changePassword(adminId: string, current: string, next: string) {
  const db = await getDb();
  const admin = await db.query.admins.findFirst({ where: eq(schema.admins.id, adminId) });
  if (!admin || !(await bcrypt.compare(current, admin.passwordHash))) return false;
  await db.update(schema.admins).set({ passwordHash: await bcrypt.hash(next, 10) }).where(eq(schema.admins.id, adminId));
  return true;
}

export async function setupTotp(adminId: string) {
  const db = await getDb();
  const admin = await db.query.admins.findFirst({ where: eq(schema.admins.id, adminId) });
  const s = generateSecret();
  const uri = generateURI({ issuer: "Studio Fisioterapia", label: admin!.email, secret: s });
  return { secret: s, uri };
}
export async function enableTotp(adminId: string, s: string, code: string) {
  if (!(await verify({ secret: s, token: code.replace(/\s/g, ""), epochTolerance: 1 })).valid) return false;
  const db = await getDb();
  await db.update(schema.admins).set({ totpSecret: s }).where(eq(schema.admins.id, adminId));
  return true;
}
export async function disableTotp(adminId: string) {
  const db = await getDb();
  await db.update(schema.admins).set({ totpSecret: null }).where(eq(schema.admins.id, adminId));
}
