// Patient-care domain for the dashboards: appointment requests, reschedule requests, chat threads, calls.
import { and, asc, desc, eq, gt, gte, inArray, isNull, lt, sql, count } from "drizzle-orm";
import { DateTime } from "luxon";
import { getDb, schema, type Db } from "@/db";
import { bookAppointment, rescheduleAppointment, cancelAppointment, getAppointmentFull, BookingError, slotsForDay } from "./booking";
import { getSetting } from "./settings";
import { formatInZone } from "./availability";
import { notifyAdmin, notifyPatient } from "./notify/enqueue";
import { sendPush } from "./push";
import { appUrl } from "./url";

export const ACTIVE = ["pending", "confirmed", "rescheduled"] as const;

// ── Appointments (patient view) ───────────────────────────────────────────────
export async function patientAppointments(patientId: string) {
  const db = await getDb();
  const rows = await db.select({ a: schema.appointments, s: schema.services }).from(schema.appointments)
    .innerJoin(schema.services, eq(schema.appointments.serviceId, schema.services.id))
    .where(eq(schema.appointments.patientId, patientId)).orderBy(desc(schema.appointments.startsAt));
  const pending = await db.query.rescheduleRequests.findMany({ where: and(eq(schema.rescheduleRequests.patientId, patientId), eq(schema.rescheduleRequests.status, "pending")) });
  const byAppt = new Map(pending.map((r) => [r.appointmentId, r]));
  const now = Date.now();
  return rows.map((r) => ({ ...r, reschedule: byAppt.get(r.a.id) ?? null, upcoming: r.a.startsAt.getTime() > now && ACTIVE.includes(r.a.status as never) }));
}

/** Patient-app request: always goes through the practitioner's approval. */
export async function requestAppointment(patient: schema.Patient, serviceId: string, startISO: string, notes?: string) {
  sendPush("admin", "*", { title: patient.name, body: "Nuova richiesta di appuntamento", url: `${appUrl()}/it/admin/requests`, tag: "requests" }).catch(() => {});
  return bookAppointment({ serviceId, startISO, patient: { name: patient.name, email: patient.email, phone: patient.phone, locale: patient.locale as "it" | "en", notes }, patientId: patient.id, source: "app", requireApproval: true, actor: "patient" });
}

export async function patientCancel(patientId: string, appointmentId: string) {
  const { appointment } = await getAppointmentFull(appointmentId);
  if (appointment.patientId !== patientId) throw new BookingError("not_found");
  return cancelAppointment(appointmentId, { actor: "patient" });
}

// ── Reschedule requests ─────────────────────────────────────────────────────────
export async function requestReschedule(patient: schema.Patient, appointmentId: string, proposedISO: string, note?: string) {
  const db = await getDb();
  const { appointment, service } = await getAppointmentFull(appointmentId);
  if (appointment.patientId !== patient.id || !ACTIVE.includes(appointment.status as never)) throw new BookingError("invalid_state");
  const start = new Date(proposedISO);
  if (Number.isNaN(start.getTime())) throw new BookingError("invalid_slot");
  const policy = await getSetting("bookingPolicy");
  const { slots } = await slotsForDay(service.id, DateTime.fromJSDate(start, { zone: policy.timezone }).toISODate()!, { excludeAppointmentId: appointmentId });
  if (!slots.some((s) => s.start.getTime() === start.getTime())) throw new BookingError("slot_taken");
  // one open request per appointment
  await db.update(schema.rescheduleRequests).set({ status: "withdrawn", decidedAt: new Date() }).where(and(eq(schema.rescheduleRequests.appointmentId, appointmentId), eq(schema.rescheduleRequests.status, "pending")));
  const [req] = await db.insert(schema.rescheduleRequests).values({ appointmentId, patientId: patient.id, proposedStartsAt: start, note: note?.slice(0, 500) }).returning();
  const cur = formatInZone(appointment.startsAt, policy.timezone, "it"), prop = formatInZone(start, policy.timezone, "it");
  await notifyAdmin(db, { template: "admin_reschedule_request", patient, appointmentId, key: req.id, payload: { date: cur.date, time: cur.time, proposedDate: prop.date, proposedTime: prop.time },
    titleIt: `Richiesta di spostamento — ${patient.name.split(" ")[0]} → ${prop.date} ${prop.time}`, titleEn: `Reschedule request — ${patient.name.split(" ")[0]} → ${prop.date} ${prop.time}` });
  return req;
}

export async function withdrawReschedule(patientId: string, id: string) {
  const db = await getDb();
  await db.update(schema.rescheduleRequests).set({ status: "withdrawn", decidedAt: new Date() }).where(and(eq(schema.rescheduleRequests.id, id), eq(schema.rescheduleRequests.patientId, patientId), eq(schema.rescheduleRequests.status, "pending")));
}

export async function decideReschedule(id: string, accept: boolean, actor: string) {
  const db = await getDb();
  const req = await db.query.rescheduleRequests.findFirst({ where: and(eq(schema.rescheduleRequests.id, id), eq(schema.rescheduleRequests.status, "pending")) });
  if (!req) throw new BookingError("not_found");
  const { patient, appointment } = await getAppointmentFull(req.appointmentId);
  const policy = await getSetting("bookingPolicy");
  if (accept) {
    const updated = await rescheduleAppointment(req.appointmentId, req.proposedStartsAt.toISOString(), { admin: true, actor });
    await db.update(schema.rescheduleRequests).set({ status: "accepted", decidedAt: new Date() }).where(eq(schema.rescheduleRequests.id, id));
    const w = formatInZone(updated.startsAt, policy.timezone, patient.locale);
    await notifyPatient(db, { template: "patient_reschedule_accepted", patient, appointmentId: req.appointmentId, key: id, payload: { date: w.date, time: w.time } });
  } else {
    await db.update(schema.rescheduleRequests).set({ status: "declined", decidedAt: new Date() }).where(eq(schema.rescheduleRequests.id, id));
    const w = formatInZone(appointment.startsAt, policy.timezone, patient.locale), pw = formatInZone(req.proposedStartsAt, policy.timezone, patient.locale);
    await notifyPatient(db, { template: "patient_reschedule_declined", patient, appointmentId: req.appointmentId, key: id, payload: { date: w.date, time: w.time, proposedDate: pw.date, proposedTime: pw.time } });
  }
}

export async function openRequests() {
  const db = await getDb();
  const appts = await db.select({ a: schema.appointments, p: schema.patients, s: schema.services }).from(schema.appointments)
    .innerJoin(schema.patients, eq(schema.appointments.patientId, schema.patients.id)).innerJoin(schema.services, eq(schema.appointments.serviceId, schema.services.id))
    .where(eq(schema.appointments.status, "pending")).orderBy(asc(schema.appointments.startsAt));
  const res = await db.select({ r: schema.rescheduleRequests, a: schema.appointments, p: schema.patients, s: schema.services }).from(schema.rescheduleRequests)
    .innerJoin(schema.appointments, eq(schema.rescheduleRequests.appointmentId, schema.appointments.id))
    .innerJoin(schema.patients, eq(schema.rescheduleRequests.patientId, schema.patients.id)).innerJoin(schema.services, eq(schema.appointments.serviceId, schema.services.id))
    .where(eq(schema.rescheduleRequests.status, "pending")).orderBy(asc(schema.rescheduleRequests.createdAt));
  return { appointments: appts, reschedules: res };
}

// ── Chat ────────────────────────────────────────────────────────────────────────
export async function thread(patientId: string, sinceISO?: string) {
  const db = await getDb();
  const where = sinceISO ? and(eq(schema.messages.patientId, patientId), gt(schema.messages.createdAt, new Date(sinceISO))) : eq(schema.messages.patientId, patientId);
  return db.query.messages.findMany({ where, orderBy: asc(schema.messages.createdAt), limit: 500 });
}

export async function sendMessage(patientId: string, sender: "patient" | "admin", body: string, opts: { attachments?: schema.Attachment[]; replyToId?: string | null } = {}) {
  const db = await getDb();
  const text = body.trim().slice(0, 4000);
  const attachments = (opts.attachments ?? []).slice(0, 6);
  if (!text && !attachments.length) throw new Error("empty");
  let replyToId: string | null = null;
  if (opts.replyToId) { const r = await db.query.messages.findFirst({ where: and(eq(schema.messages.id, opts.replyToId), eq(schema.messages.patientId, patientId)) }); replyToId = r?.id ?? null; }
  const [m] = await db.insert(schema.messages).values({ patientId, sender, body: text, attachments, replyToId }).returning();
  const patient = await db.query.patients.findFirst({ where: eq(schema.patients.id, patientId) });
  if (!patient) return m;
  const preview = (text || `📎 ${attachments[0]?.name ?? ""}`).slice(0, 120);
  if (sender === "patient") {
    sendPush("admin", "*", { title: patient.name, body: preview, url: `${appUrl()}/it/admin/messages/${patientId}`, tag: `msg-${patientId}` }).catch(() => {});
    // throttle practitioner alerts: one per patient per 10 minutes
    const key = `${patientId}:${Math.floor(Date.now() / 600_000)}`;
    await notifyAdmin(db, { template: "admin_message", patient, key, payload: { preview }, titleIt: `Messaggio da ${patient.name}`, titleEn: `Message from ${patient.name}` });
  } else {
    sendPush("patient", patientId, { title: "Sara", body: preview, url: `${appUrl()}/${patient.locale}/app/messages`, tag: `msg-${patientId}` }).catch(() => {});
    const key = `${patientId}:${Math.floor(Date.now() / 600_000)}`;
    await notifyPatient(db, { template: "patient_message", patient, key, payload: { preview } });
  }
  return m;
}

export async function markRead(patientId: string, reader: "patient" | "admin") {
  const db = await getDb();
  await db.update(schema.messages).set({ readAt: new Date() }).where(and(eq(schema.messages.patientId, patientId), isNull(schema.messages.readAt), eq(schema.messages.sender, reader === "patient" ? "admin" : "patient")));
}

export async function unreadCount(patientId: string | null, reader: "patient" | "admin") {
  const db = await getDb();
  const base = and(isNull(schema.messages.readAt), eq(schema.messages.sender, reader === "patient" ? "admin" : "patient"));
  const [r] = await db.select({ n: count() }).from(schema.messages).where(patientId ? and(base, eq(schema.messages.patientId, patientId)) : base);
  return Number(r.n);
}

/** Admin inbox: one row per patient, latest message first. */
export async function inbox() {
  const db = await getDb();
  const latest = await db.execute(sql`
    select m.patient_id as "patientId", p.name, p.email, max(m.created_at) as "lastAt",
      (select body from messages x where x.patient_id = m.patient_id order by created_at desc limit 1) as "lastBody",
      sum(case when m.read_at is null and m.sender = 'patient' then 1 else 0 end)::int as unread
    from messages m join patients p on p.id = m.patient_id
    group by m.patient_id, p.name, p.email order by max(m.created_at) desc limit 200`);
  return (latest as unknown as { rows?: unknown[] }).rows ?? (latest as unknown as unknown[]);
}

// ── Calls ───────────────────────────────────────────────────────────────────────
export function callProvider() {
  return process.env.CF_CALLS_APP_ID && process.env.CF_CALLS_APP_SECRET ? "cloudflare" : "demo";
}

export async function startCall(patientId: string, startedBy: "patient" | "admin") {
  const db = await getDb();
  // end any dangling call for this patient
  await db.update(schema.calls).set({ status: "ended", endedAt: new Date() }).where(and(eq(schema.calls.patientId, patientId), inArray(schema.calls.status, ["ringing", "active"])));
  const [c] = await db.insert(schema.calls).values({ patientId, startedBy, provider: callProvider() }).returning();
  if (startedBy === "patient") {
    const patient = await db.query.patients.findFirst({ where: eq(schema.patients.id, patientId) });
    if (patient) { await notifyAdmin(db, { template: "admin_call_request", patient, key: c.id, payload: {}, titleIt: `${patient.name} ti sta chiamando`, titleEn: `${patient.name} is calling you` });
      sendPush("admin", "*", { title: `📞 ${patient.name}`, body: "Chiamata in arrivo", url: `${appUrl()}/it/admin/calls?answer=${c.id}`, tag: "call" }).catch(() => {}); }
  } else {
    const patient = await db.query.patients.findFirst({ where: eq(schema.patients.id, patientId) });
    if (patient) sendPush("patient", patientId, { title: "📞 Sara", body: patient.locale === "en" ? "Incoming call" : "Chiamata in arrivo", url: `${appUrl()}/${patient.locale}/app/call?answer=${c.id}`, tag: "call" }).catch(() => {});
  }
  return c;
}

export async function activeCall(patientId: string) {
  const db = await getDb();
  return db.query.calls.findFirst({ where: and(eq(schema.calls.patientId, patientId), inArray(schema.calls.status, ["ringing", "active"])), orderBy: desc(schema.calls.createdAt) });
}

export async function ringingCalls() {
  const db = await getDb();
  // calls older than 90s that were never answered count as missed
  await db.update(schema.calls).set({ status: "missed", endedAt: new Date() }).where(and(eq(schema.calls.status, "ringing"), lt(schema.calls.createdAt, new Date(Date.now() - 90_000))));
  return db.select({ c: schema.calls, p: schema.patients }).from(schema.calls).innerJoin(schema.patients, eq(schema.calls.patientId, schema.patients.id))
    .where(inArray(schema.calls.status, ["ringing", "active"])).orderBy(desc(schema.calls.createdAt));
}

export async function callHistory(patientId?: string) {
  const db = await getDb();
  return db.select({ c: schema.calls, p: schema.patients }).from(schema.calls).innerJoin(schema.patients, eq(schema.calls.patientId, schema.patients.id))
    .where(patientId ? eq(schema.calls.patientId, patientId) : gte(schema.calls.createdAt, new Date(Date.now() - 30 * 86_400_000))).orderBy(desc(schema.calls.createdAt)).limit(100);
}

export async function updateCall(id: string, patch: Partial<Pick<schema.Call, "status" | "answeredAt" | "endedAt">> & { room?: Record<string, unknown> }) {
  const db = await getDb();
  const cur = await db.query.calls.findFirst({ where: eq(schema.calls.id, id) });
  if (!cur) return null;
  const [c] = await db.update(schema.calls).set({ ...patch, room: patch.room ? { ...cur.room, ...patch.room } : undefined }).where(eq(schema.calls.id, id)).returning();
  return c;
}

export async function getCall(id: string) {
  const db = await getDb();
  return db.query.calls.findFirst({ where: eq(schema.calls.id, id) });
}

export type { Db };

/** Every attachment exchanged in a patient's thread (newest first) — the "Documents" view. */
export async function documents(patientId: string) {
  const db = await getDb();
  const rows = await db.query.messages.findMany({ where: eq(schema.messages.patientId, patientId), orderBy: desc(schema.messages.createdAt), limit: 500 });
  return rows.flatMap((m) => m.attachments.map((a) => ({ ...a, sender: m.sender, at: m.createdAt, messageId: m.id })));
}
