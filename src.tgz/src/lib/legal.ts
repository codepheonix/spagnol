import type { ClinicInfo } from "./settings";
/** Template legal text. Not legal advice — have a professional review before production. */
export function legalText(kind: "privacy" | "cookies" | "terms", locale: "it" | "en", c: ClinicInfo): string[] {
  const it = locale === "it";
  if (kind === "privacy") return it ? [
    `Titolare del trattamento: ${c.practice}, ${c.address} — ${c.email}.`,
    "## Quali dati raccogliamo", "Per gestire la prenotazione raccogliamo nome, email, numero di cellulare, la lingua preferita, le note facoltative che inserisci e i dati dell'appuntamento. Non raccogliamo dati sanitari tramite il sito: ti chiediamo di non inserirli nelle note.",
    "## Perché li usiamo", "Base giuridica: esecuzione di misure precontrattuali/contrattuali (art. 6.1.b GDPR) per confermare, ricordare, spostare o cancellare l'appuntamento; consenso (art. 6.1.a) per gli SMS facoltativi.",
    "## Per quanto tempo", "I dati di prenotazione sono conservati per 24 mesi dall'ultimo appuntamento, salvo obblighi di legge diversi, poi cancellati o anonimizzati.",
    "## A chi li comunichiamo", "A fornitori che agiscono come responsabili del trattamento: hosting (Vercel), database, invio email (Resend), eventuali SMS (Twilio) e WhatsApp Business (Meta) per la notifica interna alla fisioterapista, che riceve solo data, ora, iniziale del cognome e trattamento.",
    "## I tuoi diritti", `Puoi chiedere accesso, rettifica, cancellazione, limitazione e portabilità scrivendo a ${c.email}. Hai diritto di reclamo al Garante per la protezione dei dati personali.`,
    "Questo testo è un modello: va verificato da un professionista prima della pubblicazione.",
  ] : [
    `Data controller: ${c.practice}, ${c.address} — ${c.email}.`,
    "## What we collect", "To manage your booking we collect your name, email, mobile number, preferred language, the optional notes you enter and the appointment details. We do not collect health data through the website: please do not include it in the notes.",
    "## Why we use it", "Legal basis: performance of pre-contractual/contractual steps (art. 6.1.b GDPR) to confirm, remind, reschedule or cancel; consent (art. 6.1.a) for optional SMS.",
    "## How long", "Booking data is kept for 24 months after your last appointment unless the law requires otherwise, then deleted or anonymised.",
    "## Who we share it with", "Processors acting on our behalf: hosting (Vercel), database, email delivery (Resend), optional SMS (Twilio) and WhatsApp Business (Meta) for the practitioner's internal alert, which only contains date, time, surname initial and treatment.",
    "## Your rights", `You can request access, rectification, erasure, restriction and portability by writing to ${c.email}. You may lodge a complaint with the Italian Data Protection Authority (Garante).`,
    "This text is a template and must be reviewed by a professional before publication.",
  ];
  if (kind === "cookies") return it ? [
    "Questo sito usa solo cookie e storage tecnici strettamente necessari: la preferenza di lingua e tema (localStorage) e, nell'area riservata, il cookie di sessione dell'amministratore. Non usiamo cookie di profilazione né strumenti di tracciamento di terze parti. La mappa di Google incorporata può impostare cookie propri quando viene caricata.",
  ] : [
    "This site only uses strictly necessary cookies and storage: your language and theme preference (localStorage) and, in the staff area, the administrator session cookie. We do not use profiling cookies or third-party tracking. The embedded Google map may set its own cookies when loaded.",
  ];
  return it ? [
    "## Prenotazione", "La prenotazione online è gratuita e non richiede alcun pagamento anticipato. Il pagamento della seduta avviene direttamente in studio.",
    "## Cancellazione e spostamento", "Puoi cancellare o spostare l'appuntamento dal link ricevuto via email entro il termine indicato nella pagina di prenotazione. Oltre tale termine contatta lo studio telefonicamente.",
    "## Mancata presentazione", "In caso di mancata presentazione senza preavviso lo studio si riserva di non accettare nuove prenotazioni online dallo stesso contatto.",
    "## Informazioni sanitarie", "Il sito non è uno strumento diagnostico. Porta in studio eventuali referti medici: non inserirli nel modulo di prenotazione.",
  ] : [
    "## Booking", "Online booking is free and requires no upfront payment. Sessions are paid directly at the practice.",
    "## Cancellation and rescheduling", "You can cancel or reschedule from the link in your email within the time limit shown on the booking page. After that, please phone the practice.",
    "## No-shows", "In case of a no-show without notice, the practice may decline further online bookings from the same contact.",
    "## Health information", "The website is not a diagnostic tool. Bring any medical reports to the practice; do not enter them in the booking form.",
  ];
}
