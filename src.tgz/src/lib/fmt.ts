/** Date formatting that is identical on server and client (explicit locale + clinic timezone → no hydration mismatches). */
export const TZ = "Europe/Rome";
export const fmtDate = (d: string | Date, locale: string, opts: Intl.DateTimeFormatOptions) => new Date(d).toLocaleString(locale, { timeZone: TZ, ...opts });
