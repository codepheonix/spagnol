import { and, eq, gt, inArray, lt } from "drizzle-orm";
import { DateTime } from "luxon";
import { createHash, randomBytes } from "node:crypto";
import { customAlphabet } from "nanoid";
import { getDb, schema, type Db } from "@/db";
import { computeSlots, type BusyInterval } from "./availability";
import { getSetting } from "./settings";
import { enqueueAppointmentNotifications, cancelReminderJobs, loadNotifySettings } from "./notify/enqueue";

const ACTIVE = ["pending", "confirmed", "rescheduled"] as const;
const makeReference = customAlphabet("ABCDEFGHJKLMNPQRSTUVWXYZ23456789", 8);

export class BookingError extends Error {
  constructor(public code:
    | "slot_taken" | "service_not_found" | "invalid_slot" | "not_found" | "policy_cutoff" | "invalid_state", message?: string) {
    super(message ?? code);
  }
}

export function hashToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

export async function loadAvailabilityContext(providerId: string) {
  const db = await getDb();
  const [hours, exceptions, policy] = await Promise.all([
    db.query.workingHours.findMany({ where: eq(schema.workingHours.providerId, providerId) }),
    db.query.availabilityExceptions.findMany({ where: eq(schema.availabilityExceptions.providerId, providerId) }),
    getSetting("bookingPolicy"),
  ]);
  return { hours, exceptions, policy };
}

/** Active appointments intersecting [from, to) — used to build busy intervals. Never exposes patient data. */
export async function busyIntervals(db: Db, providerId: string, from: Date, to: Date, excludeId?: string): Promise<BusyInterval[]> {
  const rows = await db.select({ id: schema.appointments.id, startsAt: schema.appointments.startsAt, blocksUntil: schema.appointments.blocksUntil })
    .from(schema.appointments)
    .where(and(
      eq(schema.appointments.providerId, providerId),
      inArray(schema.appointments.status, [...ACTIVE]),
      lt(schema.appointments.startsAt, to),
      gt(schema.appointments.blocksUntil, from),
    ));
  return rows.filter((r) => r.id !== excludeId);
}

export async function slotsForDay(serviceId: string, dateISO: string, opts: { admin?: boolean; excludeAppointmentId?: string } = {}) {
  const db = await getDb();
  const service = await db.query.services.findFirst({ where: eq(schema.services.id, serviceId) });
  if (!service || (!service.active && !opts.admin)) throw new BookingError("service_not_found");
  const ctx = await loadAvailabilityContext((await getSetting("bookingPolicy")).providerId);
  const zone = ctx.policy.timezone;
  const day = DateTime.fromISO(dateISO, { zone });
  if (!day.isValid) return { service, slots: [] };
  const busy = await busyIntervals(db, ctx.policy.providerId, day.startOf("day").toJSDate(), day.endOf("day").toJSDate(), opts.excludeAppointmentId);
  const slots = computeSlots({ dateISO, service, hours: ctx.hours, exceptions: ctx.exceptions, busy, policy: ctx.policy, ignorePolicyLimits: opts.admin });
  return { service, slots, policy: ctx.policy };
}

export type BookInput = {
  serviceId: string;
  startISO: string; // exact slot start as ISO (UTC or offset)
  patient: { name: string; email: string; phone: string; locale: "it" | "en"; smsOptIn?: boolean; notes?: string };
  source?: "online" | "manual" | "app";
  admin?: boolean;
  actor?: string;
  /** book for an existing patient account instead of creating a patient row */
  patientId?: string;
  /** force the approval flow (patient-app requests are always reviewed by the practitioner) */
  requireApproval?: boolean;
};

function isOverlapError(e: unknown) {
  const msg = String((e as { cause?: { message?: string }; message?: string })?.cause?.message ?? (e as Error)?.message ?? "");
  return msg.includes("appointments_no_overlap") || msg.includes("23P01") || msg.includes("exclusion constraint");
}

/** Atomic booking: validates the slot inside the transaction and relies on the DB exclusion constraint as the last line of defence. */
export async function bookAppointment(input: BookInput) {
  const db = await getDb();
  const start = new Date(input.startISO);
  if (Number.isNaN(start.getTime())) throw new BookingError("invalid_slot");
  const { service, slots, policy } = await slotsForDay(input.serviceId, DateTime.fromJSDate(start, { zone: (await getSetting("bookingPolicy")).timezone }).toISODate()!, { admin: input.admin });
  if (!slots.some((s) => s.start.getTime() === start.getTime())) throw new BookingError("slot_taken", "That time is no longer available.");
  const end = new Date(start.getTime() + service.durationMin * 60_000);
  const blocksUntil = new Date(end.getTime() + service.bufferMin * 60_000);
  const token = randomBytes(24).toString("hex");
  const status = (policy!.requireApproval || input.requireApproval) && !input.admin ? "pending" : "confirmed";
  const ns = await loadNotifySettings();

  try {
    const result = await db.transaction(async (tx) => {
      // Re-check inside the transaction (serializable-ish guard); the EXCLUDE constraint makes it bulletproof.
      const clash = await busyIntervals(tx as unknown as Db, policy!.providerId, start, blocksUntil);
      if (clash.length) throw new BookingError("slot_taken");

      let patient: schema.Patient;
      if (input.patientId) {
        const existing = await tx.query.patients.findFirst({ where: eq(schema.patients.id, input.patientId) });
        if (!existing) throw new BookingError("not_found");
        patient = existing;
      } else {
        [patient] = await tx.insert(schema.patients).values({
          name: input.patient.name.trim(), email: input.patient.email.trim().toLowerCase(), phone: input.patient.phone.trim(),
          locale: input.patient.locale, smsOptIn: !!input.patient.smsOptIn,
        }).returning();
      }

      const [appt] = await tx.insert(schema.appointments).values({
        reference: makeReference(), patientId: patient.id, serviceId: service.id, providerId: policy!.providerId,
        startsAt: start, endsAt: end, blocksUntil, status, source: input.source ?? "online",
        manageTokenHash: hashToken(token), patientNotes: input.patient.notes?.slice(0, 500), locale: input.patient.locale,
      }).returning();

      await tx.insert(schema.appointmentEvents).values({ appointmentId: appt.id, type: "booked", actor: input.actor ?? (input.admin ? "admin" : "patient"), data: { status } });
      await enqueueAppointmentNotifications(tx as unknown as Db, { appointment: appt, patient, service, kind: status === "pending" ? "pending" : "booked", manageToken: token }, ns);
      return { appointment: appt, patient, service };
    });
    return { ...result, manageToken: token };
  } catch (e) {
    if (isOverlapError(e)) throw new BookingError("slot_taken", "Someone booked this slot a moment ago.");
    throw e;
  }
}

export async function findByManageToken(reference: string, token: string) {
  const db = await getDb();
  const appt = await db.query.appointments.findFirst({ where: eq(schema.appointments.reference, reference.toUpperCase()) });
  if (!appt || !appt.manageTokenHash || appt.manageTokenHash !== hashToken(token)) throw new BookingError("not_found");
  return appt;
}

export async function getAppointmentFull(id: string) {
  const db = await getDb();
  const appt = await db.query.appointments.findFirst({ where: eq(schema.appointments.id, id) });
  if (!appt) throw new BookingError("not_found");
  const [patient, service] = await Promise.all([
    db.query.patients.findFirst({ where: eq(schema.patients.id, appt.patientId) }),
    db.query.services.findFirst({ where: eq(schema.services.id, appt.serviceId) }),
  ]);
  return { appointment: appt, patient: patient!, service: service! };
}

function assertCutoff(appt: schema.Appointment, hours: number, admin: boolean) {
  if (admin) return;
  if (appt.startsAt.getTime() - Date.now() < hours * 3_600_000) throw new BookingError("policy_cutoff");
}

export async function cancelAppointment(id: string, opts: { admin?: boolean; actor?: string; reason?: string } = {}) {
  const db = await getDb();
  const policy = await getSetting("bookingPolicy");
  const { appointment, patient, service } = await getAppointmentFull(id);
  if (!ACTIVE.includes(appointment.status as (typeof ACTIVE)[number])) throw new BookingError("invalid_state");
  assertCutoff(appointment, policy.cancelCutoffHours, !!opts.admin);
  const ns = await loadNotifySettings();
  return db.transaction(async (tx) => {
    const [updated] = await tx.update(schema.appointments).set({ status: "cancelled", updatedAt: new Date() }).where(eq(schema.appointments.id, id)).returning();
    await tx.insert(schema.appointmentEvents).values({ appointmentId: id, type: "cancelled", actor: opts.actor ?? (opts.admin ? "admin" : "patient"), data: { reason: opts.reason ?? null } });
    await cancelReminderJobs(tx as unknown as Db, id);
    await enqueueAppointmentNotifications(tx as unknown as Db, { appointment: updated, patient, service, kind: "cancelled", byAdmin: !!opts.admin }, ns);
    return updated;
  });
}

/** Lock the new slot and release the old one in a single transaction. */
export async function rescheduleAppointment(id: string, newStartISO: string, opts: { admin?: boolean; actor?: string } = {}) {
  const db = await getDb();
  const policy = await getSetting("bookingPolicy");
  const { appointment, patient, service } = await getAppointmentFull(id);
  if (!ACTIVE.includes(appointment.status as (typeof ACTIVE)[number])) throw new BookingError("invalid_state");
  assertCutoff(appointment, policy.rescheduleCutoffHours, !!opts.admin);
  const start = new Date(newStartISO);
  const { slots } = await slotsForDay(service.id, DateTime.fromJSDate(start, { zone: policy.timezone }).toISODate()!, { admin: opts.admin, excludeAppointmentId: id });
  if (!slots.some((s) => s.start.getTime() === start.getTime())) throw new BookingError("slot_taken");
  const end = new Date(start.getTime() + service.durationMin * 60_000);
  const blocksUntil = new Date(end.getTime() + service.bufferMin * 60_000);
  const ns = await loadNotifySettings();
  try {
    return await db.transaction(async (tx) => {
      const clash = await busyIntervals(tx as unknown as Db, policy.providerId, start, blocksUntil, id);
      if (clash.length) throw new BookingError("slot_taken");
      const [updated] = await tx.update(schema.appointments)
        .set({ startsAt: start, endsAt: end, blocksUntil, status: appointment.status === "pending" ? "pending" : "rescheduled", updatedAt: new Date() })
        .where(eq(schema.appointments.id, id)).returning();
      await tx.insert(schema.appointmentEvents).values({ appointmentId: id, type: "rescheduled", actor: opts.actor ?? (opts.admin ? "admin" : "patient"), data: { from: appointment.startsAt.toISOString(), to: start.toISOString() } });
      await cancelReminderJobs(tx as unknown as Db, id);
      await enqueueAppointmentNotifications(tx as unknown as Db, { appointment: updated, patient, service, kind: "rescheduled", byAdmin: !!opts.admin }, ns);
      return updated;
    });
  } catch (e) {
    if (isOverlapError(e)) throw new BookingError("slot_taken");
    throw e;
  }
}

export async function setAppointmentStatus(id: string, status: "confirmed" | "completed" | "no_show", actor = "admin") {
  const db = await getDb();
  const { appointment, patient, service } = await getAppointmentFull(id);
  const ns = await loadNotifySettings();
  return db.transaction(async (tx) => {
    const [updated] = await tx.update(schema.appointments).set({ status, updatedAt: new Date() }).where(eq(schema.appointments.id, id)).returning();
    await tx.insert(schema.appointmentEvents).values({ appointmentId: id, type: status, actor, data: { from: appointment.status } });
    if (status === "confirmed" && appointment.status === "pending") {
      await enqueueAppointmentNotifications(tx as unknown as Db, { appointment: updated, patient, service, kind: "approved" }, ns);
    }
    if (status !== "confirmed") await cancelReminderJobs(tx as unknown as Db, id);
    return updated;
  });
}
