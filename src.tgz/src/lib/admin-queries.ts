import { and, asc, count, desc, eq, gte, inArray, lt, sql } from "drizzle-orm";
import { DateTime } from "luxon";
import { getDb, schema } from "@/db";
import { getSetting } from "./settings";
import { loadAvailabilityContext, busyIntervals } from "./booking";
import { computeSlots } from "./availability";

export const ACTIVE = ["pending", "confirmed", "rescheduled"] as const;

export async function appointmentsBetween(from: Date, to: Date) {
  const db = await getDb();
  return db.select({ a: schema.appointments, p: schema.patients, s: schema.services }).from(schema.appointments)
    .innerJoin(schema.patients, eq(schema.appointments.patientId, schema.patients.id))
    .innerJoin(schema.services, eq(schema.appointments.serviceId, schema.services.id))
    .where(and(gte(schema.appointments.startsAt, from), lt(schema.appointments.startsAt, to)))
    .orderBy(asc(schema.appointments.startsAt));
}

export async function overviewStats() {
  const db = await getDb();
  const policy = await getSetting("bookingPolicy");
  const now = DateTime.now().setZone(policy.timezone);
  const [todayStart, todayEnd] = [now.startOf("day").toJSDate(), now.endOf("day").toJSDate()];
  const n = async (where: ReturnType<typeof and>) => Number((await db.select({ n: count() }).from(schema.appointments).where(where))[0].n);
  const A = schema.appointments;
  const today = await appointmentsBetween(todayStart, todayEnd);
  const [upcoming, newWeek, pending, cancelledWeek, noShow30, unread] = await Promise.all([
    n(and(gte(A.startsAt, new Date()), lt(A.startsAt, now.plus({ days: 30 }).toJSDate()), inArray(A.status, [...ACTIVE]))),
    n(and(gte(A.bookedAt, now.minus({ days: 7 }).toJSDate()), eq(A.source, "online"))),
    n(eq(A.status, "pending")),
    n(and(eq(A.status, "cancelled"), gte(A.updatedAt, now.minus({ days: 7 }).toJSDate()))),
    n(and(eq(A.status, "no_show"), gte(A.startsAt, now.minus({ days: 30 }).toJSDate()))),
    Number((await db.select({ n: count() }).from(schema.adminNotifications).where(eq(schema.adminNotifications.read, false)))[0].n),
  ]);
  // remaining openings today for the shortest active service
  const ctx = await loadAvailabilityContext(policy.providerId);
  const shortest = await db.query.services.findFirst({ where: eq(schema.services.active, true), orderBy: asc(schema.services.durationMin) });
  let free = 0;
  if (shortest) {
    const busy = await busyIntervals(db, policy.providerId, todayStart, todayEnd);
    free = computeSlots({ dateISO: now.toISODate()!, service: shortest, hours: ctx.hours, exceptions: ctx.exceptions, busy, policy: { ...policy, minNoticeHours: 0 } }).length;
  }
  const notifications = await db.query.adminNotifications.findMany({ orderBy: desc(schema.adminNotifications.createdAt), limit: 12 });
  return { today, upcoming, newWeek, pending, cancelledWeek, noShow30, unread, free, notifications, timezone: policy.timezone };
}

export async function analytics(days = 90) {
  const db = await getDb();
  const since = DateTime.now().minus({ days }).toJSDate();
  const A = schema.appointments;
  const rows = await db.select({ status: A.status, startsAt: A.startsAt, bookedAt: A.bookedAt, serviceId: A.serviceId, patientEmail: schema.patients.email, titleIt: schema.services.titleIt, titleEn: schema.services.titleEn })
    .from(A).innerJoin(schema.patients, eq(A.patientId, schema.patients.id)).innerJoin(schema.services, eq(A.serviceId, schema.services.id)).where(gte(A.bookedAt, since));
  const byWeek = new Map<string, number>();
  const byService = new Map<string, { it: string; en: string; n: number }>();
  const byEmail = new Map<string, number>();
  for (const r of rows) {
    const wk = DateTime.fromJSDate(r.bookedAt).startOf("week").toISODate()!;
    byWeek.set(wk, (byWeek.get(wk) ?? 0) + 1);
    const s = byService.get(r.serviceId) ?? { it: r.titleIt, en: r.titleEn, n: 0 }; s.n++; byService.set(r.serviceId, s);
    byEmail.set(r.patientEmail, (byEmail.get(r.patientEmail) ?? 0) + 1);
  }
  const total = rows.length;
  const cancelled = rows.filter((r) => r.status === "cancelled").length;
  const noShow = rows.filter((r) => r.status === "no_show").length;
  const returning = [...byEmail.values()].filter((n) => n > 1).length;
  return { total, cancelled, noShow, returning, uniquePatients: byEmail.size,
    byWeek: [...byWeek.entries()].sort(([a], [b]) => a.localeCompare(b)), byService: [...byService.values()].sort((a, b) => b.n - a.n) };
}

export const sqlNow = sql`now()`;
